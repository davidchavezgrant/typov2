using System.Net;
using System.Net.Http.Json;
using DotNetCore.CAP.Monitoring;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ChatTests;
public class AttachFile: ApiTestBase
{
	/// <inheritdoc />
	public AttachFile(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task AttachesFile()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		var room            = await this.CreateChatRoom(new[] { me.Id, them.Id });
		var message         = new SendMessageRequest(room.Id, me.Id, "hello", 19999);
		var messageResponse = await this.ApiClient.PostAsJsonAsync($"/api/chats/{room.Id}/messages", message);
		var messageResult   = await messageResponse.Content.ReadFromJsonAsync<ChatMessageDto>();
		var attachment      = new AttachmentRequest(Guid.NewGuid(), "test.txt");

		// Act
		var result = await this.ApiClient.PostAsJsonAsync($"/api/chats/{room.Id}/messages/{messageResult.Id}/attachments",
														  attachment);
		var attachmentResult = await result.Content.ReadFromJsonAsync<AttachmentDto>();
		attachmentResult.Should().NotBeNull();
		using var db = this.CreateDbContext();
		var chat = await db.Chats.Include(x => x.Messages)
						   .ThenInclude(x => x.Attachments)
						   .FirstOrDefaultAsync(x => x.Id == room.Id);
		var messageWithAttachment = chat.Messages.FirstOrDefault(x => x.Id == messageResult.Id);

		// Assert
		messageWithAttachment.Should().NotBeNull();
		messageWithAttachment.Attachments.Should().NotBeEmpty();
		messageWithAttachment.Attachments.First().FileName.Should().Be("test.txt");
		messageWithAttachment.Attachments.First().Id.Should().Be(attachmentResult.AttachmentId);
	}
}