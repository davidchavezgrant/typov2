using Typo.Kernel.Abstract;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Chats.Domain;
internal sealed class Chat: Entity<Guid>
{
	private readonly List<ChatMessage>     _messages     = new();
	private readonly List<ChatParticipant> _participants = new();
	private Chat() {}
	public Chat(IEnumerable<UserProfile> participants)
	{
		this._participants.AddRange(participants.Select(p => new ChatParticipant(this, p)));
	}
	public IReadOnlyCollection<ChatMessage>     Messages     => this._messages.AsReadOnly();
	public IReadOnlyCollection<ChatParticipant> Participants => this._participants.AsReadOnly();

	public ChatMessage SendMessage(ChatParticipant sender, string text, long sentAt)
	{
		var message = new ChatMessage(this, sender, text, sentAt);
		this._messages.Add(message);
		return message;
	}

	public ChatDto ToDto()
	{
		var participants = this._participants.Select(p => new ChatParticipantDto(p.UserProfileId, p.Nickname));
		var messages = this._messages.Select(a => new ChatMessageDto(a.Id,
																	 a.Chat.Id,
																	 a.Sender.UserProfileId,
																	 a.Text,
																	 a.SentAt));
		return new ChatDto(this.Id, participants, messages);
	}
}