namespace Typo.Messenger.Core.Profiles.Domain;
internal sealed class Friendship
{
	private Friendship() {}
	public Friendship(UserProfile first, UserProfile second)
	{
		if (first is null)
		{
			throw new ArgumentNullException(nameof(first));
		}

		if (second is null)
		{
			throw new ArgumentNullException(nameof(second));
		}

		if (first.Id == second.Id)
		{
			throw new ArgumentException("Users cannot be the same");
		}

		this.First    = first;
		this.FirstId  = first.Id;
		this.Second   = second;
		this.SecondId = second.Id;
	}
	public UserProfile First    { get; private set; }
	public Guid        FirstId  { get; private set; }
	public UserProfile Second   { get; private set; }
	public Guid        SecondId { get; private set; }
}