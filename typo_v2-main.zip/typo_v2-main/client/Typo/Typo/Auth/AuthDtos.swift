import Foundation

// MARK: - AuthRequest

struct AuthRequest: Codable {
    public var username = ""
}

// MARK: - RegisterResponse

struct RegisterResponse: Codable {
    public let id: UUID
    public let phoneNumber: String?
    public let email: String?
    public let phoneNumberConfirmed: Bool
    public let emailConfirmed: Bool
}

// MARK: - SendOtpRequest

struct SendOtpRequest: Codable {
    public let value: String
}

// MARK: - ValidateOtpRequest

struct ValidateOtpRequest: Codable {
    public let userIdentifier: String
    public let code: String
}

// MARK: - ValidateOtpResponse

struct ValidateOtpResponse: Codable {
    public let success: Bool
    public let accessToken: String
    public let refreshToken: String
    public let error: String
    public let userName: String
    public let userId: UUID
}
