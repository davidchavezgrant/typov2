using Savorboard.CAP.InMemoryMessageQueue;
using Typo.Kernel.Abstract;
namespace Typo.Web.Client.EventBus;
internal static class ServiceCollectionExtensions
{
	public static IServiceCollection AddInProcessEventBus(this IServiceCollection services)
	{
		services.AddTransient<IEventPublisher, CapEventPublisher>();
		services.AddCap(options =>
						{
							options.UseInMemoryStorage();
							options.UseInMemoryMessageQueue();
							options.UseDashboard();
						});
		return services;
	}

	public static IServiceCollection AddOutOfProcessEventBus(this IServiceCollection services,
															 string                  kafkaConnectionString,
															 string                  postgresConnectionString)
	{
		services.AddTransient<IEventPublisher, CapEventPublisher>();
		services.AddCap(options =>
						{
							options.UseKafka(kafkaConnectionString);
							options.UsePostgreSql(postgresConnectionString);
							options.UseDashboard();
						});
		return services;
	}
}