using Typo.Kernel;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Service;
namespace Typo.Web.Client;
public sealed class ProfileProvider
{
	private readonly AuthStateProvider    _authStateProvider;
	private readonly IProfileService      _profileService;
	private          List<UserProfileDto> _profiles = new List<UserProfileDto>();
	public ProfileProvider(IProfileService profileService, AuthStateProvider authStateProvider)
	{
		this._profileService    = profileService;
		this._authStateProvider = authStateProvider;
	}
	public List<UserProfileDto> Profiles
	{
		get => this._profiles;
		private set
		{
			this._profiles = value;
			this.OnChange?.Invoke();
		}
	}
	public UserProfileDto? ActiveProfile => this.Profiles.FirstOrDefault();

	public event Action? OnChange;
	public void ClearCache()
	{
		this.Profiles = new();
	}
	private async Task<Result> CreateProfile()
	{
		var request = new CreateProfileRequest(this._authStateProvider.Username);
		var result  = await this._profileService.CreateProfile(request, this._authStateProvider.UserId);
		if (result.IsSuccess)
		{
			this.Profiles.Add(result.Value);
			return Result.Ok;
		}

		return result.Error;
	}
	public async Task<Result> FetchProfiles()
	{
		await this.Initialize();
		if (this.Profiles.Count == 0)
		{
			var result = await this.CreateProfile();
			if (result?.Error is not null)
			{
				return result.Error;
			}
		}

		return Result.Ok;
	}
	private async Task FetchProfiles(Guid userId)
	{
		var profiles = await this._profileService.GetUserProfiles(userId);
		this.Profiles = profiles.Profiles.ToList();
	}
	public async Task Initialize()
	{
		var token = await this._authStateProvider.GetToken();
		if (token is not null)
		{
			var userId = await this._authStateProvider.FetchUserId(token);
			if (userId is null) return;

			await this.FetchProfiles(userId.Value);
			return;
		}
	}
}