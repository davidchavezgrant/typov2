import Foundation

// MARK: - FileInfoForView

public class FileAttachmentData: AttachmentData {
    // MARK: Internal

    var id: UUID
    var sizeInBytes: UInt64
    var name: String
    var imageHeight: CGFloat?
    var imageWidth: CGFloat?

    // MARK: Lifecycle

    init(id: UUID, sizeInBytes: UInt64, name: String) {
        self.id = id
        self.sizeInBytes = sizeInBytes
        self.name = name
        let imageSize = MediaSize.create(fileName: name, fileId: id)
        imageWidth = imageSize.width
        imageHeight = imageSize.height
    }

    func updateSize(_ size: MediaSize) {
        imageWidth = size.width
        imageHeight = size.height
    }

    var displayText: String {
        if name.count < DisplayConstants.pillDisplayTextMaxLength {
            return name
        }
        // Find the last occurrence of "."
        guard let endOfFileName = name.lastIndex(of: ".")
        else {
            // If no "." is found, return a truncated version of the name
            let maxLength = DisplayConstants.pillDisplayTextMaxLength - 3
            let truncatedString = name.prefix(maxLength) + "..."
            return String(truncatedString)
        }

        let fileName = name[..<endOfFileName]
        let fileExtensionWithDelimiter = name[endOfFileName...]

        let fileNameMaxLength = DisplayConstants.pillDisplayTextMaxLength - fileExtensionWithDelimiter.count
        let nameEnd = "..." + fileName.suffix(4)
        let nameStart = String(name.prefix(fileNameMaxLength - nameEnd.count))
        return nameStart + nameEnd + fileExtensionWithDelimiter
    }
}
