using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Typo.Identity.Tests.Integration")]