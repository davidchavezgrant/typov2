import Foundation
import SwiftUI

public class MessageViewModel: Identifiable, Hashable, ObservableObject {
    static let textAttributes: [NSAttributedString.Key: Any] = [
        .font: NSFont(name: "SF Pro Text", size: 17)!,
    ]

    public var id: UUID
    var attributedContent: NSAttributedString
    var textContent: String
    var isFromMe = true
    @Published
    var senderName: String
    @Published
    var attachments: [AttachmentViewModel]
    @Published
    var activeAttachment: AttachmentViewModel {
        didSet {
            for attachment in attachments {
                if attachment.id != activeAttachment.id {
                    attachment.isActive = false
                }
            }
        }
    }

    @Published
    var timestamp: Int

    init() {
        id = UUID()
        textContent = ""
        senderName = ""
        attachments = []
        timestamp = 0
        attributedContent = NSAttributedString(string: "")
        activeAttachment = AttachmentViewModel()
    }

    init(message: Message, senderName: String, isFromMe: Bool) {
        id = message.id
        self.isFromMe = isFromMe
        self.senderName = senderName
        attachments = message.attachments
        textContent = message.textContent
        activeAttachment = AttachmentViewModel()
        var attachmentContents = message.attachments.map { $0.getContentState() }
        var contentState = MessageContentState(text: message.textContent, attachments: attachmentContents, isFromMe: isFromMe)
        attributedContent = contentState.toAttributedString()
        timestamp = message.timestamp
    }

    init(id: UUID,
         textContent: String,
         isFromMe: Bool,
         senderName: String,
         attachments: [AttachmentViewModel],
         timestamp: Int)
    {
        self.id = id
        self.isFromMe = isFromMe
        self.senderName = senderName
        self.attachments = attachments
        self.textContent = textContent
        self.timestamp = timestamp
        activeAttachment = attachments.first!
        var attachmentContents = attachments.map { $0.getContentState() }
        var contentState = MessageContentState(text: textContent, attachments: attachmentContents, isFromMe: isFromMe)
        attributedContent = contentState.toAttributedString()
    }

    public func clone() -> MessageViewModel {
        MessageViewModel(id: id,
                         textContent: textContent,
                         isFromMe: isFromMe,
                         senderName: senderName,
                         attachments: attachments.map { $0.clone() }, timestamp: timestamp)
    }

    // swiftlint:disable:next operator_whitespace
    public static func == (lhs: MessageViewModel, rhs: MessageViewModel) -> Bool {
        lhs.id == rhs.id
    }

    public func refresh() {
        if let newAttachment = attachments.first(where: {
            $0.data.id == activeAttachment.data
                .id
        }) {
            activeAttachment = newAttachment
        }
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }

    public func getSystemMessage(getDisplayName: (UUID) -> String?) -> String? {
        if let systemMessageAttachment = attachments.first?.data as? SystemMessageAttachmentData {
            let name = getDisplayName(systemMessageAttachment.userId) ?? "Unknown User"
            switch systemMessageAttachment.type {
            case .userJoined:
                return "\(name) joined the stream"
            case .userLeft:
                return "\(name) left the stream"
            case .streamCreated:
                return "\(name) created the stream"
            }
        } else {
            return nil
        }
    }

    public var isSystemMessage: Bool {
        attachments.first?.data is SystemMessageAttachmentData
    }

    /// Handles a file drop event from the input field
    public func handleDrop(providers: [NSItemProvider]) -> Bool {
        var success = false
        for itemProvider in providers {
            loadFile(itemProvider: itemProvider)
        }
        return success
    }

    private func loadFile(itemProvider: NSItemProvider) {
        itemProvider.loadItem(forTypeIdentifier: "public.file-url", options: nil) { data, _ in
            if let data = data,
               let url = NSURL(dataRepresentation: data as! Data, relativeTo: nil) as URL?
            {
                self.attachFile(locatedAt: url)
            }
        }
    }

    private func attachFile(locatedAt url: URL) {
        let attachmentData = Import.fileAttachment(from: url)
        let attachment = AttachmentViewModel(data: attachmentData,
                                             displayIndex: attachments.count - 1)
        attachment.isActive = attachments.count == 0
        attachments.append(attachment)

        if attachments.count == 1 {
            DispatchQueue.main.async {
                self.activeAttachment = attachment
            }
        }
    }
}
