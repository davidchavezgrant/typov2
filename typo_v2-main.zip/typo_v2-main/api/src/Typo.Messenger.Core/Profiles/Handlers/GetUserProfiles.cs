using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
class GetUserProfiles
{
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _userId;
	public GetUserProfiles(MessengerDbContext dbContext, Guid userId)
	{
		this._dbContext = dbContext;
		this._userId    = userId;
	}
	public async Task<UserProfileListDto> Execute()
	{
		var results = await this._dbContext.Profiles.Where(p => p.UserId == this._userId).ToListAsync();
		return new UserProfileListDto(results.Select(p => p.ToDto()));
	}
}