using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
namespace Typo.Messenger.Core.Chats;
internal sealed class ChatHub: Hub
{

	private readonly ILogger<ChatHub> _logger;

	public ChatHub(ILogger<ChatHub> logger)
	{
		this._logger = logger;
	}

	public async Task SubscribeToProfileChatsCreated(Guid profileId)
	{

		var topicId = $"chat-created_{profileId}";
		await this.Groups.AddToGroupAsync(this.Context.ConnectionId, topicId);
		this._logger.LogInformation($"Client {this.Context.ConnectionId} subscribed to {topicId}");
	}

	public async Task SubscribeToChatMessagesSent(Guid chatId)
	{
		var topicId = $"message-sent_{chatId}";
		await this.Groups.AddToGroupAsync(this.Context.ConnectionId, topicId);
		this._logger.LogInformation($"Client {this.Context.ConnectionId} subscribed to {topicId}");
	}
}