using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Typo.Messenger.Core.Chats.Domain;
namespace Typo.Messenger.Core.Chats;
public static class Endpoints
{
	public static IEndpointRouteBuilder MapChatEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapPost("/api/chats", HttpChatService.CreateChat)
				 .WithOpenApi()
				 .Produces<ChatDto>()
				 .WithDisplayName("CreateChat")
				 .WithSummary("Creates a Chat Room")
				 .WithDescription("Creates a new Chat Room with the provided participants.");

		endpoints.MapGet("/api/chats", HttpChatService.GetChats)
				 .WithOpenApi()
				 .Produces<IEnumerable<ChatDto>>()
				 .WithDisplayName("GetChats")
				 .WithSummary("Gets all Chat Rooms for the provided user")
				 .WithDescription("Gets all Chat Rooms for the provided user");

		endpoints.MapGet("/api/chats/{chatId}", HttpChatService.GetChat)
				 .WithOpenApi()
				 .Produces<ChatDto>()
				 .WithDisplayName("GetChat")
				 .WithSummary("Gets a Chat Room by its Id")
				 .WithDescription("Gets a Chat Room by its Id");

		endpoints.MapPost("/api/chats/{chatId}/messages", HttpChatService.SendMessage)
				 .WithOpenApi()
				 .Produces<ChatMessageDto>()
				 .WithDisplayName("SendMessage")
				 .WithSummary("Sends a message to a Chat Room")
				 .WithDescription("Sends a message to a Chat Room");

		endpoints.MapGet("/api/chats/{chatId}/messages/{messageId}", HttpChatService.GetMessage)
				 .WithOpenApi()
				 .Produces<ChatMessageDto>()
				 .WithDisplayName("GetMessage")
				 .WithSummary("Gets a message by its Id")
				 .WithDescription("Gets a message by its Id");

		endpoints.MapPost("/api/chats/{chatId}/messages/{messageId}/attachments", HttpChatService.AttachFile)
				 .WithOpenApi()
				 .Produces<AttachmentDto>()
				 .WithDisplayName("AttachFile")
				 .WithSummary("Attaches a file to a message")
				 .WithDescription("Attaches a file to a message");

		endpoints.MapPost("/api/chats/{chatId}/messages/{messageId}/comments", HttpChatService.AddComment)
				 .WithOpenApi()
				 .Produces<CommentDto>()
				 .WithDisplayName("CommentMessage")
				 .WithSummary("Comments on a message")
				 .WithDescription("Comments on a message");

		endpoints.MapGet("/api/chats/{chatId}/messages/{messageId}/comments", HttpChatService.GetComments)
				 .WithOpenApi()
				 .Produces<CommentDtoList>()
				 .WithDisplayName("GetComments")
				 .WithSummary("Gets all comments for a message")
				 .WithDescription("Gets all comments for a message");
		endpoints.MapPost("/api/profiles/upload-image",
						  async (IFormFile                          profileImage,
								 [FromServices] IFileStorageService fileService,
								 HttpContext                        httpContext) =>
						  {
							  Console.WriteLine("UPLOADING FILE...");
							  var userId = httpContext.Items["UserId"] as Guid?;
							  if (!userId.HasValue)
							  {
								  return Results.BadRequest("Invalid user ID");
							  }
							  var keys = httpContext.Request.Form.Keys;

							  var file = httpContext.Request.Form.Files.GetFile("profileImage");
							  if (file is null || file.Length == 0)
							  {
								  return Results.BadRequest("No file uploaded or file is empty.");
							  }

							  try
							  {
								  var response = await fileService.Upload(file.FileName, file.OpenReadStream());
								  return Results.Ok(response);
							  }
							  catch (Exception e)
							  {
								  return Results.BadRequest("Error occurred while processing the uploaded file.");
							  }
						  })
				 .DisableAntiforgery();
		endpoints.MapHub<ChatHub>("/rtm/chat");

		return endpoints;
	}
}
