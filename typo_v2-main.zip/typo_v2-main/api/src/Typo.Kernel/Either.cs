namespace Typo.Kernel;
public abstract record Either<TLeft, TRight>
{
	public sealed record Left(TLeft   Value): Either<TLeft, TRight>;
	public sealed record Right(TRight Value): Either<TLeft, TRight>;

	public TResult Match<TResult>(Func<TLeft, TResult> onLeft, Func<TRight, TResult> onRight)
	{
		return this switch
			   {
				   Left left   => onLeft(left.Value),
				   Right right => onRight(right.Value),
				   _           => throw new InvalidOperationException("Unreachable code has been reached.")
			   };
	}
}