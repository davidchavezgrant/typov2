namespace Typo.Kernel.Abstract;
public abstract class AggregateRoot<TId, TIdType>: Entity<TId> where TId: AggregateRootId<TIdType> where TIdType: notnull
{
	public new AggregateRootId<TIdType> Id { get; protected set; }

	public AggregateRoot(TId id): base(id)
	{
		this.Id = id;
	}
}