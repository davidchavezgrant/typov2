using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class GetChats
{
	private readonly MessengerDbContext _db;
	private readonly Guid               _profileId;
	public GetChats(MessengerDbContext db, Guid profileId)
	{
		this._db        = db;
		this._profileId = profileId;
	}

	public async Task<ChatListDto> Execute()
	{
		var chatRooms = await this._db.Chats
								  .Include(cr => cr.Participants)
								  .Include(cr => cr.Messages)
								  .ThenInclude(a => a.Sender)
								  .Where(cr => cr.Participants.Any(p => p.UserProfileId == this._profileId))
								  .ToListAsync();
		var dtos = chatRooms.Select(cr => cr.ToDto());
		return new ChatListDto(dtos);
	}
}