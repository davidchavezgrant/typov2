import Foundation
import SwiftUI

// MARK: - Message

class Message: Identifiable, Equatable, Hashable, ObservableObject {
    // MARK: Lifecycle

    init(id: UUID,
         chatid: UUID,
         senderId: UUID,
         textContent: String,
         timestamp: Int,
         attachments: [AttachmentViewModel])
    {
        self.id = id
        chatId = chatid
        self.senderId = senderId
        self.textContent = textContent
        self.timestamp = timestamp
        self.attachments = attachments
    }

    // MARK: Public

    public let id: UUID
    public let chatId: UUID
    public let timestamp: Int
    public let senderId: UUID
    public let textContent: String
    public let attachments: [AttachmentViewModel]

    public static func fromDto(_ dto: ChatMessageDto) -> Message {
        Message(id: dto.id,
                chatid: dto.chatId,
                senderId: dto.senderId,
                textContent: dto.text,
                timestamp: dto.sentAt,
                attachments: [])
    }

    public static func == (lhs: Message, rhs: Message) -> Bool {
        lhs.id == rhs.id
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
