using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Kernel.Abstract;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class CreateChat
{
	private readonly MessengerDbContext _db;
	private readonly IEventPublisher    _publisher;
	private readonly CreateChatRequest  _request;
	public CreateChat(CreateChatRequest request, MessengerDbContext db, IEventPublisher publisher)
	{
		this._db        = db;
		this._publisher = publisher;
		this._request   = request;
	}

	public async Task<Result<ChatDto>> Execute(Guid requestingProfileId)
	{
		var participants = await this._db.Profiles.Where(p => this._request.ParticipantIds.Contains(p.Id)).ToListAsync();
		if (!this._request.ParticipantIds.Contains(requestingProfileId))
		{
			var requestingProfile = await this._db.Profiles.FindAsync(requestingProfileId);
			participants.Add(requestingProfile);
		}
		var chatRoom = new Chat(participants);

		await this._db.Chats.AddAsync(chatRoom);
		await this._db.SaveChangesAsync();

		return chatRoom.ToDto();
	}
}