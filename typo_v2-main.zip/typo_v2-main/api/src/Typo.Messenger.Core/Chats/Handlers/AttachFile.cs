using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class AttachFile
{
	private readonly MessengerDbContext _context;
	private readonly AttachmentRequest  _request;
	private readonly Guid               _chatId;
	private readonly Guid               _messageId;
	public AttachFile(MessengerDbContext context,
					  AttachmentRequest  request,
					  Guid               chatId,
					  Guid               messageId)
	{
		this._context   = context;
		this._request   = request;
		this._chatId    = chatId;
		this._messageId = messageId;
	}

	public async Task<Result<AttachmentDto>> Execute()
	{
		var chat = await this._context.Chats.Include(x => x.Messages).FirstOrDefaultAsync(x => x.Id == this._chatId);

		if (chat is null)
			return Error.NotFound("Chat not found");

		var message = chat.Messages.FirstOrDefault(x => x.Id == this._messageId);

		if (message is null)
			return Error.NotFound("Message not found");

		var attachment = message.AttachFile(this._request.FileId, this._request.FileName);

		await this._context.SaveChangesAsync();
		return attachment.ToDto();
	}
}