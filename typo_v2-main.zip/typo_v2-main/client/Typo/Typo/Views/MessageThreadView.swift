import SwiftUI

struct MessageThreadView: View {
    // MARK: Public

    @EnvironmentObject
    public var authStateProvider: AuthStateProvider
    @EnvironmentObject
    public var model: ChatModel
    @ObservedObject
    public var selectedChat: Chat
 

    // MARK: Internal

    var body: some View {
        VStack { // Wrap in a VStack for better layout control
            ScrollViewReader { proxy in
                List(selectedChat.messages.sorted(by: { $0.timestamp < $1.timestamp }) ?? [], id: \.self)
                    { artifact in
                        let senderName = model.activeProfile?.nickname
                        let isFromMe = artifact.senderId == model.activeProfile?.id
                        MessageView(artifact: artifact, onArtifactPage: true, senderName: senderName ?? "", isFromMe: isFromMe)
                            .listRowSeparator(.hidden)
                            .id(artifact.id) // Assign an id to each message
                    }
                    .onChange(of: selectedChat) { _ in
                        if let lastMessage = selectedChat.messages.sorted(by: { $0.timestamp < $1.timestamp }).last
                        {
                            proxy.scrollTo(lastMessage.id, anchor: .bottom) // Scroll to the last message
                        }
                    }
            }
           
        }
        .navigationTitle(selectedChat.title ?? "")
    }

    // MARK: Private

   
}
