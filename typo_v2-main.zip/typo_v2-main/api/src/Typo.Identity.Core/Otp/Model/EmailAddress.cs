namespace Typo.Identity.Core.Otp.Model;
public class EmailAddress
{
	private const    int    MAX_EMAIL_LENGTH = 254;
	private readonly string _email;
	public           string Value => this._email;
	public EmailAddress(string email)
	{
		this._email = email;
	}
	public bool IsValid()
	{
		// Check for empty string or length constraint
		if (string.IsNullOrWhiteSpace(this._email) || this._email.Length > MAX_EMAIL_LENGTH)
			return false;

		// Check for presence of '@' symbol
		if (!this._email.Contains('@'))
			return false;

		// Split email into local and domain parts
		var parts = this._email.Split('@');
		if (parts.Length != 2)
			return false;

		// Check if domain part is present
		if (string.IsNullOrWhiteSpace(parts[1]))
			return false;

		// Check for invalid characters
		if (this._email.Any(ch => !this.IsValidCharacter(ch)))
			return false;

		return true;
	}

	private bool IsValidCharacter(char ch)
	{
		// Define valid characters here. This is a basic example.
		return char.IsLetterOrDigit(ch) || ch == '@' || ch == '.' || ch == '_' || ch == '+';
	}
}