using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.UserProfiles;
public class DeleteUserProfile: ApiTestBase
{
	/// <inheritdoc />
	public DeleteUserProfile(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task DeletesUserProfile_When_ProfileExists()
	{
		// Create a new profile
		var createResult = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, new CreateProfileRequest("david"));
		createResult.IsSuccessStatusCode.Should().BeTrue();
		var newProfile = await createResult.Content.ReadFromJsonAsync<UserProfileDto>();

		// Delete the created profile
		var deleteResult = await this.ApiClient.DeleteAsync(ChatRoutes.USER_PROFILES + "/" + newProfile.Id);
		deleteResult.IsSuccessStatusCode.Should().BeTrue();

		// Check if the profile is deleted
		using var dbContext = this.CreateDbContext();
		var       found     = await dbContext.Profiles.FindAsync(newProfile.Id);
		found.Should().BeNull();
	}

	[Fact]
	public async Task DoesNotDeleteUserProfile_When_ProfileDoesNotExist()
	{
		var nonExistentProfileId = Guid.NewGuid();

		// Attempt to delete a non-existent profile
		var deleteResult = await this.ApiClient.DeleteAsync(ChatRoutes.USER_PROFILES + "/" + nonExistentProfileId);
		deleteResult.IsSuccessStatusCode.Should().BeFalse();
	}
}