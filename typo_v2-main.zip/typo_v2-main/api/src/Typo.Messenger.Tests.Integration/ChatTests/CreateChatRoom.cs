using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ChatTests;
public class CreateChatRoom: ApiTestBase
{
	public CreateChatRoom(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}
	[Fact]
	public async Task CreatesChatRoom()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request = new CreateChatRequest(new List<Guid> { user1!.Id, user2!.Id });

		// Act
		var       response = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		using var db       = this.CreateDbContext();
		var       chatRoom = await db.Chats.FirstOrDefaultAsync();

		// Assert
		chatRoom.Should().NotBeNull();
	}

	[Fact]
	public async Task CreatesChatRoom_WithoutMessages()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request = new CreateChatRequest(new List<Guid> { user1!.Id, user2!.Id });

		// Act
		var       response = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		using var db       = this.CreateDbContext();
		var       chatRoom = await db.Chats.FirstOrDefaultAsync();

		// Assert
		chatRoom.Messages.Should().BeEmpty();
	}

	[Fact]
	public async Task CreatesChatRoom_With_CorrectParticipants()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request = new CreateChatRequest(new List<Guid> { user1!.Id, user2!.Id });

		// Act
		var       response = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		using var db       = this.CreateDbContext();
		var       chatRoom = await db.Chats.Include(cr => cr.Participants).FirstOrDefaultAsync();

		// Assert
		chatRoom.Should().NotBeNull();
		chatRoom.Participants.Should().NotBeEmpty().And.HaveCount(2);
		chatRoom.Participants.Select(p => p.UserProfileId).Should().Contain(new List<Guid> { user1.Id, user2.Id });
	}

	[Fact]
	public async Task CreatesChatRoom_With_CorrectParticipants_WhenRequestingProfileIsNotIncludedInRequest()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request = new CreateChatRequest(new List<Guid> { user2!.Id });

		// Act
		var       response = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		using var db       = this.CreateDbContext();
		var       chatRoom = await db.Chats.Include(cr => cr.Participants).FirstOrDefaultAsync();

		// Assert
		chatRoom.Should().NotBeNull();
		chatRoom.Participants.Should().NotBeEmpty().And.HaveCount(2);
		chatRoom.Participants.Select(p => p.UserProfileId).Should().Contain(new List<Guid> { user1.Id, user2.Id });
	}

		[Fact]
	public async Task CreatesChatRoom_With_CorrectParticipants_WhenCreatingWithSelf()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		this.SetActiveProfileHeader(user1.Id);
		var request = new CreateChatRequest(new List<Guid> { user1!.Id, user1!.Id });

		// Act
		var       response = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		using var db       = this.CreateDbContext();
		var       chatRoom = await db.Chats.Include(cr => cr.Participants).FirstOrDefaultAsync();

		// Assert
		chatRoom.Should().NotBeNull();
		chatRoom.Participants.Should().NotBeEmpty().And.HaveCount(1);
		chatRoom.Participants.Select(p => p.UserProfileId).Should().Contain(new List<Guid> { user1!.Id });
	}
}