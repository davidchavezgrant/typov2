using Typo.Identity.Core;
using Typo.Kernel.Configuration;
using Typo.Messenger.Core;
using Typo.Messenger.Core.Chats;
using Typo.Messenger.Core.Profiles;
using Typo.Web.Api;
using Typo.Web.Api.EventBus;
var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseKestrel(o => o.Limits.MaxRequestLineSize = 10024 * 10);

// Configuration
var jwtSettings = builder.Configuration.GetSection("Jwt").Get<JwtSettings>();
builder.Services.Configure<AmazonS3Options>(builder.Configuration.GetSection("AmazonS3"));
builder.Services.Configure<AwsAccountDetails>(builder.Configuration.GetSection("AwsAccountDetails"));

var identityConnection = builder.Configuration.GetConnectionString("IdentityDb");
var chatConnection     = builder.Configuration.GetConnectionString("ChatDb");

// Swagger
builder.Services.AddSwagger();
builder.Services.AddSwaggerGen(options =>
							   {
								   // other configurations...

								   options.CustomSchemaIds(type => type.FullName);
							   });

// Event Bus
builder.Services.AddInProcessEventBus();

// Identity
builder.ConfigureOtpServices();
builder.Services.AddIdentityModuleServices(identityConnection, jwtSettings);

// Messenger
builder.Services.AddChatServices(chatConnection);

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseWhen(context => !context.Request.Path.StartsWithSegments("/health"),
			appBuilder => appBuilder.Use(RequestLoggingMiddleware.EndpointLogging));
if (Environment.GetEnvironmentVariable("MOCK_AUTH") == "TRUE")
{
	app.UseMiddleware<TestUserIdMiddleware>(Guid.NewGuid());
}
app.UseWhen(context => context.Request.Path.Value.Contains("friends")
					   || context.Request.Path.Value.Contains("chats")
					   || (context.Request.Path.Value.Contains("profiles/all") && context.Request.Method == "GET"),
			branch =>
			{
				branch.UseMiddleware<ActiveProfileIdMiddleware>();
			});
app.UseWhen(context => !context.Request.Path.StartsWithSegments("/api/auth")
					   && !context.Request.Path.StartsWithSegments("/health")
					   && !context.Request.Path.StartsWithSegments("/swagger"),
			appBuilder =>
			{
				appBuilder.UseAuthentication();
				appBuilder.UseAuthorization();
				if (Environment.GetEnvironmentVariable("MOCK_AUTH") != "TRUE")
				{
					appBuilder.UseMiddleware<UserIdValidationMiddleware>();
				}
			});

app.MapGet("/health", () => DateTime.UtcNow).AllowAnonymous();
app.MapTypoAuthEndpoints();
app.MapProfileEndpoints();
app.MapChatEndpoints();
app.Run();