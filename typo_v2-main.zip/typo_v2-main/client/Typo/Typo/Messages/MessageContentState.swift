import Foundation
import SwiftUI

public struct AttachmentContentState: Identifiable {
    public let id: UUID
    let data: AttachmentData
    var displayIndex: Int

    init(id: UUID, data: AttachmentData, displayIndex: Int) {
        self.id = id
        self.data = data
        self.displayIndex = displayIndex
    }

    func clone() -> AttachmentContentState {
        AttachmentContentState(id: id,
                               data: data,
                               displayIndex: displayIndex)
    }
}

public struct MessageContentState {
    let text: String
    let attachments: [AttachmentContentState]
    let isFromMe: Bool

    init(text: String, attachments: [AttachmentContentState], isFromMe: Bool) {
        self.text = text
        self.attachments = attachments
        self.isFromMe = isFromMe
    }

    public func toAttributedString() -> NSAttributedString {
        let state = self
        let initialState = createMutableState(text: state.text, isFromMe: state.isFromMe)
        let startingLength = initialState.length

        let sortedAttachments = cloneAndSortAttachments(state.attachments)

        for attachment in sortedAttachments {
            let indexOffset = initialState.length - startingLength
            updateAttachmentDisplayIndex(attachment, indexOffset: indexOffset)
            replaceAndInsertText(initialState, attachment)
        }

        return initialState
    }

    private func createMutableState(text: String, isFromMe: Bool) -> NSMutableAttributedString {
        if isFromMe {
            let backgroundColor = NSColor(named: "BackgroundSolid")!
            Self.defaultAttributes.updateValue(backgroundColor, forKey: .foregroundColor)
        }

        let currentText = NSMutableAttributedString(string: text, attributes: Self.defaultAttributes)
        return currentText
    }

    private func cloneAndSortAttachments(_ attachments: [AttachmentContentState]) -> [AttachmentContentState]
    {
        let clonedAttachments = attachments.map
            { $0.clone() }
        let sortedAttachments = clonedAttachments.sorted
            { $0.displayIndex < $1.displayIndex }
        return sortedAttachments
    }

    private func updateAttachmentDisplayIndex(_ attachment: AttachmentContentState, indexOffset: Int)
    {
        var clonedAttachment = attachment.clone()
        clonedAttachment.displayIndex += indexOffset
    }

    private func replaceAndInsertText(_ textState: NSMutableAttributedString, _ attachment: AttachmentContentState)
    {
        let tokenizedText = "[\(attachment.data.displayText)]"
        let updatedText = NSAttributedString(string: tokenizedText)
        let placeholderRange = NSRange(location: attachment.displayIndex,
                                       length: PillConstants.tokenPlaceholderStringLength)

        textState.replaceCharacters(in: placeholderRange, with: "")
        textState.insert(updatedText, at: attachment.displayIndex)
    }

    private static var defaultAttributes: [NSAttributedString.Key: Any] = [
        .font: DisplayConstants.defaultFont,
        .baselineOffset: NSNumber(value: 0),
        .foregroundColor: NSColor(named: "Label")!,
        .paragraphStyle: DisplayConstants.defaultParagraphStyle,
    ]
}
