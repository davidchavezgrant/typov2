import AVFoundation
import Foundation
import SwiftUI

struct MediaSize {
    let width: CGFloat
    let height: CGFloat

    public static func create(fileName name: String, fileId id: UUID) -> MediaSize {
        let category = MediaType.lookup(fileName: name)
        if category == .image {
            return getImageSize(fileName: name, fileId: id)
        } else if category == .video {
            return getVideoSize(fileName: name, fileId: id)
        }

        return MediaSize(width: 0, height: 0)
    }

    private static func getImageSize(fileName name: String, fileId id: UUID) -> MediaSize {
        guard let imageUrl = URL.localFilePath(fileName: name, folderName: id),
              let data = try? Data(contentsOf: imageUrl),
              let image = NSImage(data: data)
        else {
            return MediaSize(width: 0, height: 0)
        }

        if image.size.width == 0 || image.size.height == 0 {
            print("ERROR NIL SIZE")
        }

        return MediaSize(width: image.size.width, height: image.size.height)
    }

    private static func getVideoSize(fileName name: String, fileId id: UUID) -> MediaSize {
        guard let videoUrl = URL.localFilePath(fileName: name, folderName: id),
              let thumbnail = Self.generateVideoThumbnail(url: videoUrl, at: CMTime(value: 0, timescale: 60))
        else {
            return MediaSize(width: 0, height: 0)
        }

        let image = NSImage(cgImage: thumbnail, size: .zero)
        if image.size.width == 0 || image.size.height == 0 {
            print("ERROR NIL SIZE")
        }

        return MediaSize(width: image.size.width, height: image.size.height)
    }

    private static func generateVideoThumbnail(url: URL, at time: CMTime) -> CGImage? {
        let asset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        imageGenerator.appliesPreferredTrackTransform = true // Rotate the image to the correct orientation

        do {
            let cgImage = try imageGenerator.copyCGImage(at: time, actualTime: nil)
            return cgImage
        } catch {
            return nil
        }
    }
}
