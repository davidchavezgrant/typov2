import Foundation

// MARK: - WhoAmIResponse

struct WhoAmIResponse: Codable {
    public let userId: UUID
    public let email: String?
    public let phoneNumber: String?
}

// MARK: - UserProfileDto

struct UserProfileDto: Codable {
    public let id: UUID
    public let userId: UUID
    public let displayName: String
}

// MARK: - UserProfileListResponse

struct UserProfileListResponse: Codable {
    public let profiles: [UserProfileDto]
}

// MARK: - CreateProfileRequest

struct CreateProfileRequest: Codable {
    public let nickname: String
}

// MARK: - CreateChatRequest

struct CreateChatRequest: Codable {
    public let participantIds: [UUID]
}

// MARK: - UpdateDisplayNameRequest

struct UpdateDisplayNameRequest: Codable {
    public let newDisplayName: String
}

// MARK: - ChatDto

struct ChatDto: Codable {
    public let id: UUID
    public let participants: [ChatParticipantDto]
    public let messages: [ChatMessageDto]
}

// MARK: - ChatParticipantDto

struct ChatParticipantDto: Codable {
    public let userProfileId: UUID
    public let nickname: String
}

// MARK: - ChatMessageDto

struct ChatMessageDto: Codable {
    public let id: UUID
    public let chatId: UUID
    public let senderId: UUID
    public let text: String
    public let sentAt: Int
}

// MARK: - ChatListDto

struct ChatListDto: Codable {
    public let chats: [ChatDto]
}

// MARK: - SendMessageRequest

struct SendMessageRequest: Codable {
    let chatId: UUID
    let senderId: UUID
    let text: String
    let sentAt: Int
}
