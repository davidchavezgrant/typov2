namespace Typo.Kernel;
public static class UserIds
{
	public static readonly Guid One    = Guid.Parse("05910545-5e87-4df3-95c6-40b89dc76dbc");
	public static readonly Guid Two    = Guid.Parse("65ed1a28-d1b1-41ee-acc9-f02aac19dbba");
	public static readonly Guid Three  = Guid.Parse("6ea07a96-03a2-4708-a77a-3710a9272cc1");
	public static readonly Guid Four   = Guid.Parse("9b4d94de-bb70-46d2-a816-dd02fd3cbc2f");
	public static readonly Guid Five   = Guid.Parse("a36fd2e5-7d70-4f93-b909-567064649aff");
	public static readonly Guid Six    = Guid.Parse("a4834a3d-0a62-435a-9f9e-8233bc109792");
	public static readonly Guid Seven  = Guid.Parse("acf74bba-0966-4b87-94d5-0aec309226bf");
	public static readonly Guid Eight  = Guid.Parse("b2b8e95d-98f3-4652-9b26-43c278d29c2c");
	public static readonly Guid Nine   = Guid.Parse("b38d8c07-a492-4ed1-9242-f97a32b0566c");
	public static readonly Guid Ten    = Guid.Parse("dd928a25-a90c-4b6e-b7e1-aabce81a4912");
	public static readonly Guid Eleven = Guid.Parse("fdcbbdb4-25eb-45a4-9bce-7004709779cc");
}