using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ChatTests;
public class GetChatById: ApiTestBase

/// <inheritdoc />
{
	public GetChatById(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsRoom_When_Exist()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		var room = await this.CreateChatRoom(new[] { me.Id, them.Id });

		// Act
		var result = await this.ApiClient.GetFromJsonAsync<ChatDto>($"/api/chats/{room.Id}");

		// Assert
		result.Should().NotBeNull();
	}
}