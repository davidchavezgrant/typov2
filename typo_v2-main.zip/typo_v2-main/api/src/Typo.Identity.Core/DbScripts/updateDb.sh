#!/bin/bash
cd ..
dotnet ef database update --startup-project ../Typo.Web.Api/ --context AppIdentityDbContext
