using System.Net.Http.Json;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.Setup;
public abstract class ApiTestBase: IClassFixture<CustomWebApplicationFactory<IWebApi>>
{
	private readonly HttpClient                           _apiClient;
	private readonly CustomWebApplicationFactory<IWebApi> _factory;

	// Setup
	protected ApiTestBase(CustomWebApplicationFactory<IWebApi> factory)
	{
		this._factory   = factory;
		this._apiClient = factory.CreateClient();
	}
	protected HttpClient ApiClient => this._apiClient;
	private protected MessengerDbContext CreateDbContext()
	{
		return this._factory.CreateScopedDbContext();
	}

	protected async Task<UserProfileDto> CreateProfile(string name)
	{
		var request  = new CreateProfileRequest(name);
		var response = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);
		var result   = await response.Content.ReadFromJsonAsync<UserProfileDto>();
		return result;
	}

	protected async Task<ChatDto> CreateChatRoom(IEnumerable<Guid> participantIds)
	{
		var request  = new CreateChatRequest(participantIds);
		var result   = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		var response = await result.Content.ReadFromJsonAsync<ChatDto>();
		return response;
	}

	protected void SetActiveProfileHeader(Guid id)
	{
		this.ApiClient.DefaultRequestHeaders.Remove("X-Active-Profile-Id");
		this.ApiClient.DefaultRequestHeaders.Add("X-Active-Profile-Id", id.ToString());
	}
}