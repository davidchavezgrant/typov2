using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles;
public class FriendRequestTests
{
	[Fact]
	public void AcceptChangesStatus_When_Invoked()
	{
		var user1         = new UserProfile(Guid.NewGuid(), "User1");
		var user2         = new UserProfile(Guid.NewGuid(), "User2");
		var friendRequest = new FriendRequest(user1, user2);

		friendRequest.Accept();

		friendRequest.Status.Should().Be(FriendRequestStatus.ACCEPTED);
	}

	[Fact]
	public void RejectChangesStatus_When_Invoked()
	{
		var user1         = new UserProfile(Guid.NewGuid(), "User1");
		var user2         = new UserProfile(Guid.NewGuid(), "User2");
		var friendRequest = new FriendRequest(user1, user2);

		friendRequest.Reject();

		friendRequest.Status.Should().Be(FriendRequestStatus.REJECTED);
	}

	[Fact]
	public void CancelChangesStatus_When_Invoked()
	{
		var user1         = new UserProfile(Guid.NewGuid(), "User1");
		var user2         = new UserProfile(Guid.NewGuid(), "User2");
		var friendRequest = new FriendRequest(user1, user2);

		friendRequest.Cancel();

		friendRequest.Status.Should().Be(FriendRequestStatus.CANCELLED);
	}

	[Fact]
	public void RemoveChangesStatus_When_Invoked()
	{
		var user1         = new UserProfile(Guid.NewGuid(), "User1");
		var user2         = new UserProfile(Guid.NewGuid(), "User2");
		var friendRequest = new FriendRequest(user1, user2);

		friendRequest.Remove();

		friendRequest.Status.Should().Be(FriendRequestStatus.REMOVED);
	}

	[Fact]
	public void StartsWithPendingStatus()
	{
		var user1         = new UserProfile(Guid.NewGuid(), "User1");
		var user2         = new UserProfile(Guid.NewGuid(), "User2");
		var friendRequest = new FriendRequest(user1, user2);

		friendRequest.Status.Should().Be(FriendRequestStatus.PENDING);
	}

	[Fact]
	public void ToDto_AssignsAllFields()
	{
		var user1         = new UserProfile(Guid.NewGuid(), "User1");
		var user2         = new UserProfile(Guid.NewGuid(), "User2");
		var friendRequest = new FriendRequest(user1, user2);

		var dto = friendRequest.ToDto();

		dto.Id.Should().Be(friendRequest.Id);
	}
}