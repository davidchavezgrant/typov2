namespace Typo.Kernel.Abstract;
public interface IAggregateRoot;