namespace Typo.Identity.Contracts;
public static class IdentityRoutes
{
	public const string SEND_OTP     = "/api/auth/otp/send";
	public const string VALIDATE_OTP = "/api/auth/otp/validate";
	public const string REGISTER     = "/api/auth/register";
	public const string USER         = "/api/user";
	public const string VALIDATE_JWT = "/api/auth/token/validate";
	public const string TEST_BEARER  = "/api/auth/test/bearer";
	public const string WHOAMI       = "/api/auth/whoami";
}