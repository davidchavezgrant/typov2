import Foundation
import SwiftUI
struct ColorScheme {
    typealias ColorType = Color

    var backgroundColor: Color!
    var textColor: Color!
    var defaultTextColor: Color!
    var borderColor: Color?
    var iconStandinColor: Color!

    static func create(for pillType: PillStatus) -> ColorScheme {
        var backgroundColor: Color!
        var textColor: Color!
        var defaultTextColor: Color!
        var borderColor: Color?
        var iconStandinColor: Color!

        defaultTextColor = pillType.isFromMe ? Colors.BackgroundSolid : Colors.Label

        switch pillType {
        case let .sent(selected):
            if selected {
                backgroundColor = Colors.BackgroundSolid
                textColor = Colors.Blue
                borderColor = Colors.Border
                iconStandinColor = Colors.Border.opacity(0.10)
            } else {
                backgroundColor = Colors.BackgroundSolid.opacity(0.20)
                textColor = Colors.BackgroundSolid
                iconStandinColor = Colors.BackgroundBlur.opacity(0.5)
            }
        case let .received(selected):
            if selected {
                backgroundColor = Colors.BackgroundSolid
                textColor = Colors.Label
                borderColor = Colors.Border.opacity(0.10)
                iconStandinColor = Colors.Border.opacity(0.10)
            } else {
                backgroundColor = Colors.Label.opacity(0.10)
                textColor = Colors.Label
                iconStandinColor = Colors.Border.opacity(0.10)
            }
        case let .new(state):
            switch state {
            case .selected:
                backgroundColor = Colors.BackgroundSolid
                textColor = Colors.Label
                borderColor = Colors.Border.opacity(0.10)
                iconStandinColor = Colors.Border.opacity(0.10)
            case .unselected:
                backgroundColor = Colors.Border.opacity(0.10)
                textColor = Colors.Label
                iconStandinColor = Colors.Border.opacity(0.10)
            case .focused:
                backgroundColor = Colors.Label
                textColor = Colors.BackgroundSolid
                iconStandinColor = Colors.Border.opacity(0.10)
            }
        }
        return ColorScheme(backgroundColor: backgroundColor,
                           textColor: textColor,
                           defaultTextColor: defaultTextColor,
                           iconStandinColor: iconStandinColor)
    }
}
