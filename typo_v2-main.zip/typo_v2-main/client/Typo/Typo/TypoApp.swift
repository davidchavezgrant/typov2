import SwiftUI
@main
struct TypoApp: App {
    @StateObject
    var authStateProvider: AuthStateProvider
    @StateObject
    var model: ChatModel
    @StateObject
    var appState = AppState()
    @State
    var isLoading = true

    init() {
        let authStateProvider = AuthStateProvider()
        let model = ChatModel(authStateProvider: authStateProvider)
        _authStateProvider = StateObject(wrappedValue: authStateProvider)
        _model = StateObject(wrappedValue: model)
    }

    var body: some Scene {
        WindowGroup {
            if isLoading {
                // Replace this with your own loading view
                Text("Loading...")
                    .onAppear {
                        Task {
                            await authStateProvider.initialize()
                            isLoading = false
                        }
                    }
            } else if authStateProvider.isValidated {
                ContentView()
                    .environmentObject(authStateProvider)
                    .environmentObject(model)
                    .environmentObject(appState)
                    .task {
                        do {
                            try await model.initialize(authStateProvider)
                        } catch {
                            print("Error initializing model: \(error)")
                        }
                    }
            } else {
                AuthView()
                    .environmentObject(authStateProvider)
            }
        }
    }
}
