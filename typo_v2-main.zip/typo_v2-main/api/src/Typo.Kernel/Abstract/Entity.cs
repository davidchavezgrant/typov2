using System.ComponentModel.DataAnnotations.Schema;
// ReSharper disable NonReadonlyMemberInGetHashCode
#pragma warning disable CS8607
#pragma warning disable CS8618
namespace Typo.Kernel.Abstract;
public abstract class Entity<TId>: IEquatable<Entity<TId>>
{
	public TId Id { get; protected set; }
	protected Entity() {}
	protected Entity(TId id)
	{
		this.Id = id;
	}

	/// <inheritdoc />
	public override bool Equals(object? obj)
	{
		if (ReferenceEquals(null, obj)) return false;
		if (ReferenceEquals(this, obj)) return true;
		if (obj.GetType() != this.GetType()) return false;

		return this.Equals((Entity<TId>)obj);
	}

	public static bool operator ==(Entity<TId>? left, Entity<TId>? right)
	{
		return Equals(left, right);
	}

	public static bool operator !=(Entity<TId>? left, Entity<TId>? right)
	{
		return !Equals(left, right);
	}

	/// <inheritdoc />
	public override int GetHashCode()
	{
		return EqualityComparer<TId>.Default.GetHashCode(this.Id);
	}

	/// <inheritdoc />
	public bool Equals(Entity<TId>? other)
	{
		return this.Equals((object?)other);
	}
	[NotMapped]
	private readonly List<DomainEvent> _domainEvents = new List<DomainEvent>();
	[NotMapped]
	public IReadOnlyList<DomainEvent> DomainEvents
		=> this._domainEvents.AsReadOnly();
	protected void PublishEvent(DomainEvent domainEvent) => this._domainEvents.Add(domainEvent);

	public void ClearDomainEvents() => this._domainEvents.Clear();
}