namespace Typo.Identity.Core.Otp;
public class ValidateTokenResponse
{
	public bool   IsValid { get; set; }
	public string Message { get; set; }
	public Guid   UserId  { get; set; }

	public ValidateTokenResponse(bool   isValid,
								 string message,
								 Guid   userId)
	{
		this.IsValid = isValid;
		this.Message = message;
		this.UserId  = userId;
	}
}
public sealed record PhoneNumberDto(string Value);
public sealed record SendOtpRequest(string Value);
public sealed record AuthRequest(string    UserIdentifier, string Code);
public sealed record AuthResponse(
bool   Success,
string AccessToken,
string RefreshToken,
string Error,
string UserName,
Guid   UserId);