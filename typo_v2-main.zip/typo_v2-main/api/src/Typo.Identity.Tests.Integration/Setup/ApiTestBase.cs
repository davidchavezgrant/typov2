using Typo.Identity.Core.Users;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Setup;
public abstract class ApiTestBase: IClassFixture<CustomWebApplicationFactory<IWebApi>>
{
	private readonly HttpClient                           _apiClient;
	private readonly CustomWebApplicationFactory<IWebApi> _factory;
	protected        HttpClient                           ApiClient => this._apiClient;
	private protected AppIdentityDbContext CreateDbContext()
	{
		return this._factory.CreateScopedDbContext();
	}

	// Setup
	protected ApiTestBase(CustomWebApplicationFactory<IWebApi> factory)
	{
		this._factory   = factory;
		this._apiClient = factory.CreateClient();
	}

	protected async Task AddUserWithEmail(string email)
	{
		var user = new User
		{
			Email = email
		};
		using var dbContext = this.CreateDbContext();
		dbContext.Users.Add(user);
		await dbContext.SaveChangesAsync();
	}
	protected async Task AddUserWithPhoneNumber(string phone)
	{
		var user = new User
		{
			PhoneNumber = phone
		};
		using var dbContext = this.CreateDbContext();
		dbContext.Users.Add(user);
		await dbContext.SaveChangesAsync();
	}
}