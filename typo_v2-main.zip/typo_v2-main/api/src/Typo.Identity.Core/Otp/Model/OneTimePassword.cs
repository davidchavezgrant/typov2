namespace Typo.Identity.Core.Otp.Model;
internal readonly record struct OneTimePassword
{
	private OneTimePassword(string value, DateTime expiresAt)
	{
		this.Value     = value;
		this.ExpiresAt = expiresAt;
	}

	public string   Value     { get; }
	public DateTime ExpiresAt { get; init; }
	public static OneTimePassword Generate()
		=> new(Guid.NewGuid().ToString("N").Substring(0, 6), DateTime.UtcNow.AddMinutes(5));

	public static OneTimePassword GenerateNumericCode(int length)
	{
		var random = new Random();
		var code   = new char[length];

		for (int i = 0; i < length; i++)
		{
			code[i] = (char)('0' + random.Next(0, 10));
		}
		var value = new string(code);
		return new(value, DateTime.UtcNow.AddMinutes(5));
	}

	public bool IsExpired => this.ExpiresAt < DateTime.UtcNow;
	public static OneTimePassword Generate(DateTime expiry)
		=> new(Guid.NewGuid().ToString("N").Substring(0, 6), expiry);
}