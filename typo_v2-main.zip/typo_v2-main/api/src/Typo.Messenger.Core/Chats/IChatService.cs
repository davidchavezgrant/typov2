using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
namespace Typo.Messenger.Core.Chats;
public interface IChatService
{
	Task<Result<ChatDto>>        CreateChat(CreateChatRequest   request, Guid requestingProfileId);
	Task<ChatListDto>   GetChats(Guid                  profileId);
	Task<Result<ChatDto>>        GetChat(Guid                   id);
	Task<Result<ChatMessageDto>> SendMessage(SendMessageRequest request);
}