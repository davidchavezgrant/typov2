namespace Typo.Web.Api;
public class TestUserIdMiddleware
{
	private readonly RequestDelegate _next;
	private readonly Guid            _testUserId;

	public TestUserIdMiddleware(RequestDelegate next, Guid testUserId)
	{
		this._next       = next;
		this._testUserId = testUserId;
	}

	public async Task InvokeAsync(HttpContext context)
	{
		context.Items["UserId"] = this._testUserId;
		await this._next(context);
	}
}