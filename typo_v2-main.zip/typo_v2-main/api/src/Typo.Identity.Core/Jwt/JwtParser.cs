using System.Security.Claims;
using System.Text.Json;
namespace Typo.Identity.Core.Jwt;
public static class JwtParser
{
	public static IEnumerable<Claim> Parse(string jwt)
	{
		// Take the payload part of the token (index 1)
		// [0] is the header, [1] is the payload
		string payload       = jwt.Split('.')[1];
		byte[] jsonBytes     = ParseBase64WithoutPadding(payload);
		var    keyValuePairs = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonBytes);

		if (keyValuePairs is null)
			return Enumerable.Empty<Claim>();

		// First, add the role claims
		var claims = ExtractClaims(keyValuePairs);

		// Then, add all other claims
		foreach (var kvp in keyValuePairs)
		{
			var claimName = kvp.Value.ToString() ?? string.Empty;
			var newClaim  = new Claim(kvp.Key, claimName);
			claims.Add(newClaim);
		}

		return claims;
	}

	private static byte[] ParseBase64WithoutPadding(string base64)
	{
		switch (base64.Length % 4)
		{
			case 2:
				base64 += "==";
				break;

			case 3:
				base64 += "=";
				break;
		}

		return Convert.FromBase64String(base64);
	}
	private static List<Claim> ExtractClaims(IDictionary<string, object> keyValuePairs)
	{
		keyValuePairs.TryGetValue(ClaimTypes.Role, out object? roles);

		if (roles is null)
			return new List<Claim>();

		string?[]? roleNames = roles.ToString()?.Trim().TrimStart('[').TrimEnd(']').Split(',');

		var claims = CreateClaimsFromRoles(roleNames);

		// Remove the roles from the keyValuePairs so they aren't added a second time to the claims list
		keyValuePairs.Remove(ClaimTypes.Role);
		return claims;
	}
	private static List<Claim> CreateClaimsFromRoles(string?[]? roleNames)
	{
		if (roleNames is not null && roleNames.Length > 1)
			return MultipleClaims(roleNames);
		else
			return OneOrNoClaims(roleNames);
	}

	private static List<Claim> MultipleClaims(string?[] roleNames)
	{
		var claims = new List<Claim>();
		foreach (var role in roleNames)
		{
			var roleName = role?.Trim('"') ?? string.Empty;
			var newClaim = new Claim(ClaimTypes.Role, roleName);
			claims.Add(newClaim);
		}
		return claims;
	}

	private static List<Claim> OneOrNoClaims(string?[]? roleNames)
	{
		var claims    = new List<Claim>();
		var claimName = roleNames?[0] ?? string.Empty;
		var newClaim  = new Claim(ClaimTypes.Role, claimName);
		claims.Add(newClaim);
		return claims;
	}
}