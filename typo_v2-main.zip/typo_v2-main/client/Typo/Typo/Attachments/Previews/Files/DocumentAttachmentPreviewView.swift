import Quartz
import SwiftUI

struct DocumentAttachmentPreviewView: View {
    let url: URL?
    let mimeType: String

    var body: some View {
        if let url = url, mimeType == "application/pdf" {
            ZStack(alignment: .bottomTrailing) {
                Button(action: { showQuickLookPanel() }) {
                    PDFThumbnailView(url: url)
                        .frame(width: 100, height: 100)
                        .border(Color.gray, width: 1)
                }

                TextOverlayView(url: url)
            }
        } else {
            Text("Document")
        }
    }

    private let quickLookController = QuickLookController()

    func showQuickLookPanel() {
        if let panel = QLPreviewPanel.shared() {
            quickLookController.previewItems = [url!]
            panel.dataSource = quickLookController
            panel.makeKeyAndOrderFront(self)
        }
    }
}

// PDFThumbnailView and TextOverlayView remain the same as in the previous example.

struct TextOverlayView: View {
    let url: URL

    var body: some View {
        Text(url.lastPathComponent)
            .font(.caption)
            .padding(3)
            .background(Color.black.opacity(0.5))
            .foregroundColor(.white)
            .cornerRadius(5)
            .padding([.bottom, .trailing], 5)
    }
}

struct PDFThumbnailView: View {
    let url: URL

    var body: some View {
        if let pdfDocument = PDFDocument(url: url), let page = pdfDocument.page(at: 0) {
            Image(nsImage: page.thumbnail(of: CGSize(width: 100, height: 100), for: .artBox))
                .resizable()
                .aspectRatio(contentMode: .fit)
        } else {
            Text("No Preview")
        }
    }
}

// MARK: - SpatialModelAttachmentView

struct SpatialModelAttachmentPreviewView: View {
    let url: URL?
    let mimeType: String
    var body: some View {
        Text("SpatialModel")
    }
}
