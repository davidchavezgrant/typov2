using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using Typo.Identity.Core;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Kernel;
namespace Typo.Web.Client;
public sealed class AuthStateProvider
{
	private readonly IAuthService          _authService;
	private readonly ProtectedLocalStorage _protectedLocalStorage;
	private          bool                  _isAuthenticated;
	private          string?               _token;
	private          Guid                  _userId;
	private          string                _username = string.Empty;
	public AuthStateProvider(ProtectedLocalStorage protectedLocalStorage, IAuthService authService)
	{
		this._protectedLocalStorage = protectedLocalStorage;
		this._authService           = authService;
	}
	public bool IsAuthenticated => this.Token is not null;

	public string? Token
	{
		get => this._token;
		private set
		{
			this._token = value;
			this.OnChange?.Invoke();
		}
	}
	public Guid UserId
	{
		get => this._userId;
		private set
		{
			this._userId = value;
			this.OnChange?.Invoke();
		}
	}
	public string Username
	{
		get => this._username;
		set
		{
			this._username = value;
			this.OnChange?.Invoke();
		}
	}

	public event Action? OnChange;
	public async Task ClearCache()
	{
		await this._protectedLocalStorage.DeleteAsync("token");
		await this._protectedLocalStorage.DeleteAsync("userId");
	}
	public async Task ClearToken()
	{
		await this._protectedLocalStorage.DeleteAsync("token");
		this.Token = null;
	}
	public async Task<Guid?> FetchUserId(string token)
	{
		var whoami = await this._authService.WhoAmI(token);
		if (whoami.Value is null)
		{
			await this.ClearToken();
			return null;
		}

		this.Token = token;
		var userId = whoami.Value.UserId;
		await this.SetUserId(userId);
		this.Username = whoami.Value.PhoneNumber;
		if (string.IsNullOrWhiteSpace(this.Username))
		{
			this.Username = whoami.Value.Email;
		}

		if (string.IsNullOrWhiteSpace(this.Username))
		{
			return null;
		}

		return userId;
	}
	public async Task<string?> GetToken()
	{
		var result = await this._protectedLocalStorage.GetAsync<string>("token");
		return result.Value;
	}
	public async Task<Result> Login(string username)
	{
		this.Username = username;
		var result = await this.SendOtp();
		if (result.IsSuccess)
		{
			return Result.Ok;
		}

		return result.Error;
	}
	public async Task Logout()
	{
		await this.ClearCache();
		this.Username = string.Empty;
		this.Token    = null;
	}
	public async Task<Result> Register(string username)
	{
		var result = await this._authService.RegisterUser(new RegisterRequest(username));
		if (result.IsSuccess)
		{
			this.Username = username;
			await this.SetUserId(result.Value.Id);
			await this.SendOtp();
			return Result.Ok;
		}
		return result.Error;
	}
	public async Task<Result> SendOtp()
	{
		var result = await this._authService.SendOtp(new SendOtpRequest(this.Username));
		return result;
	}
	public async Task SetToken(string responseAccessToken)
	{
		await this._protectedLocalStorage.SetAsync("token", responseAccessToken);
		this.Token = responseAccessToken;
	}
	public async Task SetUserId(Guid userId)
	{
		this.UserId = userId;
		await this._protectedLocalStorage.SetAsync("userId", userId.ToString());
	}
	public async Task<Result> ValidateOtp(string otp)
	{
		var result = await this._authService.ValidateOtp(new AuthRequest(this.Username, otp));
		if (result.IsSuccess)
		{
			var response = result.Value;
			await this.SetToken(response.AccessToken);
			await this.SetUserId(result.Value.UserId);
			return Result.Ok;
		}

		return result.Error;
	}
}