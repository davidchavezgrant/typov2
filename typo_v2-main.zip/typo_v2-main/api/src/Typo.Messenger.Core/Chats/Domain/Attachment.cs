using Typo.Kernel.Abstract;
namespace Typo.Messenger.Core.Chats.Domain;
internal sealed class Attachment: Entity<Guid>
{
	private Attachment() {}
	public Attachment(ChatMessage message,
					  Guid        fileId,
					  string      fileName)
	{
		this.Message  = message;
		this.FileId   = fileId;
		this.FileName = fileName;
	}
	public ChatMessage Message  { get; private set; }
	public Guid        FileId   { get; private set; }
	public string      FileName { get; private set; }
	public AttachmentDto ToDto()
	{
		return new AttachmentDto(this.Id,
								 this.Message.Id,
								 this.FileId,
								 this.FileName,
								 null);
	}
}