
import AVFoundation
import AVKit
import SwiftUI

// MARK: - VideoPreviewViewModel

final class VideoAttachmentPreviewViewModel: ObservableObject {
    let attachment: AttachmentViewModel
    let player: AVPlayer
    let localURL: URL

    @Published
    var playheadString = "00:00"

    init(for attachment: AttachmentViewModel, url: URL) {
        self.attachment = attachment
        player = AVPlayer(url: url)
        player.automaticallyWaitsToMinimizeStalling = false
        localURL = url
        player
            .addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 1), queue: .main)
            { time in
                let timeString = String(format: "%02d:%02d",
                                        Int(time.seconds / 60),
                                        Int(time.seconds.truncatingRemainder(dividingBy: 60)))
                print(timeString)
                DispatchQueue.main.async {
                    self.playheadString = timeString
                }
            }
    }
}
