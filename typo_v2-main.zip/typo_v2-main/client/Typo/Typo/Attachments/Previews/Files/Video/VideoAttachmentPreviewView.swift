
import AVFoundation
import AVKit
import Quartz
import SwiftUI

// MARK: - VideoPreview

struct VideoAttachmentPreviewView: View {
    @ObservedObject
    var viewModel: VideoAttachmentPreviewViewModel

    init(viewModel: VideoAttachmentPreviewViewModel) {
        self.viewModel = viewModel
    }

    func getPlayer() -> some View {
        AVPlayerView(player: viewModel.player)
            .onTapGesture {
                showQuickLookPanel()
            }
    }

    private let quickLookController = QuickLookController()

    func showQuickLookPanel() {
        if let panel = QLPreviewPanel.shared() {
            quickLookController.previewItems = [viewModel.localURL]
            panel.dataSource = quickLookController
            panel.makeKeyAndOrderFront(self)
        }
    }

    private func togglePlayback() {
        if viewModel.player.timeControlStatus == .paused {
            viewModel.player.play()
        } else {
            viewModel.player.pause()
        }
    }

    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(.clear)
                .frame(width: 285, height: 171)
                .background(getPlayer().frame(width: 285, height: 171))
                .cornerRadius(16)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .inset(by: 0.5)
                        .stroke(Color(red: 0.1, green: 0.1, blue: 0.1).opacity(0.1), lineWidth: 1)
                )

            HStack(alignment: .top, spacing: 10) {
                Text(viewModel.playheadString)
                    .font(Font.custom("SF Mono", size: 12))
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color.white)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(Color(red: 0.1, green: 0.1, blue: 0.1).opacity(0.5))
            .cornerRadius(100)
        }
        .frame(width: 285, height: 171)
    }
}
