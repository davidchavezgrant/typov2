#!/bin/bash
cd ..
dotnet ef migrations add $1  --context AppIdentityDbContext --startup-project ../Typo.Web.Api