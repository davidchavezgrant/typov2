namespace Typo.Identity.Core.Otp.Model;
public class PhoneNumber
{
	private readonly string _number;
	public           string Value => this._number;

	public PhoneNumber(string number)
	{
		this._number = number;
	}

	public bool IsValid()
	{
		// Check for null, empty, or whitespace
		if (string.IsNullOrWhiteSpace(this._number))
			return false;

		int digitCount = 0;
		foreach (char ch in this._number)
		{
			if (char.IsDigit(ch))
			{
				digitCount++;
			}
			else if (!(ch == '+' || ch == '-' || ch == ' ' || ch == '(' || ch == ')'))
			{
				// Invalid character
				return false;
			}
		}

		// Check digit count is within a reasonable range (e.g., 10 to 15)
		return digitCount >= 10 && digitCount <= 15;
	}
}