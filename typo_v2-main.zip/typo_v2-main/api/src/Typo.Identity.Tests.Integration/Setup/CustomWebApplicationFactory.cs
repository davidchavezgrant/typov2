using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Testcontainers.PostgreSql;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Core.Otp.TextMessageSender;
using Typo.Identity.Core.Users;
namespace Typo.Identity.Tests.Integration.Setup;
public class CustomWebApplicationFactory<TStartup>: WebApplicationFactory<TStartup>, IAsyncLifetime where TStartup: class
{
	private readonly PostgreSqlContainer _postgres = new PostgreSqlBuilder().WithImage("postgres:15-alpine")
																			.WithDatabase(Guid.NewGuid().ToString())
																			.Build();
	public async Task InitializeAsync()
	{
		await this._postgres.StartAsync();
		this.ClearDatabase();
	}

	internal AppIdentityDbContext CreateScopedDbContext()
	{
		var scope          = this.Services.CreateScope();
		var scopedServices = scope.ServiceProvider;
		return scopedServices.GetRequiredService<AppIdentityDbContext>();
	}

	public Task DisposeAsync()
	{
		return this._postgres.DisposeAsync().AsTask();
	}
	protected override void ConfigureWebHost(IWebHostBuilder builder)
	{
		builder.ConfigureTestServices(services =>
									  {
										  this.UseMockEmailSender(services);
										  this.UseMockTextMessageSender(services);
										  this.UseTestContainerDb(services);
									  });
	}

	public void UseTestContainerDb(IServiceCollection services)
	{
		services.RemoveAll(typeof(DbContextOptions<AppIdentityDbContext>));
		services.AddDbContext<AppIdentityDbContext>(options => options.UseNpgsql(this._postgres.GetConnectionString()));
	}

	public void UseMockEmailSender(IServiceCollection services)
	{
		services.RemoveAll(typeof(IEmailSender));
		var mockEmailSender = new FakeEmailSender();
		services.AddSingleton<IEmailSender>(mockEmailSender);
	}

	public void UseMockTextMessageSender(IServiceCollection services)
	{
		services.RemoveAll(typeof(ITextMessageSender));
		var mockTextMessageSender = new FakeTextMessageSender();
		services.AddSingleton<ITextMessageSender>(mockTextMessageSender);
	}

	public void ClearDatabase()
	{
		var builder = new DbContextOptionsBuilder<AppIdentityDbContext>();
		builder.UseNpgsql(this._postgres.GetConnectionString());

		// Ensuring that the database is deleted and then created
		using (var context = new AppIdentityDbContext(builder.Options))
		{
			context.Database.EnsureDeleted();
			context.Database.EnsureCreated();
		}
	}
}