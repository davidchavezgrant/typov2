using Typo.Kernel;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
namespace Typo.Messenger.Core.Profiles.Service;
/// <summary
public interface IProfileService
{
	/// <summary>
	/// Accepts a friend request with the specified friendRequestId for the given myProfileId.
	/// </summary>
	/// <param name="friendRequestId">The unique identifier of the friend request to accept.</param>
	/// <param name="myProfileId">The unique identifier of the user accepting the friend request.</param>
	/// <returns>A task representing the asynchronous operation, which returns a Result object containing the status of the friend request acceptance.</returns>
	Task<Result> AcceptFriendRequest(Guid friendRequestId, Guid myProfileId);

	/// <summary>
	/// Creates a user profile based on the provided request and user ID.
	/// </summary>
	/// <param name="request">The request containing the profile details.</param>
	/// <param name="userId">The ID of the user creating the profile.</param>
	/// <returns>A task that represents the asynchronous operation. The task result contains a Result object with the created UserProfileDto.</returns>
	Task<Result<UserProfileDto>> CreateProfile(CreateProfileRequest request, Guid userId);
	/// <summary>
	/// Deletes a friendship between two users.
	/// </summary>
	/// <param name="myId">The ID of the user initiating the deletion.</param>
	/// <param name="theirId">The ID of the user being deleted from the friendship.</param>
	/// <returns>A Task representing the result of the operation.</returns>
	Task<Result> DeleteFriendship(Guid myId, Guid theirId);

	/// <summary>
	/// Deletes a profile with the specified profileId.
	/// </summary>
	/// <param name="profileId">The unique identifier of the profile to be deleted.</param>
	/// <returns>A <see cref="Task"/> representing the asynchronous operation that returns a <see cref="Result"/>.</returns>
	Task<Result> DeleteProfile(Guid profileId);

	/// <summary>
	/// Retrieves all user profiles.
	/// </summary>
	/// <param name="currentProfileId">The ID of the current user profile.</param>
	/// <returns>A task that represents the asynchronous operation. The task result contains a collection of UserProfileDto objects.</returns>
	Task<UserProfileListDto> GetAllProfiles(Guid currentProfileId);

	/// <summary>
	/// Retrieves the friendships of a user profile.
	/// </summary>
	/// <param name="profileId">The ID of the user profile.</param>
	/// <returns>A <see cref="Task"/> that represents the asynchronous operation.
	/// The <see cref="Result"/> property contains the result of the operation,
	/// which is an <see cref="IEnumerable{T}"/> of <see cref="UserProfileDto"/> objects.</returns>
	Task<Result<IEnumerable<UserProfileDto>>> GetFriendships(Guid profileId);

	/// <summary>
	/// Retrieves the pending friend requests for a given profile.
	/// </summary>
	/// <param name="profileId">The unique identifier of the profile.</param>
	/// <returns>A task that represents the asynchronous operation. The task result contains a <see cref="Result{T}"/> object, where T is <see cref="FriendRequestListDto"/>. The Result object will have the list of pending friend requests if the operation is successful, or an error message if the operation fails.</returns>
	Task<Result<FriendRequestListDto>> GetPendingFriendRequests(Guid profileId);

	/// <summary>
	/// Retrieves the profiles associated with the specified user ID.
	/// </summary>
	/// <param name="userId">The ID of the user.</param>
	/// <returns>A task representing the asynchronous operation. The task result contains a collection of UserProfileDto objects.</returns>
	Task<UserProfileListDto> GetUserProfiles(Guid userId);

	/// <summary>
	/// Rejects a friend request between two profiles.
	/// </summary>
	/// <param name="friendRequestId">The ID of the friend request to reject.</param>
	/// <param name="myProfileId">The ID of the profile rejecting the friend request.</param>
	/// <returns>A Task of type Result representing the result of the operation.</returns>
	Task<Result> RejectFriendRequest(Guid friendRequestId, Guid myProfileId);
	/// <summary>
	/// Sends a friend request from the user with the specified profile ID to the user with the specified userID. </summary>
	/// <param name="from">The profile ID of the user who is sending the friend request.</param>
	/// <param name="to">The ID of the user who will receive the friend request.</param>
	/// <returns> A Task of Result object indicating the success or failure of the friend request operation. </returns>s
	Task<Result> SendFriendRequest(Guid from, Guid to);

	/// <summary>
	/// Updates the profile of a user.
	/// </summary>
	/// <param name="profileId">The profile ID of the user.</param>
	/// <param name="request">The request object containing updated display name.</param>
	/// <returns>A task that represents the asynchronous operation and contains a Result object with UserProfileDto on successful update.</returns>
	Task<Result<UserProfileDto>> UpdateProfile(Guid profileId, UpdateDisplayNameRequest request);

	/// <summary>
	/// Retrieves the user profile based on the given profile ID.
	/// </summary>
	/// <param name="profileId">The unique identifier of the profile to retrieve.</param>
	/// <returns>A Task object representing the asynchronous operation. The task result is a UserProfileDto containing the details of the user profile, or null if the profile does not exist.</returns>
	Task<Result<UserProfileDto>> GetProfile(Guid profileId);

	/// <summary>
	/// Cancels a friend request with the specified request ID for the given active profile ID.
	/// </summary>
	/// <param name="requestId"></param>
	/// <param name="activeProfileId"></param>
	/// <returns></returns>
	Task CancelFriendRequest(Guid requestId, Guid activeProfileId);
}