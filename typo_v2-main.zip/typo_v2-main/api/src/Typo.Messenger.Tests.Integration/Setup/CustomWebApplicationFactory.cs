using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Testcontainers.PostgreSql;
using Typo.Messenger.Core;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Tests.Integration.Setup;
public class CustomWebApplicationFactory<TStartup>: WebApplicationFactory<TStartup>, IAsyncLifetime where TStartup: class
{
	private readonly PostgreSqlContainer _postgres = new PostgreSqlBuilder().WithImage("postgres:15-alpine")
																			.WithDatabase(Guid.NewGuid().ToString())
																			.Build();
	public async Task InitializeAsync()
	{
		await this._postgres.StartAsync();
		Environment.SetEnvironmentVariable("MOCK_AUTH", "TRUE");
		this.ClearDatabase();
	}

	public Task DisposeAsync()
	{
		return this._postgres.DisposeAsync().AsTask();
	}

	public void ClearDatabase()
	{
		var builder = new DbContextOptionsBuilder<MessengerDbContext>();
		builder.UseNpgsql(this._postgres.GetConnectionString());

		// Ensuring that the database is deleted and then created
		using (var context = new MessengerDbContext(builder.Options))
		{
			context.Database.EnsureDeleted();
			context.Database.EnsureCreated();
		}
	}
	protected override void ConfigureWebHost(IWebHostBuilder builder)
	{
		builder.ConfigureTestServices(services =>
									  {
										  this.UseTestContainerDb(services);
									  });
	}

	internal MessengerDbContext CreateScopedDbContext()
	{
		var scope          = this.Services.CreateScope();
		var scopedServices = scope.ServiceProvider;
		return scopedServices.GetRequiredService<MessengerDbContext>();
	}

	public void UseTestContainerDb(IServiceCollection services)
	{
		services.RemoveAll(typeof(DbContextOptions<MessengerDbContext>));
		services.AddDbContext<MessengerDbContext>(options => options.UseNpgsql(this._postgres.GetConnectionString()));
	}
}