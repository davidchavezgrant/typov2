import Foundation
import SwiftUI

class ChatModelInitializer {
    // MARK: Lifecycle

    init(using httpClient: HttpClient) {
        self.httpClient = httpClient
    }

    // MARK: Public

    public func fetchUserProfiles() async throws -> [UserProfile] {
        let whoamiResponse: WhoAmIResponse = try await httpClient.getJson(url: "api/auth/whoami")
        let profileList: UserProfileListResponse = try await httpClient.getJson(url: "api/profiles")
        if profileList.profiles.isEmpty {
            let newProfile = try await createProfile(from: whoamiResponse)
            return [newProfile]
        } else {
            let profiles = profileList.profiles.map {
                UserProfile(id: $0.id, userId: $0.userId, nickname: $0.displayName)
            }
            return profiles
        }
    }

    public func fetchChats(for activeProfileId: UUID, using profileList: [UserProfile]) async throws -> [Chat]
    {
        let chatDtos: ChatListDto = try await httpClient.getJson(url: "api/chats")
        var chats: [Chat] = []
        for chatDto in chatDtos.chats {
            var participants: [UserProfile] = []

            for participant in chatDto.participants {
                let profile = profileList.first {
                    $0.id == participant.userProfileId
                }

                if profile != nil {
                    participants.append(profile!)
                }
            }

            let title = participants.filter {
                $0.id != activeProfileId
            }
            .map(\.nickname)
            .joined(separator: ",")

            let messages: [Message] = chatDto.messages.map {
                Message.fromDto($0)
            }

            let chat = Chat(id: chatDto.id,
                            title: title,
                            participants: participants,
                            messages: messages)
            chats.append(chat)
        }
        return chats
    }

    public func createProfile(from whoamiResponse: WhoAmIResponse) async throws -> UserProfile {
        // Create a profile for the user if they don't have one
        let request = CreateProfileRequest(nickname: whoamiResponse.phoneNumber ?? whoamiResponse.email!)
        let profile: UserProfileDto = try await httpClient.postJson(url: "api/profiles",
                                                                    object: request)

        return UserProfile.fromDto(profile)
    }

    public func fetchAllProfiles() async throws -> [UserProfile] {
        let allProfiles: UserProfileListResponse = try await httpClient.getJson(url: "api/profiles/all")
        return allProfiles.profiles.map {
            UserProfile(id: $0.id, userId: $0.userId, nickname: $0.displayName)
        }
    }

    // MARK: Private

    private let httpClient: HttpClient
}
