import Quartz

// MARK: - QuickLookController

final class QuickLookController: NSObject, QLPreviewPanelDataSource, QLPreviewPanelDelegate {
    var previewItems: [URL] = []

    func numberOfPreviewItems(in _: QLPreviewPanel!) -> Int {
        previewItems.count
    }

    func previewPanel(_: QLPreviewPanel!, previewItemAt index: Int) -> QLPreviewItem! {
        previewItems[index] as QLPreviewItem
    }
}
