using System.Collections;
namespace Typo.Identity.Tests.Integration.Test_Data;
public class ValidPhoneNumbers: IEnumerable<object[]>
{
	public IEnumerator<object[]> GetEnumerator()
	{
		yield return new object[] { "+1234567890" };
		yield return new object[] { "1234567890" };
		yield return new object[] { "(123) 456-7890" };
		yield return new object[] { "+1 234-567-8900" };
		yield return new object[] { "+44 20 7946 0958" }; // UK number
	}
	/// <inheritdoc />
	IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();
}