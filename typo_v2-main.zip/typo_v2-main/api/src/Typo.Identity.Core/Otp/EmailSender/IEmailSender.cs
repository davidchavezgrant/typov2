using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.EmailSender;
internal interface IEmailSender
{
	Task SendOtpEmailAsync(string          email,
						   OneTimePassword otp,
						   int             port = 25);
}