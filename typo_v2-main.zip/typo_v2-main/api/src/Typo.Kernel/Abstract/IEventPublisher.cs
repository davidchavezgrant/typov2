namespace Typo.Kernel.Abstract;
public interface IEventPublisher
{
	void Publish<T>(T      @event) where T: class;
	Task PublishAsync<T>(T @event) where T: class;
}