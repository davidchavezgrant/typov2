using Microsoft.AspNetCore.Http;
using Typo.Messenger.Core.Chats;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
namespace Typo.Messenger.Core.Profiles.Service;
/// <summary>
/// Provides methods for performing chat-related operations over HTTP.
/// </summary>
internal static partial class HttpProfileService
{
	/// <summary>
	/// Accepts a friend request.
	/// </summary>
	/// <param name="requestId">The ID of the friend request.</param>
	/// <param name="db">The database context.</param>
	/// <param name="context">The HTTP context.</param>
	/// <returns>An asynchronous task that represents the operation and returns the result of accepting the friend request as an <see cref="IResult"/>.</returns>
	public static async Task<IResult> AcceptFriendRequest(Guid               requestId,
														  MessengerDbContext db,
														  HttpContext        context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new AcceptFriendRequest(db, requestId, profileId.Value).Execute();
		return result.AsHttpResult("/api/friends/requests/accept");
	}

	public static async Task<IResult> CancelFriendRequest(Guid               requestId,
														  MessengerDbContext db,
														  HttpContext        context)
	{
		var activeProfileId = context.Items["ProfileId"] as Guid?;
		if (activeProfileId is null) return Results.Unauthorized();

		var result = await new CancelFriendRequest(requestId, activeProfileId.Value, db).Execute();
		return result.AsHttpResult("/api/friends/requests/cancel");
	}

	/// <summary>
	/// Creates a new profile using the provided request data.
	/// </summary>
	/// <param name="request">The request data for creating the profile.</param>
	/// <param name="dbContext">The database context for accessing the database.</param>
	/// <param name="httpContext">The HTTP context for accessing user information.</param>
	/// <returns>The result of creating the profile.</returns>
	public static async Task<IResult> CreateProfile(CreateProfileRequest request,
													MessengerDbContext   dbContext,
													HttpContext          httpContext)
	{
		var userId = httpContext.Items["UserId"] as Guid?;
		if (userId is null) return Results.Unauthorized();

		var result = await new CreateProfile(request, userId.Value, dbContext).Execute();
		return result.AsHttpResult("/api/profiles");
	}

	public static async Task<IResult> DeleteFriendship(Guid               profileId,
													   MessengerDbContext dbContext,
													   HttpContext        http)
	{
		var myId = http.Items["ProfileId"] as Guid?;
		if (myId is null) return Results.Unauthorized();

		var result = await new DeleteFriendship(myId.Value, profileId, dbContext).Execute();
		return result.AsHttpResult($"/api/friends/{profileId}");
	}

	/// <summary>
	/// Deletes a profile from the database.
	/// </summary>
	/// <param name="profileId">The ID of the profile to delete.</param>
	/// <param name="dbContext">The database context.</param>
	/// <returns>
	/// An asynchronous task that represents the operation and returns an instance of <see cref="IResult"/>.
	/// The result contains the HTTP response for the deletion operation.
	/// </returns>
	public static async Task<IResult> DeleteProfile(Guid profileId, MessengerDbContext dbContext)
	{
		var result = await new DeleteProfile(profileId, dbContext).Execute();
		return result.AsHttpResult($"/api/profiles/{profileId}");
	}

	/// <summary>
	/// Gets all profiles.
	/// </summary>
	/// <param name="dbContext">The database context.</param>
	/// <returns>An asynchronous task that represents the operation. The task result is an IResult object.</returns>
	public static async Task<IResult> GetAllProfiles(MessengerDbContext dbContext, HttpContext context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var profiles = await new GetAllProfiles(dbContext, profileId.Value).Execute();
		return Results.Ok(profiles);
	}

	/// <summary>
	/// Retrieves the friendships of the specified user profile.
	/// </summary>
	/// <param name="dbContext">The database context.</param>
	/// <param name="http">The HTTP context.</param>
	/// <returns>A task that represents the asynchronous operation. The task result contains an <see cref="IResult"/> object.</returns>
	public static async Task<IResult> GetFriendships(MessengerDbContext dbContext, HttpContext http)
	{
		var profileId = http.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new GetFriendships(dbContext, profileId.Value).Execute();
		return result.AsHttpResult($"/api/friends/{profileId}");
	}

	/// <summary>
	/// Retrieves the pending friend requests for a given profile.
	/// </summary>
	/// <param name="db">The instance of the ChatDbContext.</param>
	/// <param name="context">The instance of the HttpContext.</param>
	/// <returns>An instance of the Task object that represents the asynchronous operation. The task result is of type IResult.</returns>
	public static async Task<IResult> GetPendingFriendRequests(MessengerDbContext db, HttpContext context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new GetPendingFriendRequests(profileId.Value, db).Execute();
		return result.AsHttpResult("/api/friends/requests/pending");
	}

	public static async Task<IResult> GetProfile(Guid profileId, MessengerDbContext dbContext)
	{
		var result = await new GetProfile(dbContext, profileId).Execute();
		return result.AsHttpResult($"/api/profiles/{profileId}");
	}

	/// <summary>
	/// Retrieves profiles associated with a user.
	/// </summary>
	/// <param name="dbContext">The database context.</param>
	/// <param name="http">The HTTP context.</param>
	/// <returns>Returns a task of type IResult.</returns>
	public static async Task<IResult> GetProfiles(MessengerDbContext dbContext, HttpContext http)
	{
		var userId = http.Items["UserId"] as Guid?;
		if (userId is null) return Results.Unauthorized();

		var result = await new GetUserProfiles(dbContext, userId.Value).Execute();
		return Results.Ok(result);
	}

	/// <summary>
	/// Rejects a friend request.
	/// </summary>
	/// <param name="requestId">The ID of the friend request to be rejected.</param>
	/// <param name="db">The instance of <see cref="MessengerDbContext"/> for database operations.</param>
	/// <param name="context">The <see cref="HttpContext"/> for accessing user-related information.</param>
	/// <returns>An instance of <see cref="Task"/> containing the rejection result.</returns>
	public static async Task<IResult> RejectFriendRequest(Guid               requestId,
														  MessengerDbContext db,
														  HttpContext        context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new RejectFriendRequest(db, requestId, profileId.Value).Execute();
		return result.AsHttpResult("/api/friends/requests/reject");
	}

	/// <summary>
	/// Sends a friend request from the current user to the specified profile.
	/// </summary>
	/// <param name="receiverId">The ID of the profile to send a friend request to.</param>
	/// <param name="db">The ChatDbContext instance.</param>
	/// <param name="context">The HttpContext instance.</param>
	/// <returns>An instance of <see cref= "Task"/> representing the asynchronous operation.</returns>
	public static async Task<IResult> SendFriendRequest(Guid               receiverId,
														MessengerDbContext db,
														HttpContext        context)
	{
		var myProfileId = context.Items["ProfileId"] as Guid?;
		if (myProfileId is null)
			return Results.Unauthorized();

		var result = await new SendFriendRequest(myProfileId.Value, receiverId, db).Execute();
		return result.AsHttpResult("/api/profiles");
	}

	/// <summary>
	/// UpdateProfile method updates the display name of a profile identified by profileId.
	/// </summary>
	/// <param name="profileId">The unique identifier of the profile to be updated.</param>
	/// <param name="request">The UpdateDisplayNameRequest object containing the new display name.</param>
	/// <param name="dbContext">The ChatDbContext object used for database operations.</param>
	/// <returns>
	/// Returns a Task of IResult representing the result of the operation.
	/// The result contains the updated profile's information.
	/// </returns>
	public static async Task<IResult> UpdateProfile(Guid                     profileId,
													UpdateDisplayNameRequest request,
													MessengerDbContext       dbContext)
	{
		var result = await new UpdateProfile(profileId, request, dbContext).Execute();
		return result.AsHttpResult($"/api/profiles/{profileId}");
	}
	public static async Task<IResult> ChangeProfilePicture(Guid                        profileId,
														   ChangeProfilePictureRequest request,
														   MessengerDbContext          db)
	{
		var result = await new ChangeProfilePicture(profileId, request, db).Execute();
		return result.AsHttpResult($"/api/profiles/{profileId}/picture");
	}
}
public sealed record ChangeProfilePictureRequest(Guid NewImageId);