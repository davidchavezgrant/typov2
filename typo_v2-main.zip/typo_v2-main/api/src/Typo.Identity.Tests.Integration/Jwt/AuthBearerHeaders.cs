using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Jwt;
public class AuthBearerHeaders: ApiTestBase
{
	/// <inheritdoc />
	public AuthBearerHeaders(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsUnauthorized_When_NoBearerTokenIsProvided()
	{
		var response = await this.ApiClient.PostAsync(IdentityRoutes.TEST_BEARER, null);
		response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
	}

	[Fact]
	public async Task ReturnsOk_When_BearerTokenIsProvided()
	{
		// Arrange
		var request = new RegisterRequest("dgrant1998@gmail.com");
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(request.Username));
		string  code        = FakeEmailSender.SentCodes[request.Username].Value;
		var     otpRequest  = new AuthRequest(request.Username, code);
		var     jwtResponse = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, otpRequest);
		var     jwt         = await jwtResponse.Content.ReadFromJsonAsync<AuthResponse>();
		string? token       = jwt?.AccessToken;

		//Act
		this.ApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
		var response = await this.ApiClient.PostAsync(IdentityRoutes.TEST_BEARER, null);

		// Assert
		response.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Fact]
	public async Task ReturnsCorrectUserId_When_BearerTokenIsProvided()
	{
		// Arrange
		var request = new RegisterRequest("dgrant1998@gmail.com");
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(request.Username));
		string  code        = FakeEmailSender.SentCodes[request.Username].Value;
		var     otpRequest  = new AuthRequest(request.Username, code);
		var     jwtResponse = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, otpRequest);
		var     jwt         = await jwtResponse.Content.ReadFromJsonAsync<AuthResponse>();
		string? token       = jwt?.AccessToken;
		token.Should().NotBeNullOrWhiteSpace();

		//Act
		this.ApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
		var response = await this.ApiClient.GetAsync(IdentityRoutes.WHOAMI);
		var result   = await response.Content.ReadFromJsonAsync<WhoAmIResponse>();

		// Assert
		result?.PhoneNumber.Should().BeNullOrEmpty();

		result?.Email.Should().Be(request.Username);

		result?.UserId.Should().Be(jwt?.UserId.ToString());
	}

	[Fact]
	public async Task ReturnsUnauthorized_When_BearerTokenIsInvalid()
	{
		this.ApiClient.DefaultRequestHeaders.Authorization =
			new AuthenticationHeaderValue("Bearer",
										  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c");
		var response = await this.ApiClient.PostAsync(IdentityRoutes.TEST_BEARER, null);

		// Assert
		response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
	}
}