import SwiftUI
struct ProfileView: View {
    // MARK: Lifecycle

    init(profile: UserProfile) {
        self.profile = profile
        _usernameInput = State(initialValue: profile.nickname ?? "")
    }

    // MARK: Public

    public var body: some View {
        Text("Profile View")
        Text(profile.nickname ?? "No profile selected")
        TextField("Username", text: $usernameInput)
        Button("Update") {
            model.updateUsername(usernameInput)
        }
    }

    // MARK: Internal

    @EnvironmentObject
    var model: ChatModel
    @ObservedObject
    var profile: UserProfile
    @State
    var usernameInput = ""
}
