namespace Typo.Identity.Core.Users;
internal interface IUserRepository
{
	Task<User?> CreateUserAsync(User              user);
	Task<User?> GetUserByPhoneNumberAsync(string  phoneNumber);
	Task<User?> GetUserByEmailAddressAsync(string emailAddress);
	Task<bool>  DeleteUserAsync(User              user);
	Task<User?> GetUserByUserId(Guid              userId);
	Task        UpdateUser(User                   user);
}