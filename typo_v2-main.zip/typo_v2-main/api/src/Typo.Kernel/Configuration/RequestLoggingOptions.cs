namespace Typo.Kernel.Configuration;
public sealed class RequestLoggingOptions
{
	public const string SECTION_NAME = "RequestLogging";
	public       string RequestMaxLength   { get; set; } = string.Empty;
	public       string ResponseMaxLength  { get; set; } = string.Empty;
	public       bool   ShouldLogRequests  { get; set; }
	public       bool   ShouldLogResponses { get; set; }
}