using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
class GetProfile
{
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _profileId;
	public GetProfile(MessengerDbContext dbContext, Guid profileId)
	{
		this._dbContext = dbContext;
		this._profileId = profileId;
	}
	public async Task<Result<UserProfileDto>> Execute()
	{
		{
			var profile = await this._dbContext.Profiles.FirstOrDefaultAsync(p => p.Id == this._profileId);
			if (profile is null) return Error.NotFound("Profile not found");

			return profile!.ToDto();
		}
	}
}