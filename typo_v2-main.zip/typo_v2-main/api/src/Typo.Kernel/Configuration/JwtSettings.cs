namespace Typo.Kernel.Configuration;
public sealed record JwtSettings
{
	public const string SECTION_NAME = "Jwt";
	public       string Audience                   { get; set; } = string.Empty;
	public       string AccessTokenExpiryInSeconds { get; set; } = string.Empty;
	public       string RefreshTokenExpiryInDays   { get; set; } = string.Empty;
	public       string Issuer                     { get; set; } = string.Empty;
	public       string SecurityKey                { get; set; } = string.Empty;
}