#pragma warning disable CS8603
	namespace Typo.Kernel.Abstract;
	public abstract class EntityId<TId>: ValueObject
	{
		public TId Value { get; }

		protected EntityId(TId value)
		{
			if (value == null)
			{
				throw new ArgumentNullException(nameof(value));
			}
			this.Value = value;
		}

		public override IEnumerable<object> GetEqualityComponents()
		{
			yield return this.Value;
		}
	}