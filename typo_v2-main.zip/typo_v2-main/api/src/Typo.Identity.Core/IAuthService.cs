using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Users;
using Typo.Kernel;
namespace Typo.Identity.Core;
public interface IAuthService
{
	Task<Result<User>>                  RegisterUser(RegisterRequest request);
	Task<Result<User>>                  DeleteUser(Guid              userId);
	Task<Result>                        SendOtp(SendOtpRequest       request);
	Task<Result<AuthResponse>>          ValidateOtp(AuthRequest      request);
	Task<Result<ValidateTokenResponse>> ValidateToken(string         token);
	Result<string>                      RefreshToken(string          token);
	Task<Result<WhoAmIResponse>>        WhoAmI(string                token);
}