using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
namespace Typo.Messenger.Core.Profiles.Service;
internal class ProfileService: IProfileService
{
	private readonly IDbContextFactory<MessengerDbContext> _dbContextFactory;
	public ProfileService(IDbContextFactory<MessengerDbContext> dbContextFactory)
	{
		this._dbContextFactory = dbContextFactory;
	}
	public async Task<Result> AcceptFriendRequest(Guid friendRequestId, Guid myProfileId)
		=> await new AcceptFriendRequest(this._dbContextFactory.CreateDbContext(), friendRequestId, myProfileId).Execute();

	public async Task<Result<UserProfileDto>> CreateProfile(CreateProfileRequest request, Guid userId)
		=> await new CreateProfile(request, userId, this._dbContextFactory.CreateDbContext()).Execute();

	public async Task<Result> DeleteFriendship(Guid myId, Guid theirId)
		=> await new DeleteFriendship(myId, theirId, this._dbContextFactory.CreateDbContext()).Execute();

	public async Task<Result> DeleteProfile(Guid profileId)
		=> await new DeleteProfile(profileId, this._dbContextFactory.CreateDbContext()).Execute();

	public async Task<UserProfileListDto> GetAllProfiles(Guid currentProfileId)
		=> await new GetAllProfiles(this._dbContextFactory.CreateDbContext(), currentProfileId).Execute();

	public async Task<Result<IEnumerable<UserProfileDto>>> GetFriendships(Guid profileId)
		=> await new GetFriendships(this._dbContextFactory.CreateDbContext(), profileId).Execute();

	public async Task<Result<FriendRequestListDto>> GetPendingFriendRequests(Guid profileId)
		=> await new GetPendingFriendRequests(profileId, this._dbContextFactory.CreateDbContext()).Execute();

	public async Task<Result> RejectFriendRequest(Guid friendRequestId, Guid myProfileId)
		=> await new RejectFriendRequest(this._dbContextFactory.CreateDbContext(), friendRequestId, myProfileId).Execute();

	public async Task<Result> SendFriendRequest(Guid from, Guid to)
		=> await new SendFriendRequest(from, to, this._dbContextFactory.CreateDbContext()).Execute();

	public async Task<Result<UserProfileDto>> UpdateProfile(Guid profileId, UpdateDisplayNameRequest request)
		=> await new UpdateProfile(profileId, request, this._dbContextFactory.CreateDbContext()).Execute();
	public async Task<UserProfileListDto> GetUserProfiles(Guid userId)
		=> await new GetUserProfiles(this._dbContextFactory.CreateDbContext(), userId).Execute();

	/// <inheritdoc />
	public async Task<Result<UserProfileDto>> GetProfile(Guid profileId)
		=> await new GetProfile(this._dbContextFactory.CreateDbContext(), profileId).Execute();
	/// <inheritdoc />
	public async Task CancelFriendRequest(Guid requestId, Guid activeProfileId)
		=> await new CancelFriendRequest(requestId, activeProfileId, this._dbContextFactory.CreateDbContext()).Execute();
}