
// MARK: - ApiError

struct ApiError: Decodable, Error {
    let type: String
    let title: String
    let status: Int
    let detail: String
    let instance: String
}

struct EmptyBody: Encodable, Decodable {}
