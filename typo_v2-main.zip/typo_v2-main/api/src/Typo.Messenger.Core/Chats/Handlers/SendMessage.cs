using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Kernel.Abstract;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class SendMessage
{
	private readonly MessengerDbContext _dbContext;
	private readonly SendMessageRequest _request;
	private readonly IEventPublisher    _publisher;
	public SendMessage(MessengerDbContext dbContext,
					   SendMessageRequest request,
					   IEventPublisher    publisher)
	{
		this._dbContext = dbContext;
		this._request   = request;
		this._publisher = publisher;
	}

	public async Task<Result<ChatMessageDto>> Execute()
	{
		var chat = await this._dbContext.Chats.Include(x => x.Participants)
							 .Include(x => x.Messages)
							 .FirstOrDefaultAsync(x => x.Id == this._request.ChatId);

		var participant = chat.Participants.FirstOrDefault(x => x.UserProfileId == this._request.SenderId);

		var artifact = chat.SendMessage(participant, this._request.Text, this._request.SentAt);

		await this._dbContext.SaveChangesAsync();

		if (chat.Messages.Count == 1)
		{
			var participants = chat.Participants.Select(x => x.UserProfileId);
			var @event = new ChatCreated(chat.Id, participants);
			await this._publisher.PublishAsync(@event);
		}
		else
		{
			var @event = new MessageSent(artifact.Id,
										 artifact.Chat.Id,
										 artifact.Sender.UserProfileId,
										 artifact.Text);
			await this._publisher.PublishAsync(@event);
		}
		return artifact.ToDto();
	}
}