enum Config {
    static var baseUrl = "http://localhost:6080/"
}

// MARK: - DisplayConstants

enum DisplayConstants {
    static let iconSize: CGFloat = 18.0
    static let largeButtonHeight = 52.0
    static let feedBubbleMaxWidth: CGFloat = 285
    static let artifactPageArtifactMaxWidth: CGFloat = 301
    static let defaultFeedBottomPadding: CGFloat = 8
    static let defaultFont = NSFont.systemFont(ofSize: 17.0)

    static let minHitBoxSize = CGSize(width: 44.0, height: 44.0)
    static let smallImageSize = CGSize(width: 22.0, height: 22.0)
    static let circlularButtonSize = 32.0

    static let distanceToBottom = 42.0
    static var distanceToTop: CGFloat {
        64
    }

    static let horizontalPadding = 24.0
    static let defaultTextPadding = 12.0
    static let minimumGap = 8.0

    static let springAnimationDuration = 0.5
    static let springAnimationDamping = 0.9
    static let springAnimationInitialVelocity = 1.0

    static let defaultParagraphStyle: NSParagraphStyle = {
        let style = NSMutableParagraphStyle()
        style.lineHeightMultiple = 1.0
        style.lineSpacing = 3
        return style
    }()

    private static func getParagraphStyle()
    {}

    static let CompactVideoHeight = 144.0
    static let CompactAudioHeight: CGFloat = 82

    static let pillDisplayTextMaxLength = 22

    static let sentLabelPersistenceInSeconds: Double = 10
    static let nowLabelPersistenceInSeconds = 180.0
}

// MARK: - Constants

enum Constants {
    static let privacyPolicyUrl = URL(string: "https://typo-public-documents.s3.amazonaws.com/PrivacyPolicy.html")!
    static let termsOfUseUrl = URL(string: "https://typo-public-documents.s3.amazonaws.com/TermsOfUse.html")!

    static let UnixTicksPerSecond: UInt64 = 10_000_000 // tick = 100 nanoseconds, a la noda time
    static let ArtifactFilesDirectory = "ArtifactFiles"
    static let SignalRHubRoute = "/rtm/chat"
    static let secondsToLastSignalRReconnectionRetry: UInt64 = 30
    static let loadBufferTime: UInt64 = 50_000_000
    static func ticksToLastSignalRReconnectionRetry() -> UInt64 {
        secondsToLastSignalRReconnectionRetry * UnixTicksPerSecond
    }

    static let systemMessageSenderId = UUID(uuidString: "11111111-1111-1111-1111-111111111111")
}

// MARK: - PillConstants

enum PillConstants {
    static let imageWidth = 16
    static let imageHeight = 16
    static let innerPadding = 4
    static let horizontalPadding = 6
    static let pillHeight = 20
    static let outerPadding = 1 // required so all characters are drawn
    static let borderWidth = 1
    static let stringLength = 1
    static let verticalOffset = -5
    static let baselineOffset = 0
    static let tokenPlaceholderStringLength = 1
    static let tokenSubstitutionCharacter: Character = "$"
}

import Foundation
import SwiftUI

// MARK: - ColorSet

protocol ColorSet {
    associatedtype ColorType

    static var BackgroundBlur: ColorType
    { get }
    static var BackgroundSolid: ColorType
    { get }
    static var BackgroundSolidElevated: ColorType
    { get }
    static var Blue: ColorType
    { get }
    static var Border: ColorType
    { get }
    static var ButtonBGPrimary: ColorType
    { get }
    static var ButtonBGSecondary: ColorType
    { get }
    static var Label: ColorType
    { get }
    static var SecondaryLabel: ColorType
    { get }
    static var Green: ColorType
    { get }
    static var Red: ColorType
    { get }
    static var Shading: ColorType
    { get }
    static var Yellow: ColorType
    { get }
}

// MARK: - Colors

class Colors: ColorSet {
    typealias ColorType = Color
    static let BackgroundBlur = Color("BackgroundBlur")
    static let BackgroundSolid = Color("BackgroundSolid")
    static let backgroundSolidNSColor = NSColor(named: "BackgroundSolid")
    static let BackgroundSolidElevated = Color("BackgroundSolidElevated")
    static let Blue = Color("Blue")
    static let Border = Color("Border")
    static let ButtonBGPrimary = Color("ButtonBGPrimary")
    static let ButtonBGSecondary = Color("ButtonBGSecondary")
    static let Label = Color("Label")
    static let SecondaryLabel = Color("SecondaryLabel")
    static let Green = Color("Green")
    static let Red = Color("Red")
    static let Shading = Color("Shading")
    static let Yellow = Color("Yellow")
}

import Foundation
import SwiftUI

public enum Style {
    public static let backgroundSolidNSColor = NSColor(named: "BackgroundSolid")
    public static let backgroundSolid = Color("BackgroundSolid")
    public static let backgroundElevated = Color("BackgroundElevated")
    public static let backgroundBlur = Color("BackgroundBlur")
    public static let labelPrimary = Color("LabelPrimary")
    public static let labelSecondary = Color("LabelSecondary")
    public static let buttonPrimary = Color("ButtonPrimary")
    public static let buttonSecondary = Color("ButtonSecondary")
    public static let buttonOverflow = Color("ButtonOverflow")
    public static let shading = Color("Shading")
    public static let borderPrimary = Color("BorderPrimary")
    public static let borderSecondary = Color("BorderSecondary")
    public static let red = Color("Red")
    public static let yellow = Color("Yellow")
    public static let blue = Color("Blue")
    public static let bubbleReceivedBG = Color("BubbleReceivedBG")
    public static let bubbleReceivedFG = Color("BubbleReceivedFG")
    public static let bubbleSentBG = Color("BubbleSentBG")
    public static let bubbleSentFG = Color("BubbleSentFG")
    public static let textBG = Color("TextBG")
    public static let textFG = Color("TextFG")
    public static let tokenSentActiveBG = Color("TokenSentActiveBG")
    public static let tokenSentActiveFG = Color("TokenSentActiveFG")
    public static let tokenSentInactiveBG = Color("TokenSentInactiveBG")
    public static let tokenSentInactiveFG = Color("TokenSentInactiveFG")
    public static let tokenReceivedActiveBG = Color("TokenReceivedActiveBG")
    public static let tokenReceivedActiveFG = Color("TokenReceivedActiveFG")
    public static let tokenReceivedInactiveBG = Color("TokenReceivedInactiveBG")
    public static let tokenReceivedInactiveFG = Color("TokenReceivedInactiveFG")
    public static let smallLabelFont = Font.system(size: 12)
    public static let labelFont = Font.system(size: 15)
    public static let smallButtonFont = Font.system(size: 15).weight(.medium)
    public static let bubbleTextBodyFont = Font.system(size: 16)
    public static let bubbleTextTitleFont = Font.system(size: 16)
    public static let chatTitleFont = Font.system(size: 17).weight(.semibold)
    public static let subheadingFont = Font.system(size: 22).weight(.semibold)
}
