using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.FriendRequests;
public class SendFriendRequest: ApiTestBase
{
	public SendFriendRequest(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task CreatesFriendRequest_When_BothUsersExist()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);

		// Act
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);
		using var db           = this.CreateDbContext();
		var       myProfile    = await db.Profiles.Include(p => p.SentRequests).FirstOrDefaultAsync(p => p.Id     == me.Id);
		var       theirProfile = await db.Profiles.Include(p => p.ReceivedRequests).FirstOrDefaultAsync(p => p.Id == them.Id);

		// Assert
		myProfile.Should().NotBeNull();
		theirProfile.Should().NotBeNull();
		myProfile?.SentRequests.Should().HaveCount(1);
		theirProfile?.ReceivedRequests.Should().HaveCount(1);
	}

	[Fact]
	public async Task DoesNotAllowUsersToRequestSelf()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);

		// Act
		await this.ApiClient.PostAsync($"/api/profiles/{me.Id}/friends", null);
		using var db    = this.CreateDbContext();
		var       user1 = await db.Profiles.Include(p => p.SentRequests).FirstOrDefaultAsync(p => p.Id == me.Id);

		// Assert
		user1?.SentRequests.Should().HaveCount(0);
	}

	[Fact]
	public async Task DoesNotCreateDuplicateRequests()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);

		// Act
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);
		using var db    = this.CreateDbContext();
		var       user1 = await db.Profiles.Include(p => p.SentRequests).FirstOrDefaultAsync(p => p.Id     == me.Id);
		var       user2 = await db.Profiles.Include(p => p.ReceivedRequests).FirstOrDefaultAsync(p => p.Id == them.Id);

		// Assert
		user1?.SentRequests.Should().HaveCount(1);
		user2?.ReceivedRequests.Should().HaveCount(1);
	}

	[Fact]
	public async Task DoesNotCreateFriendRequest_When_OneUserDoesNotExist()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);

		// Act
		await this.ApiClient.PostAsync($"/api/profiles/{Guid.NewGuid()}/friends", null);
		using var db    = this.CreateDbContext();
		var       user1 = await db.Profiles.Include(p => p.SentRequests).FirstOrDefaultAsync(p => p.Id     == me.Id);
		var       user2 = await db.Profiles.Include(p => p.ReceivedRequests).FirstOrDefaultAsync(p => p.Id == them.Id);

		// Assert
		user1?.SentRequests.Should().HaveCount(0);
		user2?.ReceivedRequests.Should().HaveCount(0);
	}
}