import Foundation
import SwiftUI

/// A view that displays a preview of a link attachment
public struct LinkPreviewView: View {
    private let viewModel: AttachmentViewModel
    private let data: LinkAttachmentData

    init(for attachment: AttachmentViewModel) {
        viewModel = attachment
        data = attachment.data as! LinkAttachmentData
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 6) {
                favicon()
                siteTitle()
                Spacer()
                visitLinkButton()
            }
            siteDescription()
            siteImage()
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(Style.backgroundSolid)
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16)
            .inset(by: 0.5)
            .stroke(Color(red: 0.1, green: 0.1, blue: 0.1).opacity(0.1), lineWidth: 1))
    }

    @ViewBuilder
    private func siteImage() -> some View {
        if data.metaData.attachedMediaName != nil {
            AsyncImage(url: URL.localFilePath(fileName: data.metaData.attachedMediaName ?? "placeholder",
                                              folderName: viewModel.data.id))
            { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 116, height: 144)
                    .clipped()
            } placeholder: {
                ProgressView()
            }
        }
    }

    private func visitLinkButton() -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text("Visit Link")
                .font(Font.custom("SF Mono", size: 12))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.1))
                .onTapGesture {
                    NSWorkspace.shared.open(data.url)
                }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .cornerRadius(100)
        .overlay(RoundedRectangle(cornerRadius: 100)
            .inset(by: 0.5)
            .stroke(Color(red: 0.1, green: 0.1, blue: 0.1).opacity(0.1), lineWidth: 1))
    }

    @ViewBuilder
    private func siteDescription() -> some View {
        if let description = data.metaData.text {
            Text(description)
                .font(Font.system(size: 17))
                .foregroundColor(Color(red: 0.49, green: 0.49, blue: 0.49))
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .lineLimit(5)
        }
    }

    @ViewBuilder
    private func siteTitle() -> some View {
        if let title = data.metaData.title {
            Text(title)
                .foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.1))
                .font(Font.system(size: 12).weight(.semibold))
                .textSelection(.enabled)
                .lineLimit(2)
        } else {
            Text(data.url.absoluteString)
                .foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.1))
                .font(Font.system(size: 12).weight(.semibold))
                .textSelection(.enabled)
                .lineLimit(2)
        }
    }

    @ViewBuilder
    private func favicon() -> some View {
        if data.metaData.faviconName != nil {
            AsyncImage(url: URL.localFilePath(fileName: data.metaData.faviconName ?? "placeholder",
                                              folderName: viewModel.data.id))
            { image in
                image.resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 24, height: 24)
                    .clipped()
            } placeholder: {
                ProgressView()
            }
            .cornerRadius(16)
            .padding(.top, -10)
        }
    }
}
