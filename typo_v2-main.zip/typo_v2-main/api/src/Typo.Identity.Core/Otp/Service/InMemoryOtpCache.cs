using System.Collections.Concurrent;
using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.Service;
internal sealed class InMemoryOtpCache: IOtpCache
{
	private readonly ConcurrentDictionary<string, OneTimePassword> _cache = new();

	/// <inheritdoc />
	public Task<(bool, OneTimePassword)> TryGetOtpAsync(string email)
		=> Task.FromResult((this._cache.TryGetValue(email, out var otp), otp));

	/// <inheritdoc />
	public Task SetOtpAsync(string email, OneTimePassword oneTimePassword)
		=> Task.FromResult(this._cache.AddOrUpdate(email, oneTimePassword, (_, _) => oneTimePassword));
}