import SwiftUI

// MARK: - Sidebar

struct Sidebar: View {
    @EnvironmentObject
    var model: ChatModel
    @EnvironmentObject
    var authStateProvider: AuthStateProvider
    @State
    var searchText = ""
    @State
    var filteredChats = ChatModel().chats
    @State
    var isSearching = false

    var body: some View {
        TextField("Search", text: $searchText)

        List(isSearching ? $filteredChats : $model.chats, selection: $model.selectedChat)
            { selection in
                NavigationLink(value: selection.wrappedValue) {
                    ListItem(selection: selection.wrappedValue)
                }
                .padding()
            }
            .onChange(of: searchText) {
                filterStreams()
            }
            .navigationTitle(model.selectedChat?.title ?? "")

        HStack {
            Button(action: {
                authStateProvider.logout()
                model.clear()
            }) {
                Image(systemName: "person.crop.circle.badge.xmark")
            }
            Text("Logout")
            Spacer()
        }
    }

    func filterStreams() {
        if searchText.isEmpty {
            filteredChats = model.chats
            isSearching = false
        } else {
            // 2
            filteredChats = model.chats.filter {
                $0.title.localizedCaseInsensitiveContains(searchText) || $0.previewText
                    .localizedCaseInsensitiveContains(searchText)
            }

            isSearching = true
        }
    }
}

// MARK: - ListItem

struct ListItem: View {
    @ObservedObject
    var selection: Chat

    var body: some View {
        listItem(for: selection)
    }

    func listItem(for selection: Chat) -> some View {
        HStack {
            Image(systemName: "person")
                .frame(width: 50, height: 50)
            VStack(alignment: .leading) {
                Text(selection.title)
                    .fontWeight(/*@START_MENU_TOKEN@*/ .bold/*@END_MENU_TOKEN@*/)
                Text(selection.previewText)
                Spacer()
            }
            Spacer()
            VStack {
                Text(selection.timeStampString)
                Spacer()
            }
        }
    }
}
