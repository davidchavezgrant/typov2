using Microsoft.AspNetCore.Components;
namespace Typo.Web.Client.Components.Users;
public partial class User: IDisposable
{
	[Inject]
	UserViewModel ViewModel { get; set; } = null!;
	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender)
		{
			await this.ViewModel.Initialize();
			this.ViewModel.StateHasChanged += this.StateHasChanged;
			this.StateHasChanged();
		}
	}

	/// <inheritdoc />
	public void Dispose()
	{
		this.ViewModel.Dispose();
		this.ViewModel.StateHasChanged -= this.StateHasChanged;
	}
}