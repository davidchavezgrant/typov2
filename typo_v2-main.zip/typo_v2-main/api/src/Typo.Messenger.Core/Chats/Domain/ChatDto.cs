namespace Typo.Messenger.Core.Chats.Domain;
public record ChatListDto(IEnumerable<ChatDto> Chats);
public record ChatDto(Guid Id, IEnumerable<ChatParticipantDto> Participants, IEnumerable<ChatMessageDto> Messages);
public record CreateChatRequest(IEnumerable<Guid> ParticipantIds);
public record ChatParticipantDto(Guid UserProfileId, string Nickname);
public record ChatMessageDto(Guid   Id,
							 Guid   ChatId,
							 Guid   SenderId,
							 string Text,
							 long   SentAt);
public record SendMessageRequest(Guid   ChatId,
								 Guid   SenderId,
								 string Text,
								 long   SentAt);
public sealed record AttachmentRequest(Guid FileId, string FileName);
public sealed record AttachmentDto(Guid    AttachmentId,
								   Guid    MessageId,
								   Guid    FileId,
								   string  FileName,
								   string? Url);
public sealed record AttachmentUrlDto(Guid AttachmentId, string Url);
public sealed record CommentDto(Guid   Id,
								Guid   MessageId,
								Guid   SenderId,
								string Text,
								long   SentAt);
public sealed record AddCommentRequest(string Text);

public sealed record CommentDtoList(IEnumerable<CommentDto> Comments);