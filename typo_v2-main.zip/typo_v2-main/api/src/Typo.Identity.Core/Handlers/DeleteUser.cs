using Typo.Identity.Core.Users;
using Typo.Kernel;
namespace Typo.Identity.Core.Handlers;
class DeleteUser
{
	private readonly IUserService _userService;
	public DeleteUser(IUserService userService)
	{
		this._userService = userService;
	}

	public async Task<Result<User>> Execute(Guid userId)
	{
		var user = await this._userService.GetUser(userId);

		if (user == null)
		{
			return Error.NotFound($"User {userId} not found.");
		}

		var result = await this._userService.DeleteUser(user);

		if (result)
		{
			return user;
		}

		return new Error.Invalid($"Failed to delete user {userId}.");
	}
}