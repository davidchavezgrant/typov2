using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles;
public class FriendshipTests
{
	[Fact]
	public void Create_SetsIds()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		// Act
		var friendship = new Friendship(user1, user2);

		// Assert
		friendship.FirstId.Should().Be(user1.Id);
		friendship.SecondId.Should().Be(user2.Id);
	}
	[Fact]
	public void Create_SetsUsers()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		// Act
		var friendship = new Friendship(user1, user2);

		// Assert
		friendship.First.Should().Be(user1);
		friendship.Second.Should().Be(user2);
	}

	[Fact]
	public void Create_ThrowsException_When_FirstUserIsNull()
	{
		// Arrange
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		// Act & Assert
		Assert.Throws<ArgumentNullException>(() => new Friendship(null!, user2));
	}

	[Fact]
	public void Create_ThrowsException_When_SecondUserIsNull()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");

		// Act & Assert
		Assert.Throws<ArgumentNullException>(() => new Friendship(user1, null!));
	}

	[Fact]
	public void Create_ThrowsException_When_UsersAreTheSame()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");

		// Act & Assert
		Assert.Throws<ArgumentException>(() => new Friendship(user1, user1));
	}
}