using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public class DeleteFriendship
{
	[Fact]
	public void DeleteNonExistentFriendship_ShouldNotThrowError()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		// Act & Assert
		user1.Invoking(u => u.DeleteFriendship(user2)).Should().NotThrow();
	}

	[Fact]
	public void DeleteFriendship_ChangesStatusToRemoved_WhenSenderDeletes()
	{
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		user1.SendFriendRequest(user2);
		user2.AcceptFriendRequest(user1);
		user1.DeleteFriendship(user2);

		var request  = user1.SentRequests.FirstOrDefault(r => r.ReceiverId   == user2.Id);
		var request2 = user2.ReceivedRequests.FirstOrDefault(r => r.SenderId == user1.Id);

		request.Should().NotBeNull();
		request2.Should().NotBeNull();
		request!.Status.Should().Be(FriendRequestStatus.REMOVED);
		request2!.Status.Should().Be(FriendRequestStatus.REMOVED);
	}

	[Fact]
	public void DeleteFriendship_ChangesStatusToRemoved_WhenReceiverDeletes()
	{
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		user1.SendFriendRequest(user2);
		user2.AcceptFriendRequest(user1);
		user2.DeleteFriendship(user1);

		var request  = user1.SentRequests.FirstOrDefault(r => r.ReceiverId   == user2.Id);
		var request2 = user2.ReceivedRequests.FirstOrDefault(r => r.SenderId == user1.Id);

		request.Should().NotBeNull();
		request2.Should().NotBeNull();
		request!.Status.Should().Be(FriendRequestStatus.REMOVED);
		request2!.Status.Should().Be(FriendRequestStatus.REMOVED);
	}
}