using System.Net.Http.Headers;
using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Core.Users;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Users;
public class DeleteUser: ApiTestBase
{
	/// <inheritdoc />
	public DeleteUser(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task RemovesUser_When_UserExists()
	{
		await this.Authorize();
		var createUserRequest = new RegisterRequest("example@example.com");
		var result            = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, createUserRequest);
		var user              = await result.Content.ReadFromJsonAsync<User>();
		user.Id.Should().NotBeEmpty();

		// Act
		using var dbContext    = this.CreateDbContext();
		var       initialCount = await dbContext.Users.CountAsync();
		await this.ApiClient.DeleteAsync(IdentityRoutes.USER + "/" + user.Id);
		var finalCount = await dbContext.Users.CountAsync();

		finalCount.Should().Be(initialCount - 1);

		var userById    = dbContext.Users.FirstOrDefault(u => u.Id    == user.Id);
		var userByEmail = dbContext.Users.FirstOrDefault(u => u.Email == user.Email);

		// Assert
		userById.Should().BeNull();
		userByEmail.Should().BeNull();
	}

	[Fact]
	public async Task DoesNotRemoveUser_When_UserDoesNotExist()
	{
		using var dbContext = this.CreateDbContext();

		// Arrange
		var initialCount = dbContext.Users.Count();

		// Act
		await this.ApiClient.DeleteAsync(IdentityRoutes.USER + "/" + Guid.NewGuid());
		var finalCount = dbContext.Users.Count();

		finalCount.Should().Be(initialCount);

		var userById = dbContext.Users.FirstOrDefault(u => u.Id == Guid.NewGuid());

		// Assert
		userById.Should().BeNull();
	}

	async Task Authorize()
	{
		var request = new RegisterRequest("dgrant1998@gmail.com");
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(request.Username));
		string  code        = FakeEmailSender.SentCodes[request.Username].Value;
		var     otpRequest  = new AuthRequest(request.Username, code);
		var     jwtResponse = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, otpRequest);
		var     jwt         = await jwtResponse.Content.ReadFromJsonAsync<AuthResponse>();
		string? token       = jwt?.AccessToken;
		this.ApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
	}
}