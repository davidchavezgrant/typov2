using DotNetCore.CAP;
using Typo.Kernel.Abstract;
namespace Typo.Web.Api.EventBus;
class CapEventPublisher: IEventPublisher
{
	private readonly ICapPublisher _publisher;
	public CapEventPublisher(ICapPublisher publisher)
	{
		this._publisher = publisher;
	}

	public void Publish<T>(T @event) where T: class
	{
		var eventType = @event.GetType();
		var eventName = eventType.Name;
		this._publisher.PublishAsync(eventName, @event);
	}

	public Task PublishAsync<T>(T @event) where T: class
	{
		var eventType = @event.GetType();
		var eventName = eventType.Name;
		return this._publisher.PublishAsync(eventName, @event);
	}
}