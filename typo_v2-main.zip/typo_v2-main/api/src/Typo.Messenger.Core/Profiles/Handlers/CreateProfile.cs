using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal class CreateProfile
{
	private readonly MessengerDbContext   _dbContext;
	private readonly CreateProfileRequest _request;
	private readonly Guid                 _userId;
	public CreateProfile(CreateProfileRequest request,
						 Guid                 userId,
						 MessengerDbContext   dbContext)
	{
		this._request   = request;
		this._userId    = userId;
		this._dbContext = dbContext;
	}
	public async Task<Result<UserProfileDto>> Execute()
	{
		var existing = await this._dbContext.Profiles.FirstOrDefaultAsync(profile => profile.Nickname == this._request.Nickname);

		if (existing is not null)
			return new Error.Conflict($"Nickname {this._request.Nickname} is already taken");

		var newProfile = new UserProfile(this._userId, this._request.Nickname);
		this._dbContext.Profiles.Add(newProfile);
		await this._dbContext.SaveChangesAsync();
		return newProfile.ToDto();
	}
}