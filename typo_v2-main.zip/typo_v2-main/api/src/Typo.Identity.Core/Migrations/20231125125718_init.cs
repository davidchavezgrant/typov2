﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Typo.Identity.Core.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    EmailConfirmed = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "EmailConfirmed", "PhoneNumber", "PhoneNumberConfirmed" },
                values: new object[,]
                {
                    { new Guid("05910545-5e87-4df3-95c6-40b89dc76dbc"), null, false, "+18885555512", false },
                    { new Guid("65ed1a28-d1b1-41ee-acc9-f02aac19dbba"), null, false, "+18885551212", false },
                    { new Guid("6ea07a96-03a2-4708-a77a-3710a9272cc1"), null, false, "+15555648583", false },
                    { new Guid("9b4d94de-bb70-46d2-a816-dd02fd3cbc2f"), null, false, "+14155553695", false },
                    { new Guid("a36fd2e5-7d70-4f93-b909-567064649aff"), null, false, "+15555228243", false },
                    { new Guid("a4834a3d-0a62-435a-9f9e-8233bc109792"), null, false, "+15554787672", false },
                    { new Guid("acf74bba-0966-4b87-94d5-0aec309226bf"), null, false, "+14085555270", false },
                    { new Guid("b2b8e95d-98f3-4652-9b26-43c278d29c2c"), null, false, "+14085553514", false },
                    { new Guid("b38d8c07-a492-4ed1-9242-f97a32b0566c"), null, false, "+15556106679", false },
                    { new Guid("dd928a25-a90c-4b6e-b7e1-aabce81a4912"), null, false, "+15557664823", false },
                    { new Guid("fdcbbdb4-25eb-45a4-9bce-7004709779cc"), null, false, "+155570555184", false }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                table: "Users",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_PhoneNumber",
                table: "Users",
                column: "PhoneNumber",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
