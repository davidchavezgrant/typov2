using System.Text;
using Microsoft.Extensions.Options;
using Typo.Kernel.Configuration;
namespace Typo.Web.Api;
internal sealed class RequestLoggingMiddleware
{
	public static async Task EndpointLogging(HttpContext ctx, Func<Task> next)
	{
		// Setup
		var  options            = ctx.RequestServices.GetRequiredService<IOptions<RequestLoggingOptions>>();
		int  requestMaxLength   = 240;
		int  responseMaxLength  = 240;
		bool shouldLogRequests  = true;
		bool shouldLogResponses = true;
		var  logger             = ctx.RequestServices.GetRequiredService<ILogger<RequestLoggingMiddleware>>();

		StringBuilder initialLogMessage = new StringBuilder();

		// Log endpoint metadata
		var    endpoint       = ctx.GetEndpoint();
		string routeName      = endpoint?.DisplayName ?? ctx.Request.Path.ToString();
		var    startTimestamp = DateTime.UtcNow;
		initialLogMessage.AppendLine(string.Format("Executing {0} at {1}", routeName, startTimestamp));

		// Log request body
		if (shouldLogRequests)
		{
			var requestBodyStream = new MemoryStream();
			await ctx.Request.Body.CopyToAsync(requestBodyStream);
			if (requestBodyStream.Length < 5) goto thisMarkerBecauseGuessWhatWeCanDoGoTos;

			requestBodyStream.Seek(0, SeekOrigin.Begin);
			var requestBodyText = new StreamReader(requestBodyStream).ReadToEnd();
			requestBodyText = TrimBodyContent(requestBodyText, requestMaxLength);
			initialLogMessage.AppendLine(string.Format("Request body: {0}", requestBodyText));
			requestBodyStream.Seek(0, SeekOrigin.Begin);
			ctx.Request.Body = requestBodyStream;
		}

	thisMarkerBecauseGuessWhatWeCanDoGoTos:
		logger.LogInformation(initialLogMessage.ToString());
		StringBuilder responseLogMessage = new StringBuilder();

		if (shouldLogResponses)
		{
			// basically a goto lol
			await logResponse();
		}

		// Log response metadata
		var stopTimestamp = DateTime.UtcNow;
		responseLogMessage.AppendLine(string.Format("Finished {0} at {1}", routeName, stopTimestamp));
		logger.LogInformation(responseLogMessage.ToString());
		return;

		/// FUNCTIONS ///
		async Task logResponse()
		{
			// Replace the original response body stream
			var originalResponseBodyStream = ctx.Response.Body;
			using (var responseBodyStream = new MemoryStream())
			{
				// Replace the ctx.Response.Body with our stream
				ctx.Response.Body = responseBodyStream;

				// Execute the rest of the pipeline
				await next();

				// Rewind the MemoryStream before reading
				responseBodyStream.Seek(0, SeekOrigin.Begin);

				// Read the response body from the MemoryStream
				var responseBodyText = await new StreamReader(responseBodyStream).ReadToEndAsync();
				responseBodyText = TrimBodyContent(responseBodyText, responseMaxLength);
				if (shouldLogResponses && !string.IsNullOrWhiteSpace(responseBodyText))
				{
					responseLogMessage.AppendLine(string.Format("Response body: {0}", responseBodyText));
				}
				responseBodyStream.Seek(0, SeekOrigin.Begin);

				// Copy the response body to the original response stream
				await responseBodyStream.CopyToAsync(originalResponseBodyStream);
			}
		}
	}
	private static string TrimBodyContent(string bodyContent, int maxLength)
	{
		if (string.IsNullOrEmpty(bodyContent) || bodyContent.Length <= maxLength)
		{
			return bodyContent;
		}

		return bodyContent.Substring(0, maxLength) + "...";
	}
}