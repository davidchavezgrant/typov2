using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.Service;
internal interface IOtpCache
{
	Task<(bool, OneTimePassword)> TryGetOtpAsync(string email);
	Task                          SetOtpAsync(string    email, OneTimePassword oneTimePassword);
}