using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Typo.Messenger.Tests.Integration")]
[assembly: InternalsVisibleTo("Typo.Messenger.Tests.Unit")]