namespace Typo.Identity.Core.Otp.TextMessageSender;
public sealed record TextMessageSenderDetails
{
	public const string SECTION_NAME = "TextMessageSender";

	public string AccountSid { get; set; } = string.Empty;
	public string AuthToken  { get; set; } = string.Empty;
}