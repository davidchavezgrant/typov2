using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Profiles.Handlers;
class AcceptFriendRequest
{
	private readonly MessengerDbContext _db;
	private readonly Guid               _friendRequestId;
	private readonly Guid               _myProfileId;
	public AcceptFriendRequest(MessengerDbContext db,
							   Guid               friendRequestId,
							   Guid               myProfileId)
	{
		this._db              = db;
		this._friendRequestId = friendRequestId;
		this._myProfileId     = myProfileId;
	}
	public async Task<Result> Execute()
	{
		var myProfile = await this._db.Profiles.Include(p => p.ReceivedRequests)
								  .ThenInclude(x => x.Sender)
								  .Include(p => p.SentRequests)
								  .ThenInclude(x => x.Receiver)
								  .FirstOrDefaultAsync(p => p.Id == this._myProfileId);

		if (myProfile is null)
			return Error.NotFound("Profile not found");

		var request = myProfile.ReceivedRequests.FirstOrDefault(x => x.Id == this._friendRequestId);
		if (request is null)
			return Error.NotFound("Friend request not found");

		myProfile.AcceptFriendRequest(request.Sender);
		await this._db.SaveChangesAsync();
		return Result.Ok;
	}
}