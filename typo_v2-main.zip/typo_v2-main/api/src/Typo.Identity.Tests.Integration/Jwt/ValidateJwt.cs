using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.TextMessageSender;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Jwt;
public class ValidateJwt: ApiTestBase
{
	/// <inheritdoc />
	public ValidateJwt(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsOk_When_JwtIsValid()
	{
		// Arrange
		var username = "+12107921430";
		var request  = new RegisterRequest(username);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		var sendOtpRequest = new SendOtpRequest(username);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, sendOtpRequest);
		var code               = FakeTextMessageSender.SentCodes[username];
		var validateOtpRequest = new AuthRequest(username, code.Value);
		var result             = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, validateOtpRequest);
		var validationResponse = await result.Content.ReadFromJsonAsync<AuthResponse>();
		var jwt                = validationResponse?.AccessToken;

		// Act
		var response = await this.ApiClient.PostAsync(IdentityRoutes.VALIDATE_JWT + "?token=" + jwt, null);

		// Assert
		response.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Fact]
	public async Task ReturnsUnauthorized_When_JwtIsInvalid()
	{
		var response = await this.ApiClient.PostAsync(IdentityRoutes.VALIDATE_JWT + "?token=" + "invalid", null);
		response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
	}
}