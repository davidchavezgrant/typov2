using Typo.Kernel.Abstract;
namespace Typo.Messenger.Core.Profiles.Domain;
internal sealed class UserProfile: Entity<Guid>
{
	private readonly List<UserProfile>   _friendships      = new();
	private readonly List<FriendRequest> _receivedRequests = new();
	private readonly List<FriendRequest> _sentRequests     = new();
	public UserProfile(Guid   userId,
					   string nickname,
					   Guid?  profilePictureId = null)
	{
		if (string.IsNullOrWhiteSpace(nickname))
			throw new ArgumentException("Nickname cannot be empty", nameof(nickname));

		if (userId == Guid.Empty)
			throw new ArgumentException("UserId cannot be empty", nameof(userId));

		this.Id                = Guid.NewGuid();
		this.UserId            = userId;
		this.Nickname          = nickname;
		this.ProfilePictureId = profilePictureId;
	}
	public IReadOnlyCollection<UserProfile>   Friendships       => this._friendships.AsReadOnly();
	public string                             Nickname          { get; private set; }
	public Guid?                              ProfilePictureId { get; private set; }
	public IReadOnlyCollection<FriendRequest> ReceivedRequests  => this._receivedRequests.AsReadOnly();
	public IReadOnlyCollection<FriendRequest> SentRequests      => this._sentRequests.AsReadOnly();
	public Guid                               UserId            { get; private set; }

	public void AcceptFriendRequest(UserProfile requestingUser)
	{
		var request =
			this.ReceivedRequests.FirstOrDefault(request => request.Sender.Id == requestingUser.Id
															&& request.Status == FriendRequestStatus.PENDING);
		if (request is null)
			return;

		request.Accept();
		this._friendships.Add(requestingUser);
		requestingUser._friendships.Add(this);
	}
	public void CancelFriendRequest(UserProfile recipientUser)
	{
		var request =
			this.SentRequests.FirstOrDefault(request => request.Receiver.Id == recipientUser.Id
														&& request.Status   == FriendRequestStatus.PENDING);
		if (request is null)
			return;

		request.Cancel();
	}
	public void DeleteFriendship(UserProfile? friend)
	{
		if (friend is null)
			return;

		var sentRequest = this.SentRequests.FirstOrDefault(request => request.Receiver.Id == friend.Id);
		sentRequest?.Remove();

		var receivedRequest = this.ReceivedRequests.FirstOrDefault(request => request.Sender.Id == friend.Id);
		receivedRequest?.Remove();

		this._friendships.Remove(friend);
		friend._friendships.Remove(this);
	}

	public void RejectFriendRequest(UserProfile requestingUser)
	{
		var request =
			this.ReceivedRequests.FirstOrDefault(request => request.Sender.Id == requestingUser.Id
															&& request.Status == FriendRequestStatus.PENDING);
		if (request is null)
			return;

		request.Reject();
	}

	public void SendFriendRequest(UserProfile receiver)
	{
		// if the receiver is the same as the sender, do nothing
		if (receiver.Id == this.Id)
			return;

		// if the receiver has already sent a pending friend request with the sender, do nothing
		if (this.SentRequests.Any(request => request.Receiver.Id == receiver.Id && request.Status == FriendRequestStatus.PENDING))
			return;

		// if the receiver has already accepted a friend request from the sender, do nothing
		if (this.SentRequests.Any(request => request.Receiver.Id == receiver.Id
											 && request.Status   == FriendRequestStatus.ACCEPTED))
			return;

		var request = new FriendRequest(this, receiver);
		(this._sentRequests).Add(request);
		(receiver._receivedRequests).Add(request);
	}
	public UserProfileDto ToDto() => new(this.Id, this.UserId, this.Nickname);
	public void UpdateDisplayName(string requestNewDisplayName)
	{
		if (string.IsNullOrWhiteSpace(requestNewDisplayName))
			return;

		this.Nickname = requestNewDisplayName;
	}
	public void UpdateProfilePicture(Guid requestNewImageId)
	{
		if (requestNewImageId == Guid.Empty)
			return;

		this.ProfilePictureId = requestNewImageId;
	}
}