using NodaTime;
namespace Typo.Kernel.Abstract;
public abstract record DomainEvent
{
	public Instant Timestamp { get; init; } = SystemClock.Instance.GetCurrentInstant();
}