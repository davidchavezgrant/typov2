using Microsoft.AspNetCore.Components;
using Typo.Messenger.Core.Chats;
using Typo.Messenger.Core.Chats.Domain;
namespace Typo.Web.Client.Components.Chats;
public class ChatListViewModel
{
	private readonly IChatService      _chatService;
	private readonly NavigationManager _navigationManager;
	private readonly ProfileProvider   _profileProvider;
	public ChatListViewModel(NavigationManager navigationManager,
							 IChatService      chatService,
							 ProfileProvider   profileProvider)
	{
		this._navigationManager = navigationManager;
		this._chatService       = chatService;
		this._profileProvider   = profileProvider;
	}
	public IEnumerable<ChatDto> Chats     { get; set; } = new List<ChatDto>();
	public bool                 HasLoaded { get; set; }

	public event Action StateHasChanged = () => {};
	public string GetChatName(ChatDto chat)
	{
		var otherParticipants = chat.Participants.Where(x => x.UserProfileId != this._profileProvider.ActiveProfile?.Id).ToList();
		var names             = otherParticipants.Select(x => x.Nickname).ToList();
		return string.Join(", ", names);
	}
	public async Task Initialize()
	{
		if (this.HasLoaded) return;

		if (this._profileProvider.ActiveProfile is null) return;

		var chats = await this._chatService.GetChats(this._profileProvider.ActiveProfile.Id);
		this.Chats     = chats.Chats;
		this.HasLoaded = true;
		this.StateHasChanged();
	}
	public void NavigateTo(ChatDto chat)
	{
		this._navigationManager.NavigateTo($"/chat/{chat.Id}");
	}
}