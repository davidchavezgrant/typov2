using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class GetPendingFriendRequests
{
	private readonly MessengerDbContext _db;
	private readonly Guid               _profileId;

	public GetPendingFriendRequests(Guid profileId, MessengerDbContext db)
	{
		this._profileId = profileId;
		this._db        = db;
	}
	public async Task<Result<FriendRequestListDto>> Execute()
	{
		var profile = await this._db.Profiles.Include(p => p.ReceivedRequests)
								.ThenInclude(x => x.Sender)
								.Include(p => p.SentRequests)
								.ThenInclude(x => x.Receiver)
								.FirstOrDefaultAsync(p => p.Id == this._profileId);

		if (profile is null) return Error.NotFound("Profile not found");

		var receivedRequests =
			profile.ReceivedRequests.Where(x => x.Status == FriendRequestStatus.PENDING).Select(x => x.ToDto());

		var sentRequests = profile.SentRequests.Where(x => x.Status == FriendRequestStatus.PENDING).Select(x => x.ToDto());

		var allRequests = receivedRequests.Concat(sentRequests);
		return new FriendRequestListDto(allRequests);
	}
}