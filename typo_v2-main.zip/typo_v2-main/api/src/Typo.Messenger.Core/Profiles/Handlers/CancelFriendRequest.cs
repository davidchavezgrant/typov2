using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class CancelFriendRequest
{
	private readonly Guid               _requestId;
	private readonly Guid               _activeProfileId;
	private readonly MessengerDbContext _dbContext;
	public CancelFriendRequest(Guid               requestId,
							   Guid               activeProfileId,
							   MessengerDbContext dbContext)
	{
		this._requestId       = requestId;
		this._activeProfileId = activeProfileId;
		this._dbContext       = dbContext;
	}

	public async Task<Result> Execute()
	{
		var me = await this._dbContext.Profiles.Include(p => p.SentRequests)
						   .ThenInclude(c => c.Receiver)
						   .FirstOrDefaultAsync(p => p.Id == this._activeProfileId);

		if (me is null)
			return Error.NotFound("Profile not found");

		var request = me.SentRequests.FirstOrDefault(x => x.Id == this._requestId);
		if (request is null)
			return Error.NotFound("Friend request not found");

		me.CancelFriendRequest(request.Receiver);
		await this._dbContext.SaveChangesAsync();
		return Result.Ok;
	}
}