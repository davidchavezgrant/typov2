using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.TextMessageSender;
internal interface ITextMessageSender
{
	Task SendOtpTextMessageAsync(string phoneNumber, OneTimePassword otp);
	Task SendInvitationTextMessageAsync(string phoneNumber,
										string senderName,
										string recipientName);
}