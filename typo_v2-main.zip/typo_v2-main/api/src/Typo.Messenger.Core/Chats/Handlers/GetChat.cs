using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class GetChat
{
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _id;
	public GetChat(MessengerDbContext dbContext, Guid id)
	{
		this._dbContext = dbContext;
		this._id        = id;
	}
	public async Task<Result<ChatDto>> Execute()
	{
		var chat = await this._dbContext.Chats.Include(x => x.Messages)
							 .Include(c => c.Participants)
							 .FirstOrDefaultAsync(c => c.Id == this._id);

		if (chat is null)
			return Error.NotFound("Chat not found");

		return chat.ToDto();
	}
}