using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;

namespace Typo.Messenger.Core.Chats
{
	internal sealed class FileUploadService
	{
		private readonly AmazonS3Client _s3Client;
		private readonly string         _bucketName;

		public FileUploadService(IOptions<AmazonS3Options> options)
		{
			_s3Client        = new AmazonS3Client(options.Value.AccessKey, options.Value.SecretKey, options.Value.Region);
			this._bucketName = options.Value.BucketName;
		}

		public async Task<Uri> GetUploadUrl(Guid chatId,
											Guid messageId,
											Guid fileId)
		{
			// Construct a unique S3 object key. You might want to adjust this format.
			string objectKey = $"{chatId}/{messageId}/{fileId}";

			var request = new GetPreSignedUrlRequest
			{
				BucketName = _bucketName,
				Key        = objectKey,
				Verb       = HttpVerb.PUT,
				Expires    = DateTime.UtcNow.AddMinutes(5)
			};

			string presignedUrl = await _s3Client.GetPreSignedURLAsync(request);
			return new Uri(presignedUrl);
		}

		public async Task<Uri?> GetProfilePictureUploadUrl(Guid imageId)
		{
			string objectKey = imageId.ToString();

			var request = new GetPreSignedUrlRequest
			{
				BucketName = _bucketName,
				Key        = objectKey,
				Verb       = HttpVerb.PUT,
				Expires    = DateTime.UtcNow.AddMinutes(5)
			};

			string presignedUrl = await _s3Client.GetPreSignedURLAsync(request);
			return new Uri(presignedUrl);
		}
	}
}