namespace Typo.Identity.Core.Users;
internal enum AuthMethod { EMAIL, PHONE }