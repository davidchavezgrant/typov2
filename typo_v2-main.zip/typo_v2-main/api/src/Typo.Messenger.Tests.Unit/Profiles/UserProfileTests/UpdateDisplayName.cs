using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public class UpdateDisplayName
{
	[Fact]
	public void UpdateDisplayName_ShouldChangeNickname()
	{
		// Arrange
		var user    = new UserProfile(Guid.NewGuid(), "OriginalName");
		var newName = "NewName";

		// Act
		user.UpdateDisplayName(newName);

		// Assert
		user.Nickname.Should().Be(newName);
	}

	[Theory]
	[InlineData(null)]
	[InlineData("")]
	public void UpdateDisplayNameToNullOrEmpty_ShouldHandleCorrectly(string newName)
	{
		// Arrange
		var user = new UserProfile(Guid.NewGuid(), "OriginalName");

		// Act
		user.UpdateDisplayName(newName);

		// Assert
		user.Nickname.Should().NotBe(newName);
	}

	[Fact]
	public void UpdateDisplayNameWithSameName_ShouldNotChangeNickname()
	{
		// Arrange
		var user = new UserProfile(Guid.NewGuid(), "OriginalName");

		// Act
		user.UpdateDisplayName("OriginalName");

		// Assert
		user.Nickname.Should().Be("OriginalName");
	}

	[Fact]
	public void UpdateDisplayNameWithWhitespace_ShouldNotChange()
	{
		// Arrange
		var user    = new UserProfile(Guid.NewGuid(), "OriginalName");
		var newName = "   ";

		// Act
		user.UpdateDisplayName(newName);

		// Assert
		user.Nickname.Should().NotBe(newName);
	}
}