using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class GetComments
{
	private readonly Guid               _chatId;
	private readonly Guid               _messageId;
	private readonly MessengerDbContext _db;
	public GetComments(Guid               chatId,
					   Guid               messageId,
					   MessengerDbContext db)
	{
		this._chatId    = chatId;
		this._messageId = messageId;
		this._db        = db;
	}

	public async Task<Result<CommentDtoList>> Execute()
	{
		var chat = await this._db.Chats
							 .Include(c => c.Messages)
							 .ThenInclude(m => m.Comments)
							 .FirstOrDefaultAsync(c => c.Id == this._chatId);

		if (chat is null) return Error.NotFound("Chat not found");

		var message = chat.Messages.FirstOrDefault(m => m.Id == this._messageId);

		if (message is null) return Error.NotFound("Message not found");

		var comments = message.Comments.Select(c => c.ToDto());

		return new CommentDtoList(comments);
	}
}