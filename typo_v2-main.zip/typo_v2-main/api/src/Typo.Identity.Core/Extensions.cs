using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Core.Otp.Service;
using Typo.Identity.Core.Otp.TextMessageSender;
using Typo.Identity.Core.Users;
using Typo.Kernel;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core;
public static class Extensions
{
	public static IServiceCollection AddTypoIdentityServices(this IServiceCollection services, string? connectionString)
	{
		services.AddDbContext<AppIdentityDbContext>(options => options.UseNpgsql(connectionString));
		services.AddScoped<IUserRepository, AppIdentityDbContext>();
		services.AddScoped<IUserService, UserService>();
		services.AddScoped<IAuthService, AuthService>();
		return services;
	}

	public static IServiceCollection AddOtpServices(this IServiceCollection services)
	{
		services.AddScoped<IOtpService, OtpService>();
		services.AddSingleton<IOtpCache, InMemoryOtpCache>();

		services.AddScoped<IEmailSender, SesEmailSender>();
		services.AddScoped<ITextMessageSender, TwilioTextMessageSender>();

		return services;
	}

	public static IServiceCollection AddFakeOtpServices(this IServiceCollection services)
	{
		services.AddScoped<IOtpService, OtpService>();
		services.AddSingleton<IOtpCache, InMemoryOtpCache>();

		services.AddScoped<IEmailSender, FakeEmailSender>();
		services.AddScoped<ITextMessageSender, FakeTextMessageSender>();

		return services;
	}

	public static void ConfigureOtpServices(this WebApplicationBuilder builder)
	{
		var emailConfig = builder.Configuration.GetSection(EmailSenderDetails.SECTION_NAME);
		builder.Services.Configure<EmailSenderDetails>(emailConfig);

		var textMessageConfig = builder.Configuration.GetSection(TextMessageSenderDetails.SECTION_NAME);
		builder.Services.Configure<TextMessageSenderDetails>(textMessageConfig);

		var jwtConfig = builder.Configuration.GetSection(JwtSettings.SECTION_NAME);
		builder.Services.Configure<JwtSettings>(jwtConfig);
	}

	public static IResult ToHttpResult(this Error error, string route)
		=> error.GetType() switch
		   {
			   _ when error is Error.NotFoundError    => Results.NotFound(error.Message),
			   _ when error is Error.Conflict         => Results.Problem(error.Message, route, StatusCodes.Status409Conflict),
			   _ when error is Error.Unauthorized     => Results.Unauthorized(),
			   _ when error is Error.Invalid          => Results.Problem(error.Message, route, StatusCodes.Status400BadRequest),
			   _ when error is Error.ExceptionalError => Results.BadRequest(error.Message),
			   _ when error is Error.NoError          => Results.NoContent(),
			   _                                      => Results.BadRequest("Unknown error.")
		   };
}