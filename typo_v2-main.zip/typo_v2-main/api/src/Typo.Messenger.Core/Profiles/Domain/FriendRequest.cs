using Typo.Kernel.Abstract;
namespace Typo.Messenger.Core.Profiles.Domain;
internal sealed class FriendRequest: Entity<Guid>
{
	private FriendRequest() {}
	public FriendRequest(UserProfile sender, UserProfile receiver)
	{
		this.Sender     = sender;
		this.Receiver   = receiver;
		this.ReceiverId = receiver.Id;
		this.SenderId   = sender.Id;
		this.Status     = FriendRequestStatus.PENDING;
	}
	public UserProfile         Receiver   { get; private set; }
	public Guid                ReceiverId { get; private set; }
	public UserProfile         Sender     { get; private set; }
	public Guid                SenderId   { get; private set; }
	public FriendRequestStatus Status     { get; private set; }

	public void Accept()
	{
		this.Status = FriendRequestStatus.ACCEPTED;
	}

	public void Cancel()
	{
		this.Status = FriendRequestStatus.CANCELLED;
	}

	public void Reject()
	{
		this.Status = FriendRequestStatus.REJECTED;
	}
	public void Remove()
	{
		this.Status = FriendRequestStatus.REMOVED;
	}

	public FriendRequestDto ToDto()
	{
		return new FriendRequestDto(this.Id,
									this.Sender.Id,
									this.Sender.Nickname,
									this.Receiver.Id,
									this.Receiver.Nickname);
	}
}