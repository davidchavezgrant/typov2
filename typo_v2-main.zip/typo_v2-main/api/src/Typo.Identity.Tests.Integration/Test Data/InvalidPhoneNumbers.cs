using System.Collections;
namespace Typo.Identity.Tests.Integration.Test_Data;
public class InvalidPhoneNumbers: IEnumerable<object[]>
{
	public IEnumerator<object[]> GetEnumerator()
	{
		yield return new object[] { "12345" };                // Too short
		yield return new object[] { "12345678901234567890" }; // Too long
		yield return new object[] { "12345abcdef" };          // Contains letters
		yield return new object[] { "123-456-78!0" };         // Contains special characters
		yield return new object[] { "" };                     // Empty string
		yield return new object[] { null };                   // Null
	}
	/// <inheritdoc />
	IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();
}