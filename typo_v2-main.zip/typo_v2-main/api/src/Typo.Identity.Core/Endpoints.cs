using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Options;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.Service;
using Typo.Identity.Core.Users;
using Typo.Kernel.Abstract;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core;
public static class Endpoints
{
	public static IEndpointRouteBuilder MapTypoAuthEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapOtpEndpoints();
		endpoints.MapJwtEndpoints();
		endpoints.MapUserEndpoints();
		endpoints.MapTestEndpoints();
		return endpoints;
	}
	private static IEndpointRouteBuilder MapUserEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapPost(IdentityRoutes.REGISTER,
						  async (RegisterRequest request, IUserService userService) =>
						  {
							  var result = await new Register(userService).Execute(request);
							  return result.As<IResult>(success => Results.Ok(success),
														error => error.ToHttpResult(IdentityRoutes.REGISTER));
						  })
				 .WithOpenApi()
				 .Produces<User>()
				 .WithDisplayName("RegisterUser")
				 .WithSummary("Registers a new user.")
				 .WithDescription(" Registers a new user with either a phone number or an email address");

		endpoints.MapDelete($"{IdentityRoutes.USER}/{{userId}}",
							async ([FromRoute] Guid userId, IUserService userService) =>
							{
								var result = await new DeleteUser(userService).Execute(userId);
								return result.As<IResult>(success => Results.Ok(success),
														  err => err.ToHttpResult($"{IdentityRoutes.USER}/{userId}"));
							})
				 .WithOpenApi()
				 .Produces<User>()
				 .WithDisplayName("DeleteUser")
				 .WithSummary("Deletes a user")
				 .WithDescription("Deletes a user by their id.");

		return endpoints;
	}

	private static void MapOtpEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapPost(IdentityRoutes.SEND_OTP,
						  async (SendOtpRequest request,
								 IOtpService    otp,
								 IUserService   users) =>
						  {
							  var result = await new SendOtp(otp, users).Execute(request);
							  return result.As<IResult>(success => Results.Ok(success),
														error => error.ToHttpResult(IdentityRoutes.SEND_OTP));
						  })
				 .WithOpenApi()
				 .WithDisplayName("SendOtp")
				 .WithSummary("Sends an OTP")
				 .WithDescription("Sends a one time password to an email address or phone number");

		endpoints.MapPost(IdentityRoutes.VALIDATE_OTP,
						  async (AuthRequest           request,
								 IEventPublisher       publisher,
								 IOtpService           otp,
								 IUserService          users,
								 IOptions<JwtSettings> jwtSettings) =>
						  {
							  var result = await new ValidateOtp(publisher,
																 otp,
																 users,
																 jwtSettings).Execute(request);
							  return result.As<IResult>(success => Results.Ok(success),
														error => error.ToHttpResult(IdentityRoutes.VALIDATE_OTP));
						  })
				 .WithOpenApi()
				 .Produces<AuthResponse>()
				 .WithDisplayName("ValidateOtp")
				 .WithSummary("Validates an OTP")
				 .WithDescription("Validates an OTP and returns a JWT if successful.");
	}

	private static void MapJwtEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapPost(IdentityRoutes.VALIDATE_JWT,
						  async ([FromQuery] string    token,
								 IOptions<JwtSettings> jwtSettings,
								 IUserService          userService) =>
						  {
							  var result = await new ValidateJwt(userService, jwtSettings).Execute(token);
							  return result.As(success => Results.Ok(success),
											   error => error.ToHttpResult(IdentityRoutes.VALIDATE_JWT));
						  })
				 .WithOpenApi()
				 .Produces<ValidateTokenResponse>()
				 .WithDisplayName("ValidateToken")
				 .WithSummary("Validates a JWT")
				 .WithDescription("Validates a JWT and returns the userId associated with it.");

		endpoints.MapPost("/api/auth/token/refresh",
						  ([FromQuery] string refreshToken, IOptions<JwtSettings> jwtSettings) =>
						  {
							  var result = new RefreshJwt(jwtSettings).Execute(refreshToken);
							  return result.As(success => Results.Ok(success),
											   error => error.ToHttpResult("/api/auth/token/refresh"));
						  })
				 .WithOpenApi()
				 .Produces<string>()
				 .WithDisplayName("RefreshToken")
				 .WithSummary("Refreshes a JWT")
				 .WithDescription("Uses a refresh JWT token to generate a new access JWT token and returns both.");

		endpoints.MapGet(IdentityRoutes.WHOAMI,
						 async (HttpContext           httpContext,
								IOptions<JwtSettings> jwtSettings,
								IUserService          userService) =>
						 {
							 var token = httpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", string.Empty);
							 var result = await new WhoAmI(userService, jwtSettings).Execute(token);
							 return result.As<IResult>(success => Results.Ok(success),
													   error => error.ToHttpResult(IdentityRoutes.WHOAMI));
						 })
				 .WithOpenApi()
				 .Produces<WhoAmIResponse>()
				 .WithDisplayName("WhoAmI")
				 .WithSummary(" Returns the user associated with a JWT")
				 .WithDescription(" Returns the user associated with a JWT ");
	}

	public static IEndpointRouteBuilder MapTestEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapPost(IdentityRoutes.TEST_BEARER,
						  (HttpContext _) =>
						  {
							  return Results.Ok();
						  })
				 .RequireAuthorization();
		return endpoints;
	}
}