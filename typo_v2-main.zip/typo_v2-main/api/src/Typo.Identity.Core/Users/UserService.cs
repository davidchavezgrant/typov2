using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Users;
internal sealed class UserService: IUserService
{
	private readonly IUserRepository _userRepository;

	public UserService(IUserRepository userRepository)
	{
		this._userRepository = userRepository;
	}

	/// <inheritdoc />
	public async Task<User?> GetUser(PhoneNumber phoneNumber)
	{
		return await this._userRepository.GetUserByPhoneNumberAsync(phoneNumber.Value);
	}

	/// <inheritdoc />
	public async Task<User?> GetUser(EmailAddress emailAddress)
	{
		return await this._userRepository.GetUserByEmailAddressAsync(emailAddress.Value);
	}
	/// <inheritdoc />
	public async Task<User?> CreateUser(EmailAddress emailAddress)
	{
		var user = new User { Id = Guid.NewGuid(), Email = emailAddress.Value };
		await this._userRepository.CreateUserAsync(user);
		return user;
	}
	/// <inheritdoc />
	public async Task<User?> CreateUser(PhoneNumber phoneNumber)
	{
		var user = new User { Id = Guid.NewGuid(), PhoneNumber = phoneNumber.Value };
		await this._userRepository.CreateUserAsync(user);
		return user;
	}

	/// <inheritdoc />
	public async Task<bool> EmailExists(EmailAddress emailAddress)
	{
		var user = await this._userRepository.GetUserByEmailAddressAsync(emailAddress.Value);
		if (user == null)
			return false;

		return true;
	}
	/// <inheritdoc />
	public async Task<bool> PhoneExists(PhoneNumber phoneNumber)
	{
		var user = await this._userRepository.GetUserByPhoneNumberAsync(phoneNumber.Value);
		if (user == null)
			return false;

		return true;
	}
	/// <inheritdoc />
	public async Task<bool> EmailIsConfirmed(EmailAddress emailAddress)
	{
		var user = await this._userRepository.GetUserByEmailAddressAsync(emailAddress.Value);
		if (user == null)
			return false;

		return user.EmailConfirmed;
	}
	/// <inheritdoc />
	public async Task<bool> PhoneIsConfirmed(PhoneNumber phoneNumber)
	{
		var user = await this._userRepository.GetUserByPhoneNumberAsync(phoneNumber.Value);

		if (user == null)
			return false;

		return user.PhoneNumberConfirmed;
	}
	/// <inheritdoc />
	public async Task<bool> DeleteUser(User user)
	{
		return await this._userRepository.DeleteUserAsync(user);
	}
	/// <inheritdoc />
	public async Task<User?> GetUser(Guid userId)
	{
		var user = await this._userRepository.GetUserByUserId(userId);
		return user;
	}
	/// <inheritdoc />
	public async Task UpdateUser(User user)
	{
		await this._userRepository.UpdateUser(user);
	}
}