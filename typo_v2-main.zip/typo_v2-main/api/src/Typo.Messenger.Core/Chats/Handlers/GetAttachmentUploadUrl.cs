using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class GetAttachmentUploadUrl
{
	private readonly MessengerDbContext _db;
	private readonly FileUploadService  _fileUploadService;
	private readonly Guid               _chatId;
	private readonly Guid               _messageId;
	private readonly Guid               _attachmentId;
	public GetAttachmentUploadUrl(MessengerDbContext db,
								  FileUploadService  fileUploadService,
								  Guid               chatId,
								  Guid               messageId,
								  Guid               attachmentId)
	{
		this._db                = db;
		this._fileUploadService = fileUploadService;
		this._chatId            = chatId;
		this._messageId         = messageId;
		this._attachmentId      = attachmentId;
	}

	public async Task<Result<AttachmentUrlDto>> Execute()
	{
		var chat = await this._db.Chats.Include(x => x.Messages)
							 .ThenInclude(x => x.Attachments)
							 .FirstOrDefaultAsync(x => x.Id == this._chatId);

		if (chat is null)
			return Error.NotFound("Chat not found");

		var message = chat.Messages.FirstOrDefault(x => x.Id == this._messageId);

		if (message is null)
			return Error.NotFound("Message not found");

		var attachment = message.Attachments.FirstOrDefault(x => x.Id == this._attachmentId);

		if (attachment is null)
			return Error.NotFound("Attachment not found");

		var url = await this._fileUploadService.GetUploadUrl(this._chatId, this._messageId, attachment.FileId);
		return new AttachmentUrlDto(attachment.Id, url.ToString());
	}
}