import Foundation
import SwiftUI
#if os(macOS)
    import Quartz
#endif

struct ImageAttachmentPreviewView: View {
    let imageUrl: URL

    init(url: URL) {
        imageUrl = url
    }

    private let quickLookController = QuickLookController()

    func showQuickLookPanel() {
        if let panel = QLPreviewPanel.shared() {
            quickLookController.previewItems = [imageUrl]
            panel.dataSource = quickLookController
            panel.makeKeyAndOrderFront(self)
        }
    }

    var body: some View {
        GeometryReader { geometry in
            AsyncImage(url: imageUrl) { image in
                image.resizable()
            } placeholder: {
                ProgressView()
            }
            .aspectRatio(contentMode: .fill)
            .frame(width: geometry.size.width, height: geometry.size.height)
            .cornerRadius(16)
            .clipped()
        }
        .frame(width: 300, height: 300)
        .contentShape(Rectangle())
        .onTapGesture {
            showQuickLookPanel()
        }
    }
}
