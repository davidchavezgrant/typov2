import Foundation

// MARK: - LinkInfoForView

class LinkAttachmentData: AttachmentData {
    init(id: UUID, url: URL, metaData: URLMetadata) {
        self.id = id
        self.url = url

        self.metaData = metaData
    }

    var id: UUID
    var name: String {
        get {
            url.absoluteString
        }
        set {
            print("do not set name for links, name \(newValue) unused")
        }
    }

    let url: URL

    var metaData: URLMetadata

    var displayText: String {
        if let url = URL(string: name), let host = url.host {
            return host
        } else {
            return String(name.prefix(10))
        }
    }
}

import Foundation
import SwiftUI

public struct URLMetadata {
    let type: LinkType
    let title: String?
    let text: String?
    let attachedMediaName: String?
    let faviconName: String?
    let attachedMediaType: MediaType?
    var attachmentSize: CGSize?

    init(type: LinkType,
         title: String?,
         text: String?,
         attachedMediaName: String?,
         faviconName: String?,
         attachedMediaType: MediaType?,
         attachmentSize: CGSize?,
         linkId: UUID)
    {
        self.title = title
        self.text = text
        self.attachedMediaName = attachedMediaName
        self.faviconName = faviconName
        self.type = type
        self.attachedMediaType = attachedMediaType
        self.attachmentSize = attachmentSize

        if let url = URL.localFilePath(fileName: attachedMediaName ?? "", folderName: linkId),
           self.attachmentSize == nil,
           !(self.attachedMediaName?.isEmpty ?? true)
        {
            print("trying to get link attachment size retroactively")
            print("url \(url)")
            if let data = try? Data(contentsOf: url) {
                print("got data")

                if let image = NSImage(data: data) {
                    if image.size.width == 0 || image.size.height == 0 {
                        print("ERROR NIL SIZE")
                    }
                    self.attachmentSize = image.size
                    print("size \(String(describing: self.attachmentSize))")
                }
            }
        }
    }

    init() {
        title = nil
        text = nil
        attachedMediaName = nil
        faviconName = nil
        attachmentSize = nil
        type = .plain
        attachedMediaType = nil
    }
}

// MARK: - LinkType

/// this can be easily extended to support more custom link previewing
public enum LinkType: String, Codable {
    case plain
    case tweet
}
