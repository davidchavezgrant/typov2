using FluentAssertions;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Chats;
public class ChatTests
{
	[Fact]
	public void Create_SetsParticipants()
	{
		var profile1 = new UserProfile(Guid.NewGuid(), "User1");
		var profile2 = new UserProfile(Guid.NewGuid(), "User2");

		var chatRoom = new Chat(new[] { profile1, profile2 });

		var participants = chatRoom.Participants.ToList();
		participants.Select(p => p.UserProfileId).Should().Contain(profile1.Id);
		participants.Select(p => p.UserProfileId).Should().Contain(profile2.Id);
	}

	[Fact]
	public void SendMessage_AddsArtifact()
	{
		var profile1 = new UserProfile(Guid.NewGuid(), "User1");
		var profile2 = new UserProfile(Guid.NewGuid(), "User2");

		var chatRoom = new Chat(new[] { profile1, profile2 });

		chatRoom.SendMessage(chatRoom.Participants.First(), "Hello World!", 121);

		chatRoom.Messages.Should().HaveCount(1);
	}

	[Fact]
	public void SendMessage_AddsArtifactWithCorrectText()
	{
		var profile1 = new UserProfile(Guid.NewGuid(), "User1");
		var profile2 = new UserProfile(Guid.NewGuid(), "User2");

		var chatRoom = new Chat(new[] { profile1, profile2 });

		chatRoom.SendMessage(chatRoom.Participants.First(), "Hello World!", 1122);

		chatRoom.Messages.First().Text.Should().Be("Hello World!");
	}

	[Fact]
	public void SendMessage_AddsArtifactWithCorrectSenderId()
	{
		var profile1 = new UserProfile(Guid.NewGuid(), "User1");
		var profile2 = new UserProfile(Guid.NewGuid(), "User2");

		var chatRoom = new Chat(new[] { profile1, profile2 });

		chatRoom.SendMessage(chatRoom.Participants.First(), "Hello World!", 121);

		chatRoom.Messages.First().Sender.UserProfileId.Should().Be(profile1.Id);
	}
}