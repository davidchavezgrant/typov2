using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.UserProfiles;
public class GetAllUserProfiles: ApiTestBase
{
	/// <inheritdoc />
	public GetAllUserProfiles(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsProfiles_When_ProfilesExist()
	{
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		var result = await this.ApiClient.GetFromJsonAsync<UserProfileListDto>(ChatRoutes.ALL_USER_PROFILES);
		result.Profiles.Count().Should().Be(1);
	}

	[Fact]
	public async Task DoesNotReturnSelf_When_ProfileExists()
	{
		// Arrange
		var me = await this.CreateProfile("user1");
		this.SetActiveProfileHeader(me.Id);
		var result = await this.ApiClient.GetFromJsonAsync<UserProfileListDto>(ChatRoutes.ALL_USER_PROFILES);
		result.Profiles.Count().Should().Be(0);
	}
}