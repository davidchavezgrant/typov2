import SwiftUI

struct ComposeView: View {
    // MARK: Public

    @EnvironmentObject
    public var model: ChatModel
    @EnvironmentObject
    public var authStateProvider: AuthStateProvider

    // MARK: Private

    @State
    private var searchText = ""
    @State
    private var filteredProfiles: [UserProfile] = []
    @State
    private var isSearching = false
    @State
    private var addedProfiles: [UserProfile] = []

    // MARK: Internal

    var body: some View {
        GeometryReader {
            _ in
            VStack {
                if isSearching {
                    filteredSearchResults
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigation) {
                    HStack {
                        Text("To:")
                        addedProfileTokens
                        TextField("", text: $searchText)
                    }
                    .frame(width: 200)
                    Spacer()
                }
            }
            .onChange(of: searchText) {
                filterProfiles()
            }
            .navigationTitle("")
        }
    }

    private var addedProfileTokens: some View {
        ForEach($addedProfiles, id: \.self) {
            profile in
            Button(profile.wrappedValue.nickname) {
                addedProfiles.removeAll {
                    $0.id == profile.id
                }
                filterProfiles()
            }
        }
    }

    private var filteredSearchResults: some View {
        List($filteredProfiles, id: \.self) {
            profile in
            HStack {
                Text(profile.wrappedValue.nickname)
                Button("Add") {
                    addedProfiles.append(profile.wrappedValue)
                    searchText = ""
                    filterProfiles()
                }
            }
        }
    }

    private func filterProfiles() {
        if searchText.isEmpty {
            filteredProfiles = []
            isSearching = false
        } else {
            filteredProfiles = model.allProfiles.filter {
                $0.nickname.localizedCaseInsensitiveContains(searchText) && !addedProfiles.contains($0)
            }
            isSearching = true
        }
    }
}
