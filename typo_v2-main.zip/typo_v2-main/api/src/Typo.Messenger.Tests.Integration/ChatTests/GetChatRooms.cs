using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ChatTests;
public class GetChatRooms: ApiTestBase

/// <inheritdoc />
{
	public GetChatRooms(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsRooms_When_Exist()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		var room = await this.CreateChatRoom(new[] { me.Id, them.Id });

		// Act
		var result = await this.ApiClient.GetFromJsonAsync<IEnumerable<ChatDto>>("/api/chats");

		// Assert
		result.Should().NotBeNull();
		result.Count().Should().Be(1);
	}
}