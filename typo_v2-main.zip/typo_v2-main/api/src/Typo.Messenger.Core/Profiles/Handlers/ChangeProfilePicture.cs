using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Service;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class ChangeProfilePicture
{
	private readonly Guid                        _profileId;
	private readonly ChangeProfilePictureRequest _request;
	private readonly MessengerDbContext          _db;
	public ChangeProfilePicture(Guid                        profileId,
								ChangeProfilePictureRequest request,
								MessengerDbContext          db)
	{
		this._profileId = profileId;
		this._request   = request;
		this._db        = db;
	}

	public async Task<Result> Execute()
	{
		var profile = await this._db.Profiles.FindAsync(this._profileId);

		if (profile is null)
			return Error.NotFound("Profile not found with the provided ID.");

		profile.UpdateProfilePicture(this._request.NewImageId);
		await this._db.SaveChangesAsync();

		return Result.Ok;
	}
}