import AVFoundation
import SwiftUI

public enum PillStatus {
    case new(state: PillSelectionState)
    case sent(selected: Bool)
    case received(selected: Bool)

    public static func lookup(isFromMe: Bool, isActive: Bool) -> PillStatus {
        if isFromMe {
            return .sent(selected: isActive)
        }
        return .received(selected: isActive)
    }

    public var isFromMe: Bool {
        switch self {
        case .sent:
            return true
        default:
            return false
        }
    }
}

// MARK: - ComposePillState

public enum PillSelectionState {
    case focused
    case unselected
    case selected
}
