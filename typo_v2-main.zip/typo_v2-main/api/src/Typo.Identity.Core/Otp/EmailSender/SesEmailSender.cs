using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.EmailSender;
internal sealed class SesEmailSender: IEmailSender
{
	private readonly string? _username;
	private readonly string? _password;
	private readonly string? _host;

	public SesEmailSender(IOptions<EmailSenderDetails> emailSenderOptions)
	{
		this._username = emailSenderOptions.Value.Username;
		this._password = emailSenderOptions.Value.Password;
		this._host     = emailSenderOptions.Value.Host;
	}

	public SesEmailSender(string username,
						  string password,
						  string host)
	{
		this._username = username;
		this._password = password;
		this._host     = host;
	}

	/// <inheritdoc />
	public async Task SendOtpEmailAsync(string          email,
										OneTimePassword oneTimePassword,
										int             port)
	{
		port = 587;
		using var client = new SmtpClient(this._host, port);
		client.Credentials = new NetworkCredential(this._username, this._password);
		client.EnableSsl   = true;

		await client.SendMailAsync("verify@lines.by",
								   email,
								   "Lines Verification Code",
								   $"Your Lines verification code is {oneTimePassword.Value}");
	}
}