using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.UserProfiles;
public class GetUserProfile: ApiTestBase
{
	public GetUserProfile(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsProfile_When_ProfileExists()
	{
		// Arrange
		var request  = new CreateProfileRequest("david");
		var response = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);
		var result   = await response.Content.ReadFromJsonAsync<UserProfileDto>();

		// Act
		var response2 = await this.ApiClient.GetAsync($"{ChatRoutes.USER_PROFILES}/{result.Id}");
		var result2   = await response2.Content.ReadFromJsonAsync<UserProfileDto>();

		// Assert
		result2.Should().NotBeNull();
		result2?.Id.Should().Be(result.Id);
		result2?.DisplayName.Should().Be(request.Nickname);
	}

	[Fact]
	public async Task ReturnsNotFound_When_ProfileDoesNotExist()
	{
		// Arrange
		var request  = new CreateProfileRequest("david");
		var response = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);
		var result   = await response.Content.ReadFromJsonAsync<UserProfileDto>();

		// Act
		var response2 = await this.ApiClient.GetAsync($"{ChatRoutes.USER_PROFILES}/{Guid.NewGuid()}");

		// Assert
		response2.StatusCode.Should().Be(HttpStatusCode.NotFound);
	}
}