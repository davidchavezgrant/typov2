#!/bin/bash
./dropDatabase.sh
./updateDb.sh
