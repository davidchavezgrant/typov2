using System.Security.Claims;
namespace Typo.Web.Api;
public sealed class UserIdValidationMiddleware
{
	private readonly RequestDelegate _next;
	public required  Guid            UserId { get; set; }

	public UserIdValidationMiddleware(RequestDelegate next)
	{
		this._next = next;
	}

	public async Task InvokeAsync(HttpContext httpContext)
	{
		var userIdClaim = httpContext.User.FindFirst(ClaimTypes.NameIdentifier);
		Console.WriteLine($"userIdClaim: {userIdClaim?.Value}");
		if (!Guid.TryParse(userIdClaim?.Value, out var userId))
		{
			httpContext.Response.StatusCode = 401; // Unauthorized
			await httpContext.Response.WriteAsJsonAsync(new { message = "Invalid user ID" });
			Console.WriteLine("Invalid user ID");
			return;
		}

		if (userId == Guid.Empty)
		{
			httpContext.Response.StatusCode = 401;
			await httpContext.Response.WriteAsJsonAsync(new { message = "Invalid user ID" });
			Console.WriteLine("Empty user ID");
			return;
		}

		httpContext.Items["UserId"] =
			userId; // Storing the valid userId into HttpContext.Items to be used further down the pipeline.

		await this._next(httpContext);
	}
}