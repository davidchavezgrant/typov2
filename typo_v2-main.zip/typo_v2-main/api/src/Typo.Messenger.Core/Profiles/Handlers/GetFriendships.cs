using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
class GetFriendships
{
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _profileId;

	public GetFriendships(MessengerDbContext dbContext, Guid profileId)
	{
		this._dbContext = dbContext;
		this._profileId = profileId;
	}
	public async Task<Result<IEnumerable<UserProfileDto>>> Execute()
	{
		var profile =
			await this._dbContext.Profiles.Include(p => p.Friendships).FirstOrDefaultAsync(p => p.Id == this._profileId);

		if (profile is null) return Error.NotFound("Profile not found");

		var friendships = profile.Friendships.Select(f => f.ToDto());
		return new(friendships);
	}
}