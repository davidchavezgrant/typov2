import AVFoundation
import Combine
import Foundation

class Import {
    public static func fileAttachment(from fileUrl: URL) -> AttachmentData {
        let fileId = UUID()
        var copiedBytesCount: UInt64?
        do {
            copiedBytesCount = try Self.copyFileToAppFolder(from: fileUrl, fileId: fileId)
        } catch {
            print("Error copying file to app folder: \(error)")
        }
        // create file info for view AFTER copying file, so that is can get the aspect ratio data as needed
        let fileName = fileUrl.lastPathComponent
        let attachmentData = FileAttachmentData(id: fileId,
                                                sizeInBytes: copiedBytesCount ?? 0,
                                                name: fileName)
        return attachmentData
    }

    private static func copyFileToAppFolder(from sourcePath: URL, fileId: UUID) throws -> UInt64? {
        let fileName = sourcePath.lastPathComponent
        _ = sourcePath.startAccessingSecurityScopedResource()
        let destinationPath = URL.localFilePath(fileName: fileName, folderName: fileId)
        let copiedBytesCount = try Self.copyFile(from: sourcePath, to: destinationPath)
        sourcePath.stopAccessingSecurityScopedResource()
        return copiedBytesCount
    }

    private static func copyFile(from sourcePath: URL, to destinationPath: URL?) throws -> UInt64? {
        let fileAttributes: [FileAttributeKey: Any]? = try FileManager.default.attributesOfItem(atPath: sourcePath.path)

        var copiedBytesCount: UInt64?
        if let attributes: [FileAttributeKey: Any] = fileAttributes {
            if let sizeInBytes = attributes[FileAttributeKey.size] as? UInt64 {
                copiedBytesCount = sizeInBytes
            }
        }

        if let destinationPath = destinationPath {
            try FileManager.default.copyItem(at: sourcePath, to: destinationPath)
        }
        return copiedBytesCount
    }
}
