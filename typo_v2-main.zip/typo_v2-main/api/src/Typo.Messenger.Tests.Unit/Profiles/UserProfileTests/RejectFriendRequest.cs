using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public class RejectFriendRequest
{
	[Fact]
	public void ShouldNotAffectFriendship_When_AcceptedRequestIsRejected()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);
		user2.AcceptFriendRequest(user1);

		// Act
		user2.RejectFriendRequest(user1);

		// Assert
		user1.Friendships.Should().Contain(user2);
		user2.Friendships.Should().Contain(user1);
	}
	[Fact]
	public void DoesNotRemoveRequest()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.RejectFriendRequest(user1);

		// Assert
		user1.SentRequests.Should().NotBeEmpty();
		user2.ReceivedRequests.Should().NotBeEmpty();
	}

	[Fact]
	public void RejectsRequest_WhenCalled()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.RejectFriendRequest(user1);
		var request  = user1.SentRequests.FirstOrDefault(r => r.ReceiverId   == user2.Id);
		var request2 = user2.ReceivedRequests.FirstOrDefault(r => r.SenderId == user1.Id);

		// Assert
		request.Should().NotBeNull();
		request2.Should().NotBeNull();

		request!.Status.Should().Be(FriendRequestStatus.REJECTED);
		request2!.Status.Should().Be(FriendRequestStatus.REJECTED);
	}

	[Fact]
	public void DoesNotAddFriendship_WhenCalled()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.RejectFriendRequest(user1);

		// Assert
		user1.Friendships.Should().NotContain(user2);
		user2.Friendships.Should().NotContain(user1);
	}

	[Fact]
	public void DoesNothing_When_NoMatchingRequestExists()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		var user3 = new UserProfile(Guid.NewGuid(), "User3");
		user1.SendFriendRequest(user2);

		// Act
		Action act = () => user2.RejectFriendRequest(user3);

		// Assert
		act.Should().NotThrow();
		user2.Friendships.Should().NotContain(user1);
		user2.Friendships.Should().NotContain(user3);
		user1.Friendships.Should().NotContain(user2);
		user3.Friendships.Should().NotContain(user2);

		var request = user1.SentRequests.FirstOrDefault(r => r.ReceiverId == user2.Id);
		request.Should().NotBeNull();
		request!.Status.Should().Be(FriendRequestStatus.PENDING); // Assuming the default status is PENDING
	}
}