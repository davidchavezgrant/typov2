namespace Typo.Identity.Tests.Unit;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}