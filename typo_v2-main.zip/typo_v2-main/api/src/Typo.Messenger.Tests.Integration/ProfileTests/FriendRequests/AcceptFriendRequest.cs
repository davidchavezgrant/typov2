using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.FriendRequests;
public class AcceptFriendRequest: ApiTestBase
{
	/// <inheritdoc />
	public AcceptFriendRequest(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task AddsFriendToBothUsers()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);
		this.SetActiveProfileHeader(them.Id);
		var response  = await this.ApiClient.GetFromJsonAsync<FriendRequestListDto>($"/api/friends/requests/pending");
		var requestId = response.Requests.First().Id;

		// Act
		await this.ApiClient.PostAsync($"/api/friends/requests/{requestId}/accept", null);
		using var dbContext   = this.CreateDbContext();
		var       meProfile   = await dbContext.Profiles.Include(p => p.Friendships).FirstOrDefaultAsync(p => p.Id == me.Id);
		var       themProfile = await dbContext.Profiles.Include(p => p.Friendships).FirstOrDefaultAsync(p => p.Id == them.Id);

		// Assert
		meProfile?.Friendships.Count.Should().Be(1);
		themProfile?.Friendships.Count.Should().Be(1);
	}

	[Fact]
	public async Task DoesNotRemoveRequestFromUsers()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);
		this.SetActiveProfileHeader(them.Id);
		var response  = await this.ApiClient.GetFromJsonAsync<FriendRequestListDto>($"/api/friends/requests/pending");
		var requestId = response.Requests.First().Id;

		// Act
		await this.ApiClient.PostAsync($"/api/friends/requests/{requestId}/accept", null);
		using var dbContext = this.CreateDbContext();
		var meProfile = await dbContext.Profiles.Include(p => p.Friendships)
									   .Include(userProfile => userProfile.ReceivedRequests)
									   .Include(userProfile => userProfile.SentRequests)
									   .FirstOrDefaultAsync(p => p.Id == me.Id);
		var themProfile = await dbContext.Profiles.Include(p => p.Friendships)
										 .Include(userProfile => userProfile.SentRequests)
										 .Include(userProfile => userProfile.ReceivedRequests)
										 .FirstOrDefaultAsync(p => p.Id == them.Id);

		// Assert
		meProfile?.ReceivedRequests.Count.Should().Be(0);
		meProfile?.SentRequests.Count.Should().Be(1);
		themProfile?.SentRequests.Count.Should().Be(0);
		themProfile?.ReceivedRequests.Count.Should().Be(1);
	}
}