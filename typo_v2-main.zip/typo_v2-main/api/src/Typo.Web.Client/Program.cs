using Typo.Identity.Core;
using Typo.Kernel.Configuration;
using Typo.Messenger.Core;
using Typo.Web.Client;
using Typo.Web.Client.Components;
using Typo.Web.Client.Components.Chats;
using Typo.Web.Client.Components.Pages;
using Typo.Web.Client.Components.Users;
using Typo.Web.Client.EventBus;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
var identityConnection = builder.Configuration.GetConnectionString("IdentityDb");
var connectionString   = builder.Configuration.GetConnectionString("ChatDb");
var jwtSettings        = builder.Configuration.GetSection("Jwt").Get<JwtSettings>();

builder.Services.AddChatServices(connectionString);
builder.Services.AddScoped<AuthStateProvider>();
builder.Services.AddScoped<ProfileProvider>();
builder.Services.AddTransient<UserViewModel>();
builder.Services.AddTransient<FriendListViewModel>();
builder.Services.AddTransient<ChatListViewModel>();

// Event Bus
builder.Services.AddInProcessEventBus();

// Identity
builder.ConfigureOtpServices();
builder.Services.AddIdentityModuleServices(identityConnection, jwtSettings);
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
	app.UseExceptionHandler("/Error", createScopeForErrors: true);

	// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
	app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();