import Foundation
import SwiftUI

// MARK: - ChatMessage

class ChatMessage: Identifiable, Equatable, Hashable, ObservableObject {
    // MARK: Lifecycle

    init(id: UUID, chatId: UUID, senderId: UUID, title: String, textContent: String, timestamp: Int, attachments: [Attachment])
    {
        self.id = id
        self.chatId = chatId
        self.senderId = senderId
        self.title = title
        self.textContent = textContent
        self.timestamp = timestamp
        self.attachments = attachments
    }

    // MARK: Internal

    let id: UUID
    let chatId: UUID
    let senderId: UUID
    let title: String
    let textContent: String
    let timestamp: Int
    let attachments: [Attachment]

    static func == (lhs: Chat, rhs: Chat) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

// MARK: - Attachment

struct Attachment: Identifiable, Equatable, Hashable {
    // MARK: Lifecycle

    init(id: UUID, artifactId: UUID, fileName: String) {
        self.id = id
        self.artifactId = artifactId
        self.fileName = fileName
    }

    // MARK: Internal

    let id: UUID
    let artifactId: UUID
    let fileName: String

    static func == (lhs: Attachment, rhs: Attachment) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
