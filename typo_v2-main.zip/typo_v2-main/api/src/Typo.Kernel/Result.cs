#pragma warning disable CS8604
#pragma warning disable CS8767
#pragma warning disable CS8602
	namespace Typo.Kernel;
	public sealed class Void
	{
		private Void() {}
		public static readonly Void Default = new();
	}
	public enum ResultState: byte { ERROR, SUCCESS }
	public sealed class Result: Result<Void>
	{
		public static implicit operator Result(Error e) => new(e);
		public static implicit operator Result(Void  _) => new();

		/// <inheritdoc />
		public Result(): base(Void.Default) {}

		/// <inheritdoc />
		public Result(Error e): base(e) {}

		public static Result Success => new();
		public static Result Ok      => new();
	}
	public class Result<TValue>: IEquatable<Result<TValue>>, IComparable<Result<TValue>>
	{
		public readonly  TValue?     Value;
		private readonly ResultState _state;
		private readonly Error?      _error;

		public Result(TValue value)
		{
			this._state = ResultState.SUCCESS;
			this.Value  = value;
			this._error = null;
		}

		public Result(Error e)
		{
			this._state = ResultState.ERROR;
			this._error = e;
			this.Value  = default(TValue);
		}

		public static implicit operator Result<TValue>(TValue value) => new(value);
		public static implicit operator Result<TValue>(Error  e)     => new(e);
		public                          Error Error                  => this._error ?? Error.None;

		public bool HasError          => this._state == ResultState.ERROR;
		public bool IsSuccess         => this._state == ResultState.SUCCESS;
		public bool HasInnerException => this._error is Error.ExceptionalError;

		private string ErrorMessage
			=> string.IsNullOrWhiteSpace(this._error?.Message)? "Error without message" : this._error.Message;

		private Type ErrorType => this._error?.GetType() ?? typeof(Error.NoError);

		public override string ToString()
		{
			if (this.IsSuccess)
				return this.Value?.ToString() ?? "Value is null";

			return $"{this.ErrorType.Name}: {this.ErrorMessage}";
		}

		/*
		 * You could also write this overloaded Equals method in a "more functional way" like this:
		 *
		 *     public bool Equals(Result<T> other) => other.State == this.State
		 *                                   && EqualityComparer<T>.Default.Equals(other.Value, this.Value)
		 *                                   && EqualityComparer<Error>.Default.Equals(other._error, this._error);
		 *
		 * But I think the following is more readable.
		 */
		public bool Equals(Result<TValue> other)
		{
			bool stateIsEqual = other._state == this._state;
			bool valueIsEqual = EqualityComparer<TValue>.Default.Equals(other.Value, this.Value);
			bool errorIsEqual = EqualityComparer<Error>.Default.Equals(other._error, this._error);

			return stateIsEqual && valueIsEqual && errorIsEqual;
		}

		/// <inheritdoc />
		public override bool Equals(object? obj) => obj is Result<TValue> other && this.Equals(other);

		/// <inheritdoc />
		public override int GetHashCode()
		{
			/*
		   // We use a prime number (17) as the initial value and another prime number (31) as the multiplier.
		   // Prime numbers are chosen to minimize hash collisions and ensure a better distribution of hash codes.
		   // The number 31 is used because some compilers can optimize the multiplication into a more efficient shift-and-subtract operation.
		   // This pattern of using prime numbers is a common practice for generating reliable and well-distributed hash codes.
		   */
			int hash = 17;
			hash = hash * 31 + this._state.GetHashCode();
			hash = hash * 31 + EqualityComparer<TValue>.Default.GetHashCode(this.Value!);
			hash = hash * 31 + (this._error?.GetHashCode() ?? 0);
			return hash;
		}

		public static bool operator ==(Result<TValue> a, Result<TValue> b) => a.Equals(b);

		public static bool operator !=(Result<TValue> a, Result<TValue> b) => !(a == b);

		public Result<TOut> Filter<TOut>(Func<TValue, TOut> filter)
		{
			if (this.HasError)
			{
				return new Result<TOut>(this._error);
			}

			var filteredResults = filter(this.Value);
			return new Result<TOut>(filteredResults);
		}

		// This is the same as the sync Filter method,
		// but it's async and I wrote it in a more functional way
		// so that nobody can say I'm not a functional programmer
		// or that C# isn't a functional language.
		public async Task<Result<TOut>> FilterAsync<TOut>(Func<TValue, Task<TOut>> f)
			=> this.HasError? new Result<TOut>(this._error) : new Result<TOut>(await f(this.Value));

		public TOut As<TOut>(Func<TValue, TOut> onSuccess, Func<Error, TOut> onError)
		{
			if (this.HasError)
			{
				return onError(this._error);
			}

			return onSuccess(this.Value);
		}

		/// This is the same as the sync As method, but it's async and I wrote it in a more functional way
		public async Task<TOut> As<TOut>(Func<TValue, Task<TOut>> onSuccess, Func<Error, Task<TOut>> onError)
			=> this.HasError? await onError(this._error) : await onSuccess(this.Value);

		public int CompareTo(Result<TValue> other)
		{
			// If both instances have the same state, we need to compare values or errors
			if (this._state == other._state)
			{
				// If both instances are successful, we need to compare their values
				if (this.IsSuccess)
				{
					return this.CompareValueTo(other);
				}

				return this.CompareErrorTo(other);
			}

			// If states are different, successful results are considered greater than error results
			if (this._state == ResultState.SUCCESS)
			{
				return 1;
			}

			return -1;
		}

		private int CompareErrorTo(Result<TValue> other)
		{
			// If both instances are errors, we compare the hash codes of the errors
			int errorHashCode      = this._error.GetHashCode();
			int otherErrorHashCode = other._error.GetHashCode();
			return errorHashCode.CompareTo(otherErrorHashCode);
		}

		private int CompareValueTo(Result<TValue> other)
		{
			// If the value implements IComparable<T>, we use its CompareTo method
			if (this.Value is IComparable<TValue> comparableValue)
			{
				return comparableValue.CompareTo(other.Value);
			}

			// Otherwise, we compare the hash codes of the values
			int thisHashCode  = this.Value.GetHashCode();
			int otherHashCode = other.Value.GetHashCode();
			return thisHashCode.CompareTo(otherHashCode);
		}

		public static bool operator <(Result<TValue>  a, Result<TValue> b) => a.CompareTo(b) < 0;
		public static bool operator <=(Result<TValue> a, Result<TValue> b) => a.CompareTo(b) <= 0;
		public static bool operator >(Result<TValue>  a, Result<TValue> b) => a.CompareTo(b) > 0;
		public static bool operator >=(Result<TValue> a, Result<TValue> b) => a.CompareTo(b) >= 0;
	}