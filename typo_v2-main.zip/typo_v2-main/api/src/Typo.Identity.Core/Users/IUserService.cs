using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Users;
internal interface IUserService
{
	Task<User?> CreateUser(PhoneNumber   phoneNumber);
	Task<User?> GetUser(PhoneNumber      phoneNumber);
	Task<User?> CreateUser(EmailAddress  emailAddress);
	Task<User?> GetUser(EmailAddress     emailAddress);
	Task<bool>  EmailExists(EmailAddress emailAddress);
	Task<bool>  PhoneExists(PhoneNumber  phoneNumber);

	Task<bool>  EmailIsConfirmed(EmailAddress emailAddress);
	Task<bool>  PhoneIsConfirmed(PhoneNumber  phoneNumber);
	Task<bool>  DeleteUser(User               user);
	Task<User?> GetUser(Guid                  userId);
	Task        UpdateUser(User               user);
}