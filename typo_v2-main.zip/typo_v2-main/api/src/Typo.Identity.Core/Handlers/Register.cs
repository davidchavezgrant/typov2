using Typo.Identity.Core.Otp.Model;
using Typo.Identity.Core.Users;
using Typo.Kernel;
namespace Typo.Identity.Core.Handlers;
public sealed record RegisterRequest(string Username);
class Register
{
	private readonly IUserService _userService;
	public Register(IUserService userService)
	{
		this._userService = userService;
	}
	public async Task<Result<User>> Execute(RegisterRequest request)
	{
		var email = new EmailAddress(request.Username);
		var phone = new PhoneNumber(request.Username);

		if (!email.IsValid() && !phone.IsValid())
		{
			return new Error.Invalid("Invalid username.");
		}

		if (email.IsValid())
		{
			var emailExists = await this._userService.EmailExists(email);
			if (emailExists)
			{
				return new Error.Conflict("Email already registered.");
			}

			var emailUser = await this._userService.CreateUser(email);
			return emailUser;
		}

		var phoneExists = await this._userService.PhoneExists(phone);
		if (phoneExists)
		{
			return new Error.Conflict("Phone number already registered.");
		}
		var phoneUser = await this._userService.CreateUser(phone);
		return phoneUser;
	}
}