using System.Collections.Concurrent;
using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.TextMessageSender;
/// <summary>
/// Shut up, I know.
/// </summary>
internal sealed class FakeTextMessageSender: ITextMessageSender
{
	public static int                                           MessagesSent { get; private set; } = 0;
	public static ConcurrentDictionary<string, OneTimePassword> SentCodes    { get; }              = new();

	/// <inheritdoc />
	public Task SendOtpTextMessageAsync(string phoneNumber, OneTimePassword otp)
	{
		SentCodes[phoneNumber] = otp;
		MessagesSent++;
		return Task.CompletedTask;
	}
	/// <inheritdoc />
	public Task SendInvitationTextMessageAsync(string phoneNumber,
											   string senderName,
											   string recipientName)
		=> throw new NotImplementedException();

	public static void ResetCount()
	{
		SentCodes.Clear();
		MessagesSent = 0;
	}
}