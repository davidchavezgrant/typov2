#!/bin/bash
cd ..
dotnet ef database drop -f --context AppIdentityDbContext --startup-project ../Typo.Web.Api/
