using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.Service;
public interface IOtpService
{
	Task       SendOtpAsync(PhoneNumber    phoneNumberDto);
	Task       SendOtpAsync(EmailAddress   emailAddress);
	Task<bool> VerifyOtpAsync(PhoneNumber  phoneNumberDto,  string otp);
	Task<bool> VerifyOtpAsync(EmailAddress emailAddressDto, string otp);
}