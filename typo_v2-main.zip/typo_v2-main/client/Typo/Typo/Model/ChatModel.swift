import Combine
import Foundation
import SignalRClient
import SwiftUI

// MARK: - ChatModel

@MainActor
class ChatModel: ObservableObject, ChatSubscriber, MessageSubscriber {
    private var authStateProvider: AuthStateProvider
    private var rtc: RtcProvider? = nil
    init(authStateProvider: AuthStateProvider) {
        self.authStateProvider = authStateProvider
    }

    init() {
        authStateProvider = AuthStateProvider()
    }

    @Published
    public var selectedChat: Chat? = nil

    @Published
    public var chats: [Chat] = []

    @Published
    public var userProfiles: [UserProfile] = []

    @Published
    public var allProfiles: [UserProfile] = []

    @Published
    public var activeProfile: UserProfile? = nil

    public func updateUsername(_ newUsername: String) {
        Task { @MainActor in
            self.activeProfile?.nickname = newUsername

            let httpClient = HttpClient(baseUrl: Config.baseUrl, token: authStateProvider.accessToken!)
            let request = UpdateDisplayNameRequest(newDisplayName: newUsername)
            let response: UserProfileDto = try await httpClient.patchJson(url: "api/profiles/\(self.activeProfile!.id)",
                                                                          object: request)
        }
    }

    public func clear() {
        chats = []
        selectedChat = nil
        userProfiles = []
        allProfiles = []
        activeProfile = nil
    }

    @MainActor
    public func createChat(_ participants: [UserProfile]) async throws -> Chat
    {
        var participants = participants
        var ids = participants.map(\.id)

        ids.append(activeProfile!.id)

        let request = CreateChatRequest(participantIds: ids)

        let http = HttpClient(baseUrl: Config.baseUrl, token: authStateProvider.accessToken!)
        http.setActiveProfile(profileId: activeProfile!.id)
        let placeholderId = UUID()
        let timestamp = Int(Date().timeIntervalSince1970)
        let title = participants.map(\.nickname)
            .joined(separator: ",")

        participants.append(activeProfile!)
        let placeholder = Chat(id: placeholderId, title: title, participants: participants, messages: [])
        chats.append(placeholder)

        do {
            let response: ChatDto = try await http.postJson(url: "api/chats", object: request)
            let realId = response.id

            chats.removeAll {
                $0.id == placeholderId
            }

            let realChat = Chat(id: realId, title: title, participants: participants, messages: [])
            chats.append(realChat)

            if rtc != nil {
                rtc?.subscribeToChatMessagesSent(chatId: realChat.id)
            }

            return realChat
        } catch {
            print(error)
        }

        return placeholder
    }

    private func createMessage(_ chat: Chat, _ text: String, _ attachments: [AttachmentViewModel]) async throws -> Message {
        let request = SendMessageRequest(chatId: chat.id,
                                         senderId: activeProfile!.id,
                                         text: text,
                                         sentAt: Int(Date().timeIntervalSince1970))
        let http = HttpClient(baseUrl: Config.baseUrl, token: authStateProvider.accessToken!)
        http.setActiveProfile(profileId: activeProfile!.id)
        let response: ChatMessageDto = try await http.postJson(url: "api/chats/\(chat.id)/messages", object: request)
        let message = Message(id: response.id,
                              chatid: chat.id,
                              senderId: activeProfile!.id,
                              textContent: response.text,
                              timestamp: response.sentAt,
                              attachments: attachments)
        return message
    }

    private func updateChat(_ chat: Chat, _ message: Message) async throws {
        chat.messages.append(message)

        chats.removeAll {
            $0.id == chat.id
        }

        chats.insert(chat, at: 0)

        // TODO: This is a hack to force the UI to update
        // I don't understand why it's necessary
        // 10000 ns = 0.01 ms
        try await Task.sleep(nanoseconds: 10000)
        selectedChat = chat
    }

    @MainActor
    public func sendMessage(_ chat: Chat, _ text: String, _ attachments: [AttachmentViewModel]) async throws
    {
        if text.isEmpty {
            return
        }

        let message = try await createMessage(chat, text, attachments)
        try await updateChat(chat, message)
    }

    @MainActor
    func onReceivedMessage(event: MessageReceivedEvent) {
        let messageId = event.messageId
        print("received message with ID \(messageId)")
        let chat = chats.first(where: { $0.id == event.chatId })
        if (chat?.messages.contains(where: { $0.id == messageId }))! {
            return
        }

        if rtc != nil {
            // Subscribe to message updates
        }

        Task { @MainActor in
            let httpClient = HttpClient(baseUrl: Config.baseUrl, token: authStateProvider.accessToken!)
            httpClient.setActiveProfile(profileId: activeProfile!.id)
            let messageDto: ChatMessageDto
                = try await httpClient.getJson(url: "api/chats/\(chat!.id)/messages/\(messageId)")
            let message = Message.fromDto(messageDto)
            chat?.messages.append(message)
        }
    }

    @MainActor
    func onReceivedChat(chatId: UUID) {
        print("received chat with ID \(chatId)")
        if chats.contains(where: { $0.id == chatId }) {
            return
        }

        if rtc != nil {
            rtc?.subscribeToChatMessagesSent(chatId: chatId)
        }

        Task { @MainActor in
            let httpClient = HttpClient(baseUrl: Config.baseUrl, token: authStateProvider.accessToken!)
            httpClient.setActiveProfile(profileId: activeProfile!.id)
            let chatDto: ChatDto = try await httpClient.getJson(url: "api/chats/\(chatId)")
            var participants: [UserProfile] = []

            for dto in chatDto.participants {
                if let user = self.allProfiles.first(where: { $0.id == dto.userProfileId }) {
                    participants.append(user)
                    continue
                }

                let result: UserProfileDto = try await httpClient.getJson(url: "api/profiles/\(dto.userProfileId)")
                let user = UserProfile.fromDto(result)
                participants.append(user)
            }

            let chat = Chat.fromDto(chatDto, using: participants, for: self.activeProfile!)
            print(chat.messages)
            chats.insert(chat, at: 0)
        }
    }

    public func initialize(_ authStateProvider: AuthStateProvider) {
        Task(priority: .background) {
            Task { @MainActor in
                let authToken = authStateProvider.accessToken
                let httpClient = HttpClient(baseUrl: Config.baseUrl, token: authToken!)

                do {
                    let initializer = ChatModelInitializer(using: httpClient)
                    self.userProfiles = try await initializer.fetchUserProfiles()
                    self.activeProfile = self.userProfiles[0]
                    httpClient.setActiveProfile(profileId: self.activeProfile!.id)
                    self.allProfiles = try await initializer.fetchAllProfiles()
                    let chats = try await initializer.fetchChats(for: self.activeProfile!.id, using: allProfiles)
                    let sortedChats = chats.sorted {
                        $0.lastUpdatedDate > $1.lastUpdatedDate
                    }

                    self.chats = sortedChats
                    let rtc = RtcProvider(Config.baseUrl, profileId: self.activeProfile?.id)
                    self.rtc = rtc
                    rtc.subscribe(self as any ChatSubscriber)
                    rtc.subscribe(self as any MessageSubscriber)
                    try await rtc.connect(authStateProvider: authStateProvider)

                    for chat in chats {
                        rtc.subscribeToChatMessagesSent(chatId: chat.id)
                    }
                } catch {
                    print(error)
                }
            }
        }
    }
}
