﻿namespace FSharp

open Typo
open Typo.Chat.Core

open System
open System.Threading.Tasks
open Microsoft.AspNetCore.Http
open Microsoft.EntityFrameworkCore
open Typo.Chat.Core.Profiles

module ProfileHandlers =
    // Assuming CreateProfileRequest, ChatDbContext, UserProfile, and other related types are available to this F# code

    type ProfileResult =
        | Unauthorized
        | Conflict of string
        | Ok of UserProfileDto

    let createProfile
        (request: CreateProfileRequest)
        (dbContext: ChatDbContext)
        (context: HttpContext)
        : Task<ProfileResult>
        =
        task {
            let userIdOption =
                context.Items.["UserId"] :?> Nullable<Guid>

            match userIdOption.HasValue with
            | false -> return Unauthorized
            | true ->
                let userId = userIdOption.Value

                let! existing =
                    dbContext.Profiles.FirstOrDefaultAsync(fun profile -> profile.Nickname = request.Nickname)
                    |> Async.AwaitTask

                match existing with
                | null ->
                    let newProfile = UserProfile(userId, request.Nickname)
                    do! dbContext.CreateUserProfile(newProfile) |> Async.AwaitTask
                    return Ok(newProfile.ToDto())
                | _ -> return Conflict $"Nickname {request.Nickname} is already taken"
        }
