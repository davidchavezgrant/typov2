using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.UserProfiles;
public class UpdateDisplayName: ApiTestBase
{
	/// <inheritdoc />
	public UpdateDisplayName(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task DoesNotUpdateDisplayName_When_NameIsTaken()
	{
		var result        = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, new CreateProfileRequest("david"));
		var newProfile    = await result.Content.ReadFromJsonAsync<UserProfileDto>();
		var updateRequest = new UpdateDisplayNameRequest("david");
		await this.ApiClient.PatchAsJsonAsync(ChatRoutes.USER_PROFILES + "/" + newProfile.Id, updateRequest);

		using var dbContext = this.CreateDbContext();
		var       found     = await dbContext.Profiles.FindAsync(newProfile.Id);
		found!.Nickname.Should().Be("david");
	}

	[Fact]
	public async Task UpdatesDisplayName_When_NameIsAvailable()
	{
		var result        = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, new CreateProfileRequest("david"));
		var newProfile    = await result.Content.ReadFromJsonAsync<UserProfileDto>();
		var updateRequest = new UpdateDisplayNameRequest("grant");
		await this.ApiClient.PatchAsJsonAsync(ChatRoutes.USER_PROFILES + "/" + newProfile.Id, updateRequest);

		using var dbContext = this.CreateDbContext();
		var       found     = await dbContext.Profiles.FindAsync(newProfile.Id);
		found!.Nickname.Should().Be("grant");
	}
}