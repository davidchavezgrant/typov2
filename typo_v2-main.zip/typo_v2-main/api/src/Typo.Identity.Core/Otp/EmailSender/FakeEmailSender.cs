using System.Collections.Concurrent;
using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.EmailSender;
internal sealed class FakeEmailSender: IEmailSender
{
	public static int                                           EmailsSent { get; private set; } = 0;
	public static ConcurrentDictionary<string, OneTimePassword> SentCodes  { get; }              = new();
	/// <inheritdoc />
	public Task SendOtpEmailAsync(string          email,
								  OneTimePassword otp,
								  int             port = 25)
	{
		SentCodes[email] = otp;
		EmailsSent++;
		return Task.CompletedTask;
	}

	public static void ResetCount()
	{
		SentCodes.Clear();
		EmailsSent = 0;
	}
}