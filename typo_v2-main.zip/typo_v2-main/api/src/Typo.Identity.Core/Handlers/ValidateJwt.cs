using System.Security.Claims;
using Microsoft.Extensions.Options;
using Typo.Identity.Core.Jwt;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.Model;
using Typo.Identity.Core.Users;
using Typo.Kernel;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core.Handlers;
class ValidateJwt
{
	private readonly IUserService          _userService;
	private readonly IOptions<JwtSettings> _jwtSettings;
	public ValidateJwt(IUserService userService, IOptions<JwtSettings> jwtSettings)
	{
		this._userService = userService;
		this._jwtSettings = jwtSettings;
	}

	public async Task<Result<ValidateTokenResponse>> Execute(string token)
	{
		if (string.IsNullOrEmpty(token))
		{
			return new Error.Invalid("Token is required.");
		}

		try
		{
			var claimsPrincipal = JwtFactory.ValidateToken(token, this._jwtSettings.Value);

			if (claimsPrincipal == null)
			{
				return new Error.Unauthorized("Token is invalid.");
			}

			var userIdClaim      = claimsPrincipal.FindFirst(ClaimTypes.NameIdentifier);
			var phoneNumberClaim = claimsPrincipal.FindFirst(ClaimTypes.MobilePhone);

			if (userIdClaim == null || phoneNumberClaim == null)
			{
				return new Error.Unauthorized("Token is invalid.");
			}

			// Check if the user exists in the database
			var user = await this._userService.GetUser(new PhoneNumber(phoneNumberClaim.Value));

			if (user == null)
			{
				return Error.NotFound("User not found with the given phone number");
			}

			return new ValidateTokenResponse(true, "Token is valid.", new Guid(userIdClaim.Value));
		}
		catch
		{
			// If there's an error (like if the token is expired or malformed), it's treated as an invalid token.
			return new Error.Unauthorized("Token is invalid.");
		}
	}
}