import AVFoundation
import Combine
import SwiftUI


struct ContentView: View {
    @EnvironmentObject
    var model: ChatModel
    @EnvironmentObject
    var appState: AppState
    

    var body: some View {
        NavigationSplitView {
            Sidebar()
                .toolbar(removing: .sidebarToggle)
                .navigationSplitViewColumnWidth(min: 100, ideal: 300, max: 400)
                .toolbar {
                    ToolbarItemGroup(placement: .primaryAction) {
                        Button(action: { appState.showProfile.toggle() }) {
                            Image(systemName: "person.crop.circle")
                        }
                        Spacer()
                        Button(action: { appState.showCompose.toggle() }) {
                            Image(systemName: "square.and.pencil")
                        }
                    }
                }
        } detail: {
            if appState.showCompose {
                ComposeView()
            } else if appState.showProfile {
                ProfileView(profile: model.activeProfile!)
            } else if model.selectedChat != nil {
                ChatView()
            }
        }
        .onChange(of: model.selectedChat) {
            appState.showCompose = false
            appState.showProfile = false
        }
    }

   
}

struct ChatView: View {
    @EnvironmentObject
    var model: ChatModel
    @EnvironmentObject
    var appState: AppState
    @StateObject 
    var viewModel = MessageViewModel()

    var body: some View {
        VStack {
            MessageThreadView(selectedChat: model.selectedChat!)
            if model.selectedChat != nil {
                inputBar.padding()
            }            
            if !viewModel.attachments.isEmpty {
                VStack {
                    HStack(alignment: .top) {
                        ForEach(viewModel.attachments) { attachment in
                            AttachmentPillView(parent: viewModel, viewModel: attachment)
                        }
                    }
                    .padding(.top, 12)
                    .padding(.bottom, 12)
                    MessageAttachmentContainer(viewModel: viewModel)
                }
            }
        }
        .onDrop(of: ["public.file-url"], isTargeted: $appState.isDragActive) { providers in
            viewModel.handleDrop(providers: providers)
        }
    }
    
    private var inputBar: some View {
        HStack {
            TextField("iMessage", text: $messageText, onCommit: {
                Task {
                    try await model.sendMessage(model.selectedChat!, messageText, viewModel.attachments)
                    messageText = ""
                }
            })
            .textFieldStyle(.plain)
        }
    }
    
    @State
    public var messageText = ""
}
