using Microsoft.AspNetCore.Components;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Web.Client.Components.Users;
public partial class FriendList
{
	[Inject]
	FriendListViewModel ViewModel { get; set; }

	/// <inheritdoc />
	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (this.ViewModel.HasLoaded) return;

		await this.ViewModel.Initialize();
		this.StateHasChanged();
	}
	protected override void OnInitialized()
	{
		this.ViewModel.StateHasChanged += this.StateHasChanged;
	}
}