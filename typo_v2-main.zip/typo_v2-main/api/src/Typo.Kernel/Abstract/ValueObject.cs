// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Typo.Kernel.Abstract;
public abstract class ValueObject: IEquatable<ValueObject>
{
	public abstract IEnumerable<object> GetEqualityComponents();

	/// <inheritdoc />
	public override bool Equals(object? obj)
	{
		if (ReferenceEquals(null, obj))
		{
			return false;
		}

		if (ReferenceEquals(this, obj))
		{
			return true;
		}

		if (obj.GetType() != this.GetType())
		{
			return false;
		}

		return this.Equals((ValueObject)obj);
	}

	public static bool operator ==(ValueObject left, ValueObject right)
	{
		return Equals(left, right);
	}

	public static bool operator !=(ValueObject left, ValueObject right)
	{
		return !Equals(left, right);
	}

	/// <inheritdoc />
	public override int GetHashCode()
	{
		// The 'unchecked' block is used to disable overflow-checking for the arithmetic operations
		// inside the block. In this context, 'unchecked' allows the hash code calculation to "wrap around"
		// (i.e., go back to the minimum possible integer value after reaching the maximum, or vice versa)
		// if an overflow occurs. This is generally acceptable in hash code computation as we are not
		// interested in handling overflows—they're not considered errors in this context—and the
		// wrapping behavior in the case of overflow is acceptable. This helps in reducing the
		// likelihood of hash collisions.
		unchecked
		{
			const int PRIME = 397;
			return this.GetEqualityComponents().Select(x => x != null? x.GetHashCode() : 0).Aggregate((x, y) => x * PRIME + y);
		}
	}

	/// <inheritdoc />
	public bool Equals(ValueObject? other)
	{
		return this.Equals((object?)other);
	}
}