using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Identity.Tests.Integration.Test_Data;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Otp;
public class SendEmailOtp: ApiTestBase
{
	public SendEmailOtp(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	public async Task ReturnsOk_When_EmailIsValid(string email)
	{
		await this.AddUserWithEmail(email);
		var request  = new SendOtpRequest(email);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Fact]
	public async Task SendsOneEmail_When_EmailIsValid()
	{
		await this.AddUserWithEmail("dgrant1998@gmail.com");
		FakeEmailSender.ResetCount();
		var initialCount = FakeEmailSender.EmailsSent;
		var request      = new SendOtpRequest("dgrant1998@gmail.com");
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		var finalCount = FakeEmailSender.EmailsSent;

		finalCount.Should().Be(initialCount + 1);
	}

	[Theory]
	[ClassData(typeof(InvalidEmails))]
	public async Task ReturnsBadRequest_When_EmailIsInvalid(string email)
	{
		await this.AddUserWithEmail(email);
		var request  = new SendOtpRequest(email);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
	}

	[Fact]
	public async Task SendsNoEmails_When_EmailIsInvalid()
	{
		FakeEmailSender.ResetCount();
		var request = new SendOtpRequest("notanemail");
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		FakeEmailSender.EmailsSent.Should().Be(0);
	}

	[Fact]
	public async Task ReturnsNotFound_When_EmailIsNotRegistered()
	{
		var request  = new SendOtpRequest("nothere@example.com");
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.NotFound);
	}
}