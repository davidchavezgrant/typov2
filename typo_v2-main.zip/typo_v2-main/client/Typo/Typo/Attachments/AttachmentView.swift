import SwiftUI

struct AttachmentView: View {
    @ObservedObject
    var parent: MessageViewModel
    let data: AttachmentViewModel
    private var iconImage: NSImage?

    private var isActive: Bool {
        parent.activeAttachment.id == data.id
    }

    private var colors: ColorScheme {
        ColorScheme.create(for: parent.isFromMe ? .sent(selected: isActive) : .received(
            selected: isActive))
    }

    init(parent: MessageViewModel, data: AttachmentViewModel) {
        self.parent = parent
        self.data = data
        iconImage = data.thumbnail
    }

    var body: some View {
        HStack(alignment: .center, spacing: 4.0) {
            if let image = iconImage {
                Image(nsImage: image)
                    .resizable()
                    .frame(width: 16.0, height: 16.0)
                    .clipped()
            }
            let text = data.data.displayText
            Text(text)
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(colors.textColor)
                .lineLimit(1)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 2)
        .background(RoundedRectangle(cornerRadius: 50)
            .fill(colors.backgroundColor))
        .onTapGesture {
            if isActive {
                parent.activeAttachment = AttachmentViewModel()
                return
            }
            parent.activeAttachment = data
        }
    }
}
