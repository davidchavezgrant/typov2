import Foundation
import QuickLookUI
import SwiftUI

// MARK: - ArtifactView

/// This is a composite view that contains the message content and the attachment preview
/// It is used to display an artifact in the feed
struct MessageView: View {
    @StateObject
    var viewModel: MessageViewModel
    var onArtifactPage: Bool
    var textPadding = 16.0

    init(artifact: Message, onArtifactPage: Bool, senderName: String? = nil, isFromMe: Bool = false)
    {
        self.onArtifactPage = onArtifactPage
        var viewModel = MessageViewModel(message: artifact,
                                         senderName: senderName ?? "",
                                         isFromMe: isFromMe)

        _viewModel = StateObject(wrappedValue: viewModel)
    }

    func shouldBeFullSize() -> Bool {
        viewModel.attachments
            .contains(where: { $0.data is FileAttachmentData || $0.data is LinkAttachmentData }) || getTextWidth() + textPadding * 2 > fullSize()
    }

    func fullSize() -> CGFloat {
        onArtifactPage ? DisplayConstants.artifactPageArtifactMaxWidth : DisplayConstants.feedBubbleMaxWidth
    }

    func getTextWidth() -> CGFloat {
        viewModel.textContent
            .boundingRect(with: CGSize(width: CGFloat.greatestFiniteMagnitude,
                                       height: CGFloat.greatestFiniteMagnitude),
                          options: .usesLineFragmentOrigin,
                          context: nil)
            .width
    }

    var body: some View {
        VStack(alignment: viewModel.isFromMe ? .trailing : .leading, spacing: 0) {
            HStack {
                if viewModel.isFromMe {
                    Spacer()
                }
                VStack(alignment: viewModel.isFromMe ? .trailing : .leading) {
                    let timestampInt = viewModel.timestamp
                    let timestamp = Date(timeIntervalSince1970: TimeInterval(timestampInt))
                    VStack(alignment: .leading) {
                        Text(viewModel.textContent)
                    }
                    .padding(7)
                    .background(viewModel.isFromMe ? Color.blue : Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(20)
                    Text(timestamp, style: .time)
                }

                if !viewModel.isFromMe {
                    Spacer()
                }
            }
            if !viewModel.attachments.isEmpty {
                VStack(alignment: viewModel.isFromMe ? .trailing : .leading, spacing: 4.0) {
                    ForEach(viewModel.attachments, id: \.id) { attachment in
                        AttachmentPillView(parent: viewModel, viewModel: attachment)
                    }
                }
                .frame(alignment: viewModel.isFromMe ? .trailing : .leading)
                .padding()
            }

            MessageAttachmentContainer(viewModel: viewModel)
        }
        .frame(width: shouldBeFullSize() ? fullSize() : nil)
    }
}

struct MessageAttachmentContainer: View {
    @ObservedObject
    var viewModel: MessageViewModel
    var body: some View {
        switch $viewModel.activeAttachment.data.wrappedValue {
        case is LinkAttachmentData:
            LinkPreviewView(for: viewModel.activeAttachment)
        case is FileAttachmentData:
            FilePreviewView(data: viewModel.activeAttachment)
        case is SystemMessageAttachmentData:
            Text(viewModel.activeAttachment.data.displayText)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(.black)
                .lineLimit(1)
                .truncationMode(.tail)
        default:
            EmptyView()
        }
    }
}
