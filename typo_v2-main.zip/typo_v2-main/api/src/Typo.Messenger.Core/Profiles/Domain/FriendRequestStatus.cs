namespace Typo.Messenger.Core.Profiles.Domain;
public enum FriendRequestStatus
{
	PENDING   = 0,
	CANCELLED = 1,
	ACCEPTED  = 2,
	REJECTED  = 3,
	REMOVED   = 4
}