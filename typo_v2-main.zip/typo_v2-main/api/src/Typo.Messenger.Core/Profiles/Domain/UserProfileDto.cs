namespace Typo.Messenger.Core.Profiles.Domain;
public sealed record UserProfileDto(Guid Id, Guid UserId, string DisplayName);
public sealed record FriendRequestDto(
Guid   Id,
Guid   SenderId,
string SenderDisplayName,
Guid   ReceiverId,
string ReceiverDisplayName);
public sealed record FriendRequestListDto(IEnumerable<FriendRequestDto> Requests);

public sealed record ProfilePictureDto(Guid ImageId, string Url);
public sealed record CreateProfileRequest(string     Nickname);
public sealed record UpdateDisplayNameRequest(string NewDisplayName);