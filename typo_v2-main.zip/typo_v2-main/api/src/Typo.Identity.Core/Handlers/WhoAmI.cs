using System.Security.Claims;
using Microsoft.Extensions.Options;
using Typo.Identity.Core.Jwt;
using Typo.Identity.Core.Users;
using Typo.Kernel;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core.Handlers;
public sealed record WhoAmIResponse(Guid UserId, string Email, string PhoneNumber);
public class WhoAmI
{
	private readonly IUserService          _userService;
	private readonly IOptions<JwtSettings> _jwtSettings;
	internal WhoAmI(IUserService userService, IOptions<JwtSettings> jwtSettings)
	{
		this._userService = userService;
		this._jwtSettings = jwtSettings;
	}

	public async Task<Result<WhoAmIResponse>> Execute(string token)
	{
		var claimsPrincipal = JwtFactory.ValidateToken(token, this._jwtSettings.Value);

		if (claimsPrincipal == null || !claimsPrincipal.Identity.IsAuthenticated)
		{
			return new Error.Unauthorized("Invalid token.");
		}

		var userIdClaim = claimsPrincipal.FindFirst(ClaimTypes.NameIdentifier);

		if (userIdClaim == null)
		{
			return new Error.Unauthorized("Invalid Token");
		}

		var realId = Guid.TryParse(userIdClaim.Value, out var userId);

		if (!realId)
		{
			return new Error.Unauthorized("Invalid Token");
		}

		var user = await this._userService.GetUser(userId);

		if (user == null)
		{
			return Error.NotFound($"User {userId} not found.");
		}

		return new WhoAmIResponse(user.Id, user.Email, user.PhoneNumber);
	}
}