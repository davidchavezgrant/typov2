using System.Collections;
namespace Typo.Identity.Tests.Integration.Test_Data;
internal class InvalidEmails: IEnumerable<object[]>
{
	public IEnumerator<object[]> GetEnumerator()
	{
		yield return new object[] { "" };
		yield return new object[] { "noatsymbol.com" };
		yield return new object[] { "nodomain@" };
		yield return new object[] { "invalid!email@domain.com" };
		yield return new object[]
		{
			"extremelylongemailaddressovertheusualcharacterlimitwithadditionalcharactersaddedtomakeitwaytoolongforanemailaddressandensurethatitexceedsthestandardlimitofcharactersa12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890@example.com"
		};
	}
	/// <inheritdoc />
	IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();
}