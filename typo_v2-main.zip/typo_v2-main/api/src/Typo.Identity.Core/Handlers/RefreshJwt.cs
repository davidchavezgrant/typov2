using System.Security.Claims;
using Microsoft.Extensions.Options;
using Typo.Identity.Core.Jwt;
using Typo.Kernel;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core.Handlers;
class RefreshJwt
{
	private readonly IOptions<JwtSettings> _jwtSettings;
	public RefreshJwt(IOptions<JwtSettings> jwtSettings)
	{
		this._jwtSettings = jwtSettings;
	}

	public Result<string> Execute(string refreshToken)
	{
		if (string.IsNullOrEmpty(refreshToken))
		{
			return new Error.Invalid("Token is required.");
		}

		try
		{
			var claimsPrincipal = JwtFactory.ValidateToken(refreshToken, this._jwtSettings.Value);

			if (claimsPrincipal == null)
			{
				return new Error.Unauthorized("Invalid token.");
			}

			var userIdClaim = claimsPrincipal.FindFirst(ClaimTypes.NameIdentifier);

			if (userIdClaim == null)
			{
				return new Error.Unauthorized("Invalid token.");
			}

			var newToken = JwtFactory.CreateAccessToken(claimsPrincipal.Claims, this._jwtSettings.Value);

			return newToken;
		}
		catch
		{
			// If there's an error (like if the token is expired or malformed), it's treated as an invalid token.
			return new Error.Unauthorized("Invalid token.");
		}
	}
}