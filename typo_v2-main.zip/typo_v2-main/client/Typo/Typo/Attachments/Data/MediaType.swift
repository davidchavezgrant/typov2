import Foundation

public enum MediaType: String, Codable {
    case video
    case image
    case audio
    case textDocument
    case spatialModel
    case unknown

    // MARK: Internal

    static func lookup(fileName: String) -> MediaType? {
        let fileExtension = URL(fileURLWithPath: fileName).pathExtension.lowercased()

        switch fileExtension {
        case "mp4",
             "mov",
             "avi",
             "mkv":
            return .video
        case "jpg",
             "jpeg",
             "png",
             "gif",
             "bmp",
             "heic",
             "webp",
             "heif":
            return .image
        case "mp3",
             "wav",
             "aac",
             "m4a":
            return .audio
        case "txt",
             "doc",
             "docx",
             "pdf":
            return .textDocument
        case "obj",
             "stl",
             "fbx":
            return .spatialModel
        default:
            print("No match found for doc type: \(fileExtension)")
            return nil
        }
    }
}
