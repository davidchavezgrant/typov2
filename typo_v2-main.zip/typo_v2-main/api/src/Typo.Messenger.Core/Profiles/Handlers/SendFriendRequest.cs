using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class SendFriendRequest
{
	private readonly MessengerDbContext _db;
	private readonly Guid               _receiver;
	private readonly Guid               _sender;
	public SendFriendRequest(Guid               sender,
							 Guid               receiver,
							 MessengerDbContext db)
	{
		this._sender   = sender;
		this._receiver = receiver;
		this._db       = db;
	}
	public async Task<Result> Execute()
	{
		var sender = await this._db.Profiles.Include(p => p.SentRequests)
							   .ThenInclude(r => r.Receiver)
							   .Include(p => p.ReceivedRequests)
							   .ThenInclude(r => r.Sender)
							   .FirstOrDefaultAsync(p => p.Id == this._sender);

		var receiver = await this._db.Profiles.Include(p => p.ReceivedRequests)
								 .ThenInclude(r => r.Sender)
								 .Include(p => p.SentRequests)
								 .ThenInclude(r => r.Receiver)
								 .FirstOrDefaultAsync(p => p.Id == this._receiver);

		if (sender is null || receiver is null) return Error.NotFound("Profile not found");

		sender.SendFriendRequest(receiver);
		await this._db.SaveChangesAsync();
		return Result.Ok;
	}
}