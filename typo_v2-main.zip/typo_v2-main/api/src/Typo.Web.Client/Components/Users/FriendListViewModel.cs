using Microsoft.AspNetCore.Components;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Service;
namespace Typo.Web.Client.Components.Users;
internal sealed class FriendListViewModel
{
	private readonly AuthStateProvider _authStateProvider;
	private readonly NavigationManager _navigationManager;
	private readonly ProfileProvider   _profileProvider;
	private readonly IProfileService   _profileService;
	public FriendListViewModel(AuthStateProvider authStateProvider,
							   ProfileProvider   profileProvider,
							   IProfileService   profileService,
							   NavigationManager navigationManager)
	{
		this._authStateProvider          =  authStateProvider;
		this._profileProvider            =  profileProvider;
		this._profileService             =  profileService;
		this._navigationManager          =  navigationManager;
		this._authStateProvider.OnChange += this.StateHasChanged;
		this._profileProvider.OnChange   += this.StateHasChanged;
	}
	public Guid                   ActiveProfileId => this._profileProvider.ActiveProfile?.Id ?? Guid.Empty;
	public List<UserProfileDto>   AllProfiles     { get; private set; } = new List<UserProfileDto>();
	public List<FriendRequestDto> FriendRequests  { get; private set; } = new List<FriendRequestDto>();
	public List<UserProfileDto>   Friends         { get; private set; } = new List<UserProfileDto>();
	public bool                   HasLoaded       { get; set; }
	public bool                   IsAuthenticated => this._authStateProvider.IsAuthenticated;

	public event Action StateHasChanged = () => {};
	public async Task AcceptFriendRequest(FriendRequestDto request)
	{
		await this._profileService.AcceptFriendRequest(request.Id, this._profileProvider.ActiveProfile.Id);
		var receiver = this.AllProfiles.FirstOrDefault(p => p.Id == request.ReceiverId);
		if (receiver is null) return;

		this.AllProfiles.Remove(receiver);
		this.FriendRequests.Remove(request);
		this.Friends.Add(receiver);
		this.StateHasChanged();
	}
	public async Task AddFriend(UserProfileDto profile)
	{
		var result = await this._profileService.SendFriendRequest(this._profileProvider.ActiveProfile.Id, profile.Id);
		if (result.IsSuccess)
		{
			var placeholder = new FriendRequestDto(Guid.Empty,
												   this._profileProvider.ActiveProfile.Id,
												   this._profileProvider.ActiveProfile.DisplayName,
												   profile.Id,
												   profile.DisplayName);
			this.FriendRequests.Add(placeholder);
			var friend = this.AllProfiles.FirstOrDefault(p => p.Id == profile.Id);
			if (friend is null) return;

			this.AllProfiles.Remove(friend);
			this.StateHasChanged();
		}
	}

	public async Task CancelFriendRequest(FriendRequestDto request)
	{
		this.FriendRequests.Remove(request);
		await this._profileService.CancelFriendRequest(request.Id, this._profileProvider.ActiveProfile.Id);
		this.StateHasChanged();
	}

	public async Task DeclineFriendRequest(FriendRequestDto request)
	{
		await this._profileService.RejectFriendRequest(request.Id, this._profileProvider.ActiveProfile.Id);
		var receiver = this.AllProfiles.FirstOrDefault(p => p.Id == request.ReceiverId);
		if (receiver is null) return;

		this.AllProfiles.Remove(receiver);
		this.FriendRequests.Remove(request);
		this.Friends.Add(receiver);
		this.StateHasChanged();
	}

	public async Task Initialize()
	{
		if (this._authStateProvider.IsAuthenticated && !this.HasLoaded && this._profileProvider.ActiveProfile != null)
		{
			var allProfiles = await this._profileService.GetAllProfiles(this._profileProvider.ActiveProfile.Id);
			this.AllProfiles = allProfiles.Profiles.ToList();
			var friends = await this._profileService.GetFriendships(this._profileProvider.ActiveProfile.Id);
			this.Friends = friends.Value.ToList();
			var friendRequestList = await this._profileService.GetPendingFriendRequests(this._profileProvider.ActiveProfile.Id);
			this.FriendRequests = friendRequestList.Value.Requests.ToList();
			this.HasLoaded      = true;
			this.StateHasChanged();
		}
	}
	public bool IsFriend(UserProfileDto profile)
	{
		var any = this.Friends.FirstOrDefault(f => f.Id == profile.Id);
		if (any is not null)
			return true;

		return false;
	}
	public bool IsPendingRequest(UserProfileDto profile)
	{
		return this.FriendRequests.Any(r => r.ReceiverId == profile.Id);
	}
	public async Task RemoveFriend(UserProfileDto theirProfile)
	{
		await this._profileService.DeleteFriendship(this._profileProvider.ActiveProfile.Id, theirProfile.Id);
		var formerFriend = this.Friends.FirstOrDefault(f => f.Id == theirProfile.Id);
		this.Friends.Remove(formerFriend);
		this.StateHasChanged();
	}
}