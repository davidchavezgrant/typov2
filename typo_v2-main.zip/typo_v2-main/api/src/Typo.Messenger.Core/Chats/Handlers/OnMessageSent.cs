using System.Text.Json;
using DotNetCore.CAP;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Typo.Messenger.Contracts;
namespace Typo.Messenger.Core.Chats.Handlers;
class OnMessageSent: ICapSubscribe
{
	private readonly IHubContext<ChatHub>   _hubContext;
	private readonly ILogger<OnMessageSent> _logger;
	public OnMessageSent(IHubContext<ChatHub> hubContext, ILogger<OnMessageSent> logger)
	{
		this._hubContext = hubContext;
		this._logger     = logger;
	}

	[CapSubscribe(nameof(MessageSent))]
	public async Task Execute(MessageSent @event)
	{
		var messageId      = @event.ChatMessageId.ToString();
		var topicId = $"message-sent_{@event.ChatId}";
		var messageReceived = new MessageReceived(@event.ChatId, @event.ChatMessageId);
		var serializerOptions = new JsonSerializerOptions
		{
			PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
		};
		var serializedEvent = JsonSerializer.Serialize(messageReceived, options: serializerOptions);
		await this._hubContext.Clients.Group(topicId).SendAsync(nameof(MessageSent), serializedEvent);
		this._logger.LogInformation($"Sent {nameof(MessageSent)} to {topicId} with content: {serializedEvent}");
	}
}

public sealed record MessageReceived(Guid ChatId, Guid MessageId);