import Foundation

protocol AttachmentData {
    var id: UUID {
        get set
    }

    var name: String {
        get set
    }

    var displayText: String {
        get
    }
}

struct EmptyAttachmentData: AttachmentData {
    var id: UUID = .init()

    var name: String = ""

    var displayText: String = ""
}
