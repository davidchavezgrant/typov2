import SwiftUI

class UserProfile: Identifiable, Equatable, Hashable, ObservableObject {
    // MARK: Lifecycle

    init(id: UUID,
         userId: UUID,
         nickname: String,
         profileImage: Data? = nil,
         streams: [Chat] = [])
    {
        self.id = id
        self.userId = userId
        self.nickname = nickname
        self.profileImage = profileImage
        self.streams = streams
    }

    // MARK: Public

    public var id: UUID
    public var userId: UUID
    @Published
    public var nickname: String
    public var profileImage: Data?
    @Published
    public var streams: [Chat] = []

    public static func fromDto(_ dto: UserProfileDto) -> UserProfile {
        UserProfile(id: dto.id, userId: dto.userId, nickname: dto.displayName)
    }

    public static func == (lhs: UserProfile, rhs: UserProfile) -> Bool {
        lhs.id == rhs.id
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
