using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.Friends;
public class DeleteFriend: ApiTestBase
{
	/// <inheritdoc />
	public DeleteFriend(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task RemovesFriend_WhenExists()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);
		this.SetActiveProfileHeader(them.Id);
		var response  = await this.ApiClient.GetFromJsonAsync<FriendRequestListDto>($"/api/friends/requests/pending");
		var requestId = response.Requests.First().Id;
		await this.ApiClient.PostAsync($"/api/friends/requests/{requestId}/accept", null);

		// Act
		await this.ApiClient.DeleteAsync($"/api/friends/{me.Id}");
		var dbContext   = this.CreateDbContext();
		var meProfile   = await dbContext.Profiles.Include(p => p.Friendships).FirstOrDefaultAsync(p => p.Id == me.Id);
		var themProfile = await dbContext.Profiles.Include(p => p.Friendships).FirstOrDefaultAsync(p => p.Id == them.Id);

		// Assert
		meProfile?.Friendships.Count.Should().Be(0);
		themProfile?.Friendships.Count.Should().Be(0);
	}
}