using Microsoft.Extensions.Options;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.Service;
using Typo.Identity.Core.Users;
using Typo.Kernel;
using Typo.Kernel.Abstract;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core;
internal class AuthService: IAuthService
{
	private readonly IUserService          _userService;
	private readonly IOtpService           _otpService;
	private readonly IEventPublisher       _publisher;
	private readonly IOptions<JwtSettings> _jwtSettings;
	public AuthService(IUserService          userService,
					   IOtpService           otpService,
					   IEventPublisher       publisher,
					   IOptions<JwtSettings> jwtSettings)
	{
		this._userService = userService;
		this._otpService  = otpService;
		this._publisher   = publisher;
		this._jwtSettings = jwtSettings;
	}
	public async Task<Result<User>> RegisterUser(RegisterRequest request)
		=> await new Register(this._userService).Execute(request);

	public async Task<Result<User>> DeleteUser(Guid userId)
		=> await new DeleteUser(this._userService).Execute(userId);

	public async Task<Result> SendOtp(SendOtpRequest request)
		=> await new SendOtp(this._otpService, this._userService).Execute(request);

	public async Task<Result<AuthResponse>> ValidateOtp(AuthRequest request)
		=> await new ValidateOtp(this._publisher,
								 this._otpService,
								 this._userService,
								 this._jwtSettings).Execute(request);

	public async Task<Result<ValidateTokenResponse>> ValidateToken(string token)
		=> await new ValidateJwt(this._userService, this._jwtSettings).Execute(token);

	public Result<string> RefreshToken(string token)
		=> new RefreshJwt(this._jwtSettings).Execute(token);

	public async Task<Result<WhoAmIResponse>> WhoAmI(string token)
		=> await new WhoAmI(this._userService, this._jwtSettings).Execute(token);
}