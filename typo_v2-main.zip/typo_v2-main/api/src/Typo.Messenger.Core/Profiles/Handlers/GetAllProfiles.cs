using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class GetAllProfiles
{
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _currentProfileId;
	public GetAllProfiles(MessengerDbContext dbContext, Guid currentProfileId)
	{
		this._dbContext        = dbContext;
		this._currentProfileId = currentProfileId;
	}

	public async Task<UserProfileListDto> Execute()
	{
		var allProfiles = await this._dbContext.Profiles.ToListAsync();
		var results     = allProfiles.Where(p => p.Id != this._currentProfileId).Select(p => p.ToDto());
		return new UserProfileListDto(results);
	}
}
public sealed record UserProfileListDto(IEnumerable<UserProfileDto> Profiles);