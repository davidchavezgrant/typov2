import SwiftUI

final class AuthService {
    // MARK: Public

    public func validateOtp(userIdentifier: String, code: String) async throws -> AuthState {
        let result: ValidateOtpResponse = try await httpClient.postJson(url: "api/auth/otp/validate",
                                                                        object: ValidateOtpRequest(userIdentifier: userIdentifier,
                                                                                                   code: code))
        return AuthState(registered: true,
                         isValidated: result.success,
                         sentOtp: true,
                         accessToken: result.accessToken,
                         refreshToken: result.refreshToken,
                         error: result.error)
    }

    public func register(username: String) async throws -> AuthState {
        do {
            let result: RegisterResponse = try await httpClient.postJson(url: "api/auth/register",
                                                                         object: AuthRequest(username: username))
            return AuthState(registered: true, isValidated: false, sentOtp: false, accessToken: nil, error: nil)
        } catch let error as ApiError {
            if error.status == 409 {
                return AuthState(registered: true,
                                 isValidated: false,
                                 sentOtp: false,
                                 accessToken: nil,
                                 error: error.detail)
            }

            return AuthState(registered: false,
                             isValidated: false,
                             sentOtp: false,
                             accessToken: nil,
                             error: error.detail)
        }
    }

    public func sendOtp(value: String) async throws {
        _ = try await httpClient.postJson(url: "api/auth/otp/send", object: SendOtpRequest(value: value))
    }

    // MARK: Private

    private let httpClient = HttpClient(baseUrl: Config.baseUrl, token: "")
}
