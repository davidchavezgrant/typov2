using Typo.Kernel;
using Typo.Kernel.Abstract;
namespace Typo.Messenger.Core.Chats.Domain;
internal sealed class Comment: Entity<Guid>
{
	private Comment() {}
	public Comment(ChatMessage message,
				   Guid        senderId,
				   string      text,
				   long        sentAt)
	{
		this.Message  = message;
		this.Text     = text;
		this.SentAt   = sentAt;
		this.SenderId = senderId;
	}

	public ChatMessage Message { get; private set; }

	public Guid SenderId { get; private set; }

	public string Text { get; private set; }

	public long SentAt { get; private set; }
	public CommentDto ToDto()
	{
		return new CommentDto(this.Id,
							  this.Message.Id,
							  this.SenderId,
							  this.Text,
							  this.SentAt);
	}
}