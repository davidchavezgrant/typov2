import Foundation

// MARK: - SystemMessageInfoForView

class SystemMessageAttachmentData: AttachmentData {
    var id: UUID
    let userId: UUID
    let type: SystemMessageType
    var name: String

    var displayText: String {
        String(describing: type.rawValue)
    }

    init(id: UUID, userId: UUID, type: SystemMessageType) {
        self.id = id
        self.userId = userId
        self.type = type
        name = String(describing: type.rawValue)
    }
}

// MARK: - SystemMessageType

public enum SystemMessageType: Int, Codable {
    public typealias RawValue = Int
    case userJoined = 0
    case userLeft = 1
    case streamCreated = 2
}
