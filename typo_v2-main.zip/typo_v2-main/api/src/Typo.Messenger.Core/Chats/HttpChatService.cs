using Microsoft.AspNetCore.Http;
using Typo.Kernel.Abstract;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.Chats.Handlers;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats;
internal static class HttpChatService
{
	public static async Task<IResult> CreateChat(CreateChatRequest  request,
												 MessengerDbContext db,
												 IEventPublisher    publisher,
												 HttpContext        context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new CreateChat(request, db, publisher).Execute(profileId.Value);
		return result.AsHttpResult("/api/chats");
	}

	public static async Task<IResult> GetChats(MessengerDbContext db, HttpContext context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new GetChats(db, profileId.Value).Execute();
		return Results.Ok(result);
	}

	public static async Task<IResult> GetChat(Guid               chatId,
											  MessengerDbContext db,
											  HttpContext        context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new GetChat(db, chatId).Execute();
		return result.AsHttpResult($"/api/chats/{chatId}");
	}
	public static async Task<IResult> SendMessage(Guid               chatId,
												  SendMessageRequest request,
												  MessengerDbContext dbContext,
												  IEventPublisher    publisher)
	{
		var result = await new SendMessage(dbContext, request, publisher).Execute();
		return result.AsHttpResult($"/api/chats/{chatId}/messages/{result.Value.Id}");
	}
	public static async Task<IResult> AttachFile(Guid               chatId,
												 Guid               messageId,
												 AttachmentRequest  request,
												 MessengerDbContext dbContext)
	{
		var result = await new AttachFile(dbContext,
										  request,
										  chatId,
										  messageId).Execute();
		return result.AsHttpResult($"/api/chats/{chatId}/messages/{messageId}/attachments/{result.Value.AttachmentId}");
	}
	public static async Task<IResult> GetMessage(Guid               chatId,
												 Guid               messageId,
												 MessengerDbContext db)
	{
		var result = await new GetMessage(chatId, messageId, db).Execute();
		return result.AsHttpResult($"/api/chats/{chatId}/messages/{messageId}");
	}
	public static async Task<IResult> AddComment(Guid               chatId,
												 Guid               messageId,
												 AddCommentRequest  request,
												 MessengerDbContext db,
												 HttpContext        context)
	{
		var profileId = context.Items["ProfileId"] as Guid?;
		if (profileId is null) return Results.Unauthorized();

		var result = await new AddComment(request,
										  chatId,
										  messageId,
										  profileId.Value,
										  db).Execute();

		return result.AsHttpResult($"/api/chats/{chatId}/messages/{messageId}/comments");
	}
	public static async Task<IResult> GetComments(Guid               chatId,
												  Guid               messageId,
												  MessengerDbContext db)
	{
		var result = await new GetComments(chatId, messageId, db).Execute();
		return result.AsHttpResult($"/api/chats/{chatId}/messages/{messageId}/comments");
	}
}