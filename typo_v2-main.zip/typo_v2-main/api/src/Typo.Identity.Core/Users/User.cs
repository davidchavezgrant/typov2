namespace Typo.Identity.Core.Users;
public sealed class User
{
	public Guid    Id                   { get; set; }
	public string? PhoneNumber          { get; set; } = null;
	public string? Email                { get; set; } = null;
	public bool    PhoneNumberConfirmed { get; set; }
	public bool    EmailConfirmed       { get; set; }
}