using Microsoft.Extensions.Logging;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Core.Otp.Model;
using Typo.Identity.Core.Otp.TextMessageSender;
namespace Typo.Identity.Core.Otp.Service;
internal sealed class OtpService: IOtpService
{
	private readonly IOtpCache           _cache;
	private readonly IEmailSender        _emailSender;
	private readonly ITextMessageSender  _textMessageSender;
	private readonly ILogger<OtpService> _logger;

	public OtpService(IOtpCache           cache,
					  IEmailSender        emailSender,
					  ITextMessageSender  textMessageSender,
					  ILogger<OtpService> logger)
	{
		this._cache             = cache;
		this._emailSender       = emailSender;
		this._textMessageSender = textMessageSender;
		this._logger            = logger;
	}

	/// <inheritdoc />
	public async Task SendOtpAsync(PhoneNumber phoneNumberDto)
	{
		var otp = OneTimePassword.GenerateNumericCode(6);
		await this._cache.SetOtpAsync(phoneNumberDto.Value, otp);
		await this._textMessageSender.SendOtpTextMessageAsync(phoneNumberDto.Value, otp);
		this._logger.LogInformation("Sent OTP {Otp} to {PhoneNumber}", otp, phoneNumberDto.Value);
	}

	public async Task SendOtpAsync(EmailAddress emailAddress)
	{
		var otp = OneTimePassword.Generate();
		await this._cache.SetOtpAsync(emailAddress.Value, otp);
		await this._emailSender.SendOtpEmailAsync(emailAddress.Value, otp);
	}

	private async Task<bool> IsValid(string username, string otp)
	{
		(bool found, var cachedOtp) = await this._cache.TryGetOtpAsync(username);
		if (!found) return false;

		if (cachedOtp.IsExpired) return false;

		return cachedOtp.Value == otp;
	}

	/// <inheritdoc />
	public async Task<bool> VerifyOtpAsync(PhoneNumber phoneNumberDto, string otp)
	{
		return await this.IsValid(phoneNumberDto.Value, otp);
	}

	/// <inheritdoc />
	public async Task<bool> VerifyOtpAsync(EmailAddress email, string otp)
	{
		return await this.IsValid(email.Value, otp);
	}
}