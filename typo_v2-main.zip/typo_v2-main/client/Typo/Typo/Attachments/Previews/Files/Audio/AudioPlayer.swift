
import AVKit
import Foundation

class AudioPlayer: ObservableObject {
    private var audioPlayer: AVPlayer?
    private var timeObserver: Any?
    @Published
    var currentTime = 0.0
    init(url: URL) {
        audioPlayer = AVPlayer(url: url)
        setupTimeObserver()
    }

    private func setupTimeObserver() {
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserver = audioPlayer?.addPeriodicTimeObserver(forInterval: interval,
                                                            queue: DispatchQueue.main)
        { [weak self] time in
            self?.currentTime = CMTimeGetSeconds(time)
        }
    }

    func play() {
        audioPlayer?.play()
    }

    func pause() {
        audioPlayer?.pause()
    }
}
