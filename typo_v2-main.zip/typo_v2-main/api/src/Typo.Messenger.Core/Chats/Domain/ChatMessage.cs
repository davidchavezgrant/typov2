using Typo.Kernel;
using Typo.Kernel.Abstract;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Chats.Domain;
internal sealed class ChatMessage: Entity<Guid>
{
	private ChatMessage() {}
	public ChatMessage(Chat            chat,
					   ChatParticipant sender,
					   string          text,
					   long            sentAt)
	{
		this.Text   = text;
		this.Chat   = chat;
		this.Sender = sender;
		this.SentAt = sentAt;
	}
	public           long                            SentAt { get; private set; }
	public           Chat                            Chat   { get; private set; }
	public           ChatParticipant                 Sender { get; private set; }
	public           string                          Text   { get; private set; }
	private readonly List<Comment>                   _comments = new();
	public           IReadOnlyCollection<Comment>    Comments => this._comments.AsReadOnly();
	private readonly List<Attachment>                _attachments = new();
	public           IReadOnlyCollection<Attachment> Attachments => this._attachments.AsReadOnly();
	public ChatMessageDto ToDto()
	{
		return new ChatMessageDto(this.Id,
								  this.Chat.Id,
								  this.Sender.UserProfileId,
								  this.Text,
								  this.SentAt);
	}
	public Attachment AttachFile(Guid fileId, string fileName)
	{
		var attachment = new Attachment(this, fileId, fileName);
		this._attachments.Add(attachment);
		return attachment;
	}

	public Comment AddComment(string      text,
							  long        sentAt,
							  UserProfile sender)
	{
		var comment = new Comment(this,
								  sender.Id,
								  text,
								  sentAt);
		this._comments.Add(comment);
		return comment;
	}
}