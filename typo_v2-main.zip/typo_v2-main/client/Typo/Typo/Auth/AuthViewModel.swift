import Foundation
import SwiftUI

class AuthViewModel: ObservableObject {
    // MARK: Public

    @Published
    public var input = ""
    @Published
    public private(set) var isAuthenticating = false
    @Published
    public private(set) var authError: String?
    @Published
    public private(set) var sentOtp = false
    @Published
    public private(set) var registered = false

    public var loginDisabled: Bool {
        input.isEmpty || isAuthenticating
    }

    @MainActor
    public func submit(_ authStateProvider: AuthStateProvider) {
        Task {
            let result = await try self.getAuthState()
            authStateProvider.update(newState: result)
            updateState(result)
        }
    }

    // MARK: Private

    private var userIdentifier = ""
    private let authService = AuthService()

    @MainActor
    private func getAuthState() async throws -> AuthState {
        isAuthenticating = true
        do {
            let authState = try await submitInput()
            isAuthenticating = false
            return authState
        } catch let error as ApiError {
            let authState = try await handleApiError(error)
            isAuthenticating = false
            return authState
        } catch {
            isAuthenticating = false
            return AuthState(registered: registered, isValidated: false, sentOtp: false, error: "Unknown error")
        }
    }

    @MainActor
    private func submitInput() async throws -> AuthState {
        if sentOtp {
            return try await authService.validateOtp(userIdentifier: userIdentifier, code: input)
        }

        let response = try await authService.register(username: input)
        if response.error == nil || response.registered {
            try await sendOtp()
        }
        return AuthState(registered: registered, isValidated: false, sentOtp: sentOtp, error: response.error)
    }

    @MainActor
    private func handleApiError(_ apiError: ApiError) async throws -> AuthState {
        if apiError.status == 409 {
            do {
                try await sendOtp()
                return AuthState(registered: registered,
                                 isValidated: false,
                                 sentOtp: true,
                                 error: "Please enter the OTP ")
            } catch {
                return AuthState(registered: registered,
                                 isValidated: false,
                                 sentOtp: false,
                                 error: error.localizedDescription)
            }
        }
        return AuthState(registered: registered, isValidated: false, sentOtp: false, error: apiError.detail)
    }

    @MainActor
    private func sendOtp() async throws {
        userIdentifier = input
        try await authService.sendOtp(value: input)
        sentOtp = true
    }

    private func updateState(_ result: AuthState) {
        if !result.isValidated {
            if result.sentOtp {
                input = ""
                authError = nil
                sentOtp = true
            } else {
                authError = result.error
            }
        }
    }
}
