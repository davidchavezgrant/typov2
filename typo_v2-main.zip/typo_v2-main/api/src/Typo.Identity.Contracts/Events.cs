﻿namespace Typo.Identity.Contracts;
public sealed record UserCreated(Guid UserId, string DisplayName, string PhoneNumber);
public sealed record UserDeleted(Guid UserId);