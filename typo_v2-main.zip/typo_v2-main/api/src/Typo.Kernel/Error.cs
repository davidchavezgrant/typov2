namespace Typo.Kernel;
public abstract class Error
{
	public string Message { get; }
	private Error(string message)
	{
		this.Message = message;
	}

	public sealed class ExceptionalError: Error
	{
		public Exception Exception { get; }
		public ExceptionalError(Exception exception): base(exception.Message) => this.Exception = exception;
	}

	// TODO: should these be methods to avoid "new" at the call site?
	// public static  NotFoundError NotFound(string message) => new NotFoundError(message);
	public sealed class NotFoundError: Error
	{
		internal NotFoundError(string message): base(message) {}
	}

	public static NotFoundError NotFound(string message) => new NotFoundError(message);

	public sealed class Invalid: Error
	{
		public Invalid(string message): base(message) {}
	}

	public sealed class Unauthorized: Error
	{
		public Unauthorized(string message): base(message) {}
	}

	public sealed class NoError: Error
	{
		public NoError(): base(string.Empty) {}
	}

	public sealed class Conflict: Error
	{
		public Conflict(string message): base(message) {}
	}

	public static readonly Error  None = new NoError();
	public static          Error  FromException(Exception e) => new ExceptionalError(e);
	public                 Result AsResult()                 => new(this);
}