using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Kernel.Abstract;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.Chats.Handlers;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats;
internal sealed class ChatService: IChatService
{
	private readonly IDbContextFactory<MessengerDbContext> _dbContextFactory;
	private readonly IEventPublisher                       _publisher;
	public ChatService(IDbContextFactory<MessengerDbContext> dbContextFactory, IEventPublisher publisher)
	{
		this._dbContextFactory = dbContextFactory;
		this._publisher        = publisher;
	}
	public async Task<Result<ChatDto>> CreateChat(CreateChatRequest request, Guid requestingProfileId)
		=> await new CreateChat(request, this._dbContextFactory.CreateDbContext(), _publisher).Execute(requestingProfileId);

	public async Task<ChatListDto> GetChats(Guid profileId)
		=> await new GetChats(this._dbContextFactory.CreateDbContext(), profileId).Execute();
	/// <inheritdoc />
	public async Task<Result<ChatDto>> GetChat(Guid id)
		=> await new GetChat(this._dbContextFactory.CreateDbContext(), id).Execute();
	/// <inheritdoc />
	public Task<Result<ChatMessageDto>> SendMessage(SendMessageRequest request)
		=> new SendMessage(this._dbContextFactory.CreateDbContext(), request, _publisher).Execute();
}