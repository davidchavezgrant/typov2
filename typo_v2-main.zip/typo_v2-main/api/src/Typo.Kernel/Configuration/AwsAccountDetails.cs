namespace Typo.Kernel.Configuration;
public class AwsAccountDetails
{
	public const string SECTION_NAME = nameof(AwsAccountDetails);
	public       string AccessKeyId     { get; set; } = string.Empty;
	public       string SecretAccessKey { get; set; } = string.Empty;
}
public class AwsSnsArns
{
	public const string SECTION_NAME = nameof(AwsSnsArns);
	public       string Apns             { get; set; } = string.Empty;
	public       string ApnsEndpointBase { get; set; } = string.Empty;
	public       string Fcm              { get; set; } = string.Empty;
}