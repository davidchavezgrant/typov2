using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.UserProfiles;
public class GetUserProfiles: ApiTestBase
{
	/// <inheritdoc />
	public GetUserProfiles(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}
	[Fact]
	public async Task ReturnsNoProfiles_When_UserHasNoProfiles()
	{
		var result = await this.ApiClient.GetFromJsonAsync<UserProfileListDto>(ChatRoutes.USER_PROFILES);
		result.Profiles.Count().Should().Be(0);
	}

	[Fact]
	public async Task ReturnsOk_When_UserHasNoProfiles()
	{
		var result = await this.ApiClient.GetAsync(ChatRoutes.USER_PROFILES);
		result.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Fact]
	public async Task ReturnsProfiles_When_UserHasProfiles()
	{
		var request  = new CreateProfileRequest("david");
		var request2 = new CreateProfileRequest("anthony");
		await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);
		await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request2);

		var result = await this.ApiClient.GetFromJsonAsync<UserProfileListDto>(ChatRoutes.USER_PROFILES);
		result!.Profiles.Count().Should().Be(2);
	}
}