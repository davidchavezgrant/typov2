using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.DAL;
internal sealed class MessengerDbContext: DbContext
{
	public MessengerDbContext(DbContextOptions<MessengerDbContext> options): base(options) {}

	public DbSet<UserProfile> Profiles => this.Set<UserProfile>();
	public DbSet<Chat>        Chats    => this.Set<Chat>();

	/// <inheritdoc />
	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		modelBuilder.Entity<UserProfile>()
					.HasMany(profile => profile.SentRequests)
					.WithOne(request => request.Sender)
					.HasForeignKey(f => f.SenderId)
					.OnDelete(DeleteBehavior.Restrict);

		modelBuilder.Entity<UserProfile>()
					.HasMany<FriendRequest>(profile => profile.ReceivedRequests)
					.WithOne(request => request.Receiver)
					.HasForeignKey(f => f.ReceiverId)
					.OnDelete(DeleteBehavior.Restrict);

		modelBuilder.Entity<UserProfile>().HasMany(u => u.Friendships).WithMany();
	}
}