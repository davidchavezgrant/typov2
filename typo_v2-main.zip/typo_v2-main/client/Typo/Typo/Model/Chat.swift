import Foundation
import SwiftUI

class Chat: Identifiable, Equatable, Hashable, ObservableObject {
    // MARK: Lifecycle

    init(id: UUID,
         title: String,
         participants: [UserProfile],
         profileImage: Data? = nil,
         messages: [Message])
    {
        self.id = id
        self.title = title
        self.participants = participants
        self.profileImage = profileImage
        self.messages = messages
        previewText = ""
        updatePreviewText()
    }

    // MARK: Public

    @Published
    public var participants: [UserProfile] = []
    @Published
    public var id: UUID
    @Published
    public var title: String
    @Published
    public var previewText: String

    @Published
    public var messages: [Message] = [] {
        didSet {
            updatePreviewText()
        }
    }

    public var lastMessage: Message? {
        messages.sorted(by: { $0.timestamp > $1.timestamp }).first
    }

    public var lastUpdatedDate: Date {
        let lastMessage = lastMessage
        return Date(timeIntervalSince1970: TimeInterval(lastMessage?.timestamp ?? 0))
    }

    public var timeStampString: String {
        let date = lastUpdatedDate
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = .short
        return dateFormatter.string(from: date)
    }

    public static func == (lhs: Chat, rhs: Chat) -> Bool {
        lhs.id == rhs.id
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }

    // MARK: Internal

    let profileImage: Data?

    // MARK: Private

    private func updatePreviewText() {
        previewText = messages.sorted(by: { $0.timestamp > $1.timestamp }).first?.textContent ?? ""
    }

    public static func fromDto(_ dto: ChatDto,
                               using participants: [UserProfile],
                               for requestingProfile: UserProfile) -> Chat
    {
        let others = participants.filter
            { $0.id != requestingProfile.id }
        let title = others.map(\.nickname).joined(separator: ", ")
        let messages = dto.messages.map {
            Message.fromDto($0)
        }
        return Chat(id: dto.id,
                    title: title,
                    participants: participants,
                    messages: messages)
    }
}
