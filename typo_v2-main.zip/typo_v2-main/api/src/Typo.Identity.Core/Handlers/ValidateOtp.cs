using System.Security.Claims;
using Microsoft.Extensions.Options;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Jwt;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.Model;
using Typo.Identity.Core.Otp.Service;
using Typo.Identity.Core.Users;
using Typo.Kernel;
using Typo.Kernel.Abstract;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core.Handlers;
internal sealed class ValidateOtp
{
	private readonly IEventPublisher       _publisher;
	private readonly IOtpService           _otp;
	private readonly IUserService          _userService;
	private readonly IOptions<JwtSettings> _jwtSettings;

	public ValidateOtp(IEventPublisher       publisher,
					   IOtpService           otp,
					   IUserService          userService,
					   IOptions<JwtSettings> jwtSettings)
	{
		this._publisher   = publisher;
		this._otp         = otp;
		this._userService = userService;
		this._jwtSettings = jwtSettings;
	}

	public async Task<Result<AuthResponse>> Execute(AuthRequest request)
	{
		if (request.Code.Length != 6)
			return new Error.Invalid("Invalid code.");

		var emailExists = await this._userService.EmailExists(new EmailAddress(request.UserIdentifier));
		var phoneExists = await this._userService.PhoneExists(new PhoneNumber(request.UserIdentifier));

		if (!emailExists && !phoneExists)
		{
			return Error.NotFound("User not found.");
		}

		var response = await this.GetResponse(request);
		if (response is null)
			return new Error.Invalid("Invalid code.");

		return response;
	}

	private async Task<AuthResponse?> GetResponse(AuthRequest request)
	{
		var email = new EmailAddress(request.UserIdentifier);
		var phone = new PhoneNumber(request.UserIdentifier);

		if (!email.IsValid() && !phone.IsValid())
		{
			return null;
		}

		if (email.IsValid())
		{
			var verified = await this._otp.VerifyOtpAsync(email, request.Code);

			if (verified)
			{
				var response = await this.GetEmailResponse(email);
				return response;
			}
		}

		if (phone.IsValid())
		{
			var verified = await this._otp.VerifyOtpAsync(phone, request.Code);

			if (verified)
			{
				var response = await this.GetPhoneResponse(phone);
				return response;
			}
		}

		return null;
	}

	private async Task<AuthResponse> GetEmailResponse(EmailAddress email)
	{
		// Check if user exists
		var user = await this._userService.GetUser(email);

		// If user does not exist, create a new user
		if (user == null)
		{
			user = await this._userService.CreateUser(email);
		}
		if (user != null)
		{
			await this._publisher.PublishAsync(new UserCreated(user.Id, email.Value, email.Value));
			user.EmailConfirmed = true;
			await this._userService.UpdateUser(user);
		}

		var claims = new List<Claim>();
		claims.Add(new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()));
		claims.Add(new Claim(ClaimTypes.Email,          user.Email));
		string accessToken  = JwtFactory.CreateAccessToken(claims, this._jwtSettings.Value);
		string refreshToken = JwtFactory.CreateRefreshToken(user.Id.ToString(), this._jwtSettings.Value);

		var emailResponse = new AuthResponse(true,
											 accessToken,
											 refreshToken,
											 "",
											 email.Value,
											 user.Id);

		return emailResponse;
	}

	private async Task<AuthResponse> GetPhoneResponse(PhoneNumber phone)
	{
		// Check if user exists
		var user = await this._userService.GetUser(phone);

		// If user does not exist, create a new user
		if (user == null)
		{
			user = await this._userService.CreateUser(phone);
		}
		if (user != null)
		{
			await this._publisher.PublishAsync(new UserCreated(user.Id, phone.Value, phone.Value));
			user.PhoneNumberConfirmed = true;
			await this._userService.UpdateUser(user);
		}

		var claims = new List<Claim>();
		claims.Add(new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()));
		claims.Add(new Claim(ClaimTypes.MobilePhone,    user.PhoneNumber));
		string accessToken  = JwtFactory.CreateAccessToken(claims, this._jwtSettings.Value);
		string refreshToken = JwtFactory.CreateRefreshToken(user.Id.ToString(), this._jwtSettings.Value);

		var phoneResponse = new AuthResponse(true,
											 accessToken,
											 refreshToken,
											 "",
											 phone.Value,
											 user.Id);
		return phoneResponse;
	}
}