using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Contracts;
using Typo.Messenger.Core.Profiles;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.UserProfiles;
public class CreateProfile: ApiTestBase
{
	public CreateProfile(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}
	[Fact]
	public async Task CreatesProfile_When_NicknameIsValid()
	{
		var request = new CreateProfileRequest("david");
		await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);

		using var dbContext = this.CreateDbContext();
		dbContext.Profiles.Count().Should().Be(1);
	}

	[Fact]
	public async Task DoesNotCreateProfile_When_NicknameIsDuplicate()
	{
		var request = new CreateProfileRequest("david");
		await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);
		await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);

		using var dbContext = this.CreateDbContext();
		dbContext.Profiles.Count().Should().Be(1);
	}

	[Fact]
	public async Task ReturnsId_When_NicknameIsValid()
	{
		var request  = new CreateProfileRequest("david");
		var response = await this.ApiClient.PostAsJsonAsync(ChatRoutes.USER_PROFILES, request);
		var result   = await response.Content.ReadFromJsonAsync<UserProfileDto>();
		result?.Id.Should().NotBeEmpty();
		result?.DisplayName.Should().Be(request.Nickname);

		var readingMyOwnWrite = await this.ApiClient.GetFromJsonAsync<UserProfileListDto>(ChatRoutes.USER_PROFILES);

		readingMyOwnWrite.Profiles.First().Id.Should().Be(result.Id);
	}
}