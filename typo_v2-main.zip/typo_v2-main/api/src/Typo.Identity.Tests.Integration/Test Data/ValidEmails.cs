using System.Collections;
namespace Typo.Identity.Tests.Integration.Test_Data;
class ValidEmails: IEnumerable<object[]>
{
	public IEnumerator<object[]> GetEnumerator()
	{
		yield return new object[] { "valid.email@example.com" };
		yield return new object[] { "sub.domain.email@example.co.uk" };
		yield return new object[] { "filter+test@example.com" };
		yield return new object[] { "unusual.domain@example.xyz" };
	}
	/// <inheritdoc />
	IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();
}