
import AVKit
import SwiftUI

struct AVPlayerView: NSViewRepresentable {
    let player: AVPlayer

    func makeNSView(context _: Context) -> NSView {
        let view = NSView()
        let playerLayer = AVPlayerLayer(player: player)
        view.layer = playerLayer
        return view
    }

    func updateNSView(_: NSView, context _: Context) {
        // Handle updates
    }
}
