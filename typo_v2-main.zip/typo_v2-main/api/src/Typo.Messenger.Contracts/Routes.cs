namespace Typo.Messenger.Contracts;
public static class ChatRoutes
{
	public const string USER_PROFILES     = "/api/profiles";
	public const string ALL_USER_PROFILES = "/api/profiles/all";
}