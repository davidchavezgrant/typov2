using Microsoft.AspNetCore.Components;
namespace Typo.Web.Client.Components.Chats;
public partial class ChatList
{
	[Inject]
	public ChatListViewModel ViewModel { get; set; }

	/// <inheritdoc />
	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (this.ViewModel.HasLoaded) return;

		await this.ViewModel.Initialize();
		this.StateHasChanged();
	}
	protected override void OnInitialized()
	{
		this.ViewModel.StateHasChanged += this.StateHasChanged;
	}
}