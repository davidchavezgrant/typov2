import SwiftUI

// MARK: - FileAttachmentView

struct FilePreviewView: View {
    private let viewModel: AttachmentViewModel
    private let url: URL?
    private let mimeType: String
    private let fileType: MediaType

    init(data: AttachmentViewModel) {
        viewModel = data
        url = URL.localFilePath(fileName: data.data.name, folderName: data.data.id)
        mimeType = Self.getMimeType(fileName: data.data.name)
        fileType = MediaType.lookup(fileName: data.data.name) ?? MediaType.unknown
    }

    var body: some View {
        switch fileType {
        case .image:
            ImageAttachmentPreviewView(url: url!)
        case .video:
            VideoAttachmentPreviewView(viewModel: VideoAttachmentPreviewViewModel(for: viewModel, url: url!))
        case .audio:
            AudioAttachmentPreviewView(title: viewModel.data.name, url: url!)
        case .textDocument:
            DocumentAttachmentPreviewView(url: url, mimeType: mimeType)
        case .spatialModel:
            SpatialModelAttachmentPreviewView(url: url, mimeType: mimeType)
        case .unknown:
            Text("Unknown file type")
        }
    }

    private static func getMimeType(fileName: String) -> String {
        let fileExtension = URL(fileURLWithPath: fileName).pathExtension.lowercased()

        switch fileExtension {
        case "jpeg",
             "jpg":
            return "image/jpeg"
        case "png":
            return "image/png"
        case "gif":
            return "image/gif"
        case "pdf":
            return "application/pdf"
        case "mp4":
            return "video/mp4"
        case "m4a":
            return "audio/mp4"
        case "mp3":
            return "audio/mpeg"
        case "wav":
            return "audio/x-wav"
        case "mov":
            return "video/quicktime"
        case "heic":
            return "image/heic"
        case "heif":
            return "image/heif"
        case "webp":
            return "image/webp"
        default:
            print("ERROR MIME TYPE NOT FOUND FOR EXTENSION: \(fileExtension)")
            return ""
        }
    }
}
