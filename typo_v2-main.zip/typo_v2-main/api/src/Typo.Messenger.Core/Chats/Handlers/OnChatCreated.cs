using DotNetCore.CAP;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Typo.Messenger.Contracts;
namespace Typo.Messenger.Core.Chats.Handlers;
class OnChatCreated: ICapSubscribe
{
	private readonly IHubContext<ChatHub>   _hubContext;
	private readonly ILogger<OnChatCreated> _logger;
	public OnChatCreated(IHubContext<ChatHub> hubContext, ILogger<OnChatCreated> logger)
	{
		this._hubContext = hubContext;
		this._logger     = logger;
	}

	[CapSubscribe(nameof(ChatCreated))]
	public async Task Execute(ChatCreated @event)
	{
		foreach (var profileId in @event.ParticipantProfileIds)
		{
			var topicId = $"chat-created_{profileId}";
			await this._hubContext.Clients.Group(topicId).SendAsync(nameof(ChatCreated), @event.ChatId.ToString());
			this._logger.LogInformation($"Sent {nameof(ChatCreated)} to {topicId}");
		}
	}
}