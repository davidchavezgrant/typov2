using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public class SendFriendRequest
{
	[Fact]
	public void DoesNotAddRequest()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user1.SendFriendRequest(user2);

		// Assert
		user1.SentRequests.Should().ContainSingle();
		user2.ReceivedRequests.Should().ContainSingle();
	}

	[Fact]
	public void AddsRequestCorrectly()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		// Act
		user1.SendFriendRequest(user2);

		// Assert
		user1.SentRequests.Should().ContainSingle();
		user2.ReceivedRequests.Should().ContainSingle();
	}

	[Fact]
	public void DoesNotDuplicateFriendship_When_FriendExists()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);
		user2.AcceptFriendRequest(user1);

		// Act
		user1.SendFriendRequest(user2);

		// Assert
		user1.Friendships.Count(f => f.UserId == user2.UserId).Should().Be(1);
	}

	[Fact]
	public void DoesNotNotAddRequest_When_FriendRequestSentToSelf()
	{
		// Arrange
		var user = new UserProfile(Guid.NewGuid(), "User");

		// Act
		user.SendFriendRequest(user);

		// Assert
		user.SentRequests.Should().BeEmpty();
		user.ReceivedRequests.Should().BeEmpty();
	}

	[Fact]
	public void DoesNotCreateDuplicate_WhenAlreadyReceivedOne()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user2.SendFriendRequest(user1);

		// Act
		user1.SendFriendRequest(user2);

		// Assert
		user1.SentRequests.Should().ContainSingle();
		user2.ReceivedRequests.Should().ContainSingle();
	}

	[Fact]
	public void DoesNotAddRequest_When_AlreadyAcceptedRequestExists()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);
		user2.AcceptFriendRequest(user1);

		// Act
		user1.SendFriendRequest(user2);

		// Assert
		user1.SentRequests.Should().HaveCount(1);
		user2.ReceivedRequests.Should().HaveCount(1);
	}

	[Fact]
	public void DoesNotAddRequest_When_ExistingPendingRequestFromRecipient()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user2.SendFriendRequest(user1);

		// Act
		user1.SendFriendRequest(user2);

		// Assert
		user1.SentRequests.Should().HaveCount(1);
		user2.ReceivedRequests.Should().HaveCount(1);
	}
}