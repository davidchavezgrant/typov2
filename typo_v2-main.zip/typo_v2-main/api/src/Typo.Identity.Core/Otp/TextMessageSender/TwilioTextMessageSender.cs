using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Typo.Identity.Core.Otp.Model;
namespace Typo.Identity.Core.Otp.TextMessageSender;
internal sealed class TwilioTextMessageSender: ITextMessageSender
{
	private readonly IOptions<TextMessageSenderDetails> _options;

	public TwilioTextMessageSender(IOptions<TextMessageSenderDetails> options)
	{
		this._options = options;
	}

	/// <inheritdoc />
	public Task SendOtpTextMessageAsync(string phoneNumber, OneTimePassword otp)
	{
		string accountSid = this._options.Value.AccountSid;
		string authToken  = this._options.Value.AuthToken;

		TwilioClient.Init(accountSid, authToken);

		MessageResource.Create(body: $"Your Lines verification code is {otp.Value}",
							   from: new Twilio.Types.PhoneNumber("+14247811822"),
							   to: new Twilio.Types.PhoneNumber(phoneNumber));

		return Task.CompletedTask;
	}
	/// <inheritdoc />
	public async Task SendInvitationTextMessageAsync(string phoneNumber,
													 string senderName,
													 string recipientName)
	{
		string accountSid = this._options.Value.AccountSid;
		string authToken  = this._options.Value.AuthToken;

		TwilioClient.Init(accountSid, authToken);

		if (phoneNumber == "+17268006571")
			return;

		if (!phoneNumber.StartsWith("+1"))
			phoneNumber = $"+1{phoneNumber}";

		MessageResource.Create(body:
							   $"Hi {recipientName}! Your friend {senderName} has invited you to join Typo. Download the app here: https://typoapp.com/download",
							   from: new Twilio.Types.PhoneNumber("+17268006571"),
							   to: new Twilio.Types.PhoneNumber(phoneNumber));

		return;
	}
}