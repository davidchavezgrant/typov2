using Microsoft.EntityFrameworkCore;
namespace Typo.Identity.Core.Users;
internal class AppIdentityDbContext: DbContext, IUserRepository
{
	public AppIdentityDbContext(DbContextOptions<AppIdentityDbContext> options): base(options) {}

	public DbSet<User> Users => this.Set<User>();

	public async Task<User?> GetUserByPhoneNumberAsync(string phoneNumber)
	{
		var foundUser = await this.Users.FirstOrDefaultAsync(u => u.PhoneNumber == phoneNumber);
		return foundUser;
	}
	/// <inheritdoc />
	public async Task<User?> GetUserByEmailAddressAsync(string emailAddress)
	{
		var foundUser = await this.Users.FirstOrDefaultAsync(u => u.Email == emailAddress);
		return foundUser;
	}
	/// <inheritdoc />
	public async Task<bool> DeleteUserAsync(User user)
	{
		this.Users.Remove(user);
		await this.SaveChangesAsync();
		return true;
	}
	/// <inheritdoc />
	public async Task<User?> GetUserByUserId(Guid userId)
	{
		var user = await this.Users.FirstOrDefaultAsync(u => u.Id == userId);
		return user;
	}
	/// <inheritdoc />
	public async Task UpdateUser(User user)
	{
		this.Users.Update(user);
		await this.SaveChangesAsync();
	}

	public async Task<User?> CreateUserAsync(User user)
	{
		var entry = this.Users.Add(user);
		await this.SaveChangesAsync();
		return entry.Entity;
	}

	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		modelBuilder.Entity<User>().HasKey(u => u.Id);
		modelBuilder.Entity<User>().HasIndex(u => u.PhoneNumber).IsUnique();

		modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();
	}
}