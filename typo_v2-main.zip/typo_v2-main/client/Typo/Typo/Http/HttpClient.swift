import Foundation

// MARK: - HttpClient

internal final class HttpClient {
    // MARK: Lifecycle

    public init(baseUrl: String, token: String) {
        session = URLSession.shared
        self.baseUrl = baseUrl
        self.token = token
    }

    // MARK: Public

    /// HTTP GET
    public func getJson<T: Decodable>(url: String) async throws -> T {
        try await send(method: "GET", url: url)
    }

    public func getData(url: String) async throws -> Data {
        let _: EmptyBody = try await send(method: "GET", url: url, object: EmptyBody())
        return Data()
    }

    /// HTTP POST
    public func postJson<T: Encodable, U: Decodable>(url: String, object: T) async throws -> U {
        try await send(method: "POST", url: url, object: object)
    }

    public func postJson<T: Encodable>(url: String, object: T) async throws {
        let _: EmptyBody = try await send(method: "POST", url: url, object: object)
    }

    public func post(url: String) async throws {
        let _: EmptyBody = try await send(method: "POST", url: url, object: EmptyBody())
    }

    /// HTTP PUT
    public func putJson<T: Encodable, U: Decodable>(url: String, object: T) async throws -> U {
        try await send(method: "PUT", url: url, object: object)
    }

    public func putJson<T: Encodable>(url: String, object: T) async throws -> Void {
        try await send(method: "PUT", url: url, object: object)
    }

    public func put(url: String) async throws {
        let _: EmptyBody = try await send(method: "PUT", url: url, object: EmptyBody())
    }

    /// HTTP PATCH
    public func patchJson<T: Encodable, U: Decodable>(url: String, object: T) async throws -> U {
        try await send(method: "PATCH", url: url, object: object)
    }

    public func patch(url: String) async throws {
        let _: EmptyBody = try await send(method: "PATCH", url: url, object: EmptyBody())
    }

    /// HTTP DELETE
    public func delete<T: Decodable>(url: String) async throws -> T {
        try await send(method: "DELETE", url: url, object: EmptyBody())
    }

    public func delete(url: String) async throws {
        let _: EmptyBody = try await send(method: "DELETE", url: url, object: EmptyBody())
    }

    public func setActiveProfile(profileId: UUID) {
        activeProfileId = profileId
    }

    // MARK: Private

    private let session: URLSession
    private let baseUrl: String
    private let token: String
    private var activeProfileId: UUID?
    /// Sends a request to the given URL with the given method and object.
    private func send<T: Encodable, U: Decodable>(method: String, url: String, object: T) async throws -> U
    {
        let request = try createURLRequest(for: url, method: method, object: object)
        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200 ... 299).contains(httpResponse.statusCode)
        else {
            // Error response
            let apiError = try JSONDecoder().decode(ApiError.self, from: data)
            throw apiError
        }
        if data.isEmpty {
            return try JSONDecoder().decode(U.self, from: "{}".data(using: .utf8)!)
        } else {
            return try JSONDecoder().decode(U.self, from: data)
        }
    }

    /// send method for GET
    private func send<U: Decodable>(method: String, url: String) async throws -> U {
        let request = try createURLRequest(for: url, method: method)
        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200 ... 299).contains(httpResponse.statusCode)
        else {
            // Error response
            let apiError = try JSONDecoder().decode(ApiError.self, from: data)
            throw apiError
        }
        if data.isEmpty {
            return try JSONDecoder().decode(U.self, from: "{}".data(using: .utf8)!)
        } else {
            return try JSONDecoder().decode(U.self, from: data)
        }
    }

    private func send<T: Encodable>(method: String, url: String, object: T) async throws {
        let request = try createURLRequest(for: url, method: method, object: object)
        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200 ... 299).contains(httpResponse.statusCode)
        else {
            // Error response
            let apiError = try JSONDecoder().decode(ApiError.self, from: data)
            throw apiError
        }
        if !data.isEmpty {
            throw "ERROR: 139"
        }
    }

    /// Creates a URLRequest for the given URL, method, and object.
    private func createURLRequest<T: Encodable>(for route: String, method: String, object: T) throws -> URLRequest
    {
        let url = "\(baseUrl)\(route)"
        guard let url = URL(string: url)
        else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        let jsonData = try JSONEncoder().encode(object)
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        if activeProfileId != nil {
            print("Setting active profile id to \(activeProfileId!.uuidString)")

            request.setValue(activeProfileId!.uuidString, forHTTPHeaderField: "X-Active-Profile-Id")
        }

        return request
    }

    /// createURLRequest for GET requests
    private func createURLRequest(for route: String, method: String) throws -> URLRequest {
        let url = "\(baseUrl)\(route)"
        guard let url = URL(string: url)
        else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        if activeProfileId != nil {
            print("Setting active profile id to \(activeProfileId!.uuidString)")
            request.setValue(activeProfileId!.uuidString, forHTTPHeaderField: "X-Active-Profile-Id")
        }
        return request
    }
}
