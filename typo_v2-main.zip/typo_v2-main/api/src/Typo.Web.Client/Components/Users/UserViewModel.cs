using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Web.Client.Components.Users;
internal sealed class UserViewModel: IDisposable
{
	private readonly AuthStateProvider _authStateProvider;
	private readonly ProfileProvider   _profileProvider;
	public           string?           _error;
	public           string            _otp      = string.Empty;
	public           string            _username = string.Empty;
	public UserViewModel(AuthStateProvider authStateProvider, ProfileProvider profileProvider)
	{
		this._authStateProvider = authStateProvider;
		this._profileProvider   = profileProvider;
	}
	public bool                        IsAuthenticated => this._authStateProvider.IsAuthenticated;
	public IEnumerable<UserProfileDto> Profiles        => this._profileProvider.Profiles;
	public string                      Token           => this._authStateProvider.Token;
	public Guid                        UserId          => this._authStateProvider.UserId;
	public string                      Username        => this._authStateProvider.Username;
	/// <inheritdoc />
	public void Dispose()
	{
		this._authStateProvider.OnChange -= this.StateHasChanged;
		this._profileProvider.OnChange   -= this.StateHasChanged;
	}

	public event Action StateHasChanged = () => {};

	public async Task Initialize()
	{
		await this._profileProvider.Initialize();
		this._authStateProvider.OnChange += this.StateHasChanged;
		this._profileProvider.OnChange   += this.StateHasChanged;
	}

	private async Task Login()
	{
		var result = await this._authStateProvider.Login(this._username);
		if (result?.Error is not null)
		{
			this._error = result.Error.Message;
		}
	}

	public async Task Logout()
	{
		await this._authStateProvider.Logout();
		this._profileProvider.ClearCache();
	}
	public async Task Submit()
	{
		var result = await this._authStateProvider.Register(this._username);
		if (result.Error is Kernel.Error.Conflict)
		{
			await this.Login();
			return;
		}
		if (result?.Error is not null)
		{
			this._error = result.Error.Message;
		}
	}

	public async Task ValidateOtp()
	{
		var result = await this._authStateProvider.ValidateOtp(this._otp);
		if (result.IsSuccess)
		{
			var fetchResult = await this._profileProvider.FetchProfiles();
			if (fetchResult?.Error is not null)
			{
				this._error = fetchResult.Error.Message;
			}
		}
		else if (result?.Error is not null)
		{
			this._error = result.Error.Message;
		}
	}
}