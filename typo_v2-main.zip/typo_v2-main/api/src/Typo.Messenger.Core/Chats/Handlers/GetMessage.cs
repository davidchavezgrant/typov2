using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class GetMessage
{
	private readonly Guid               _chatId;
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _id;
	public GetMessage(Guid               chatId,
					  Guid               id,
					  MessengerDbContext dbContext)
	{
		this._chatId    = chatId;
		this._dbContext = dbContext;
		this._id        = id;
	}
	public async Task<Result<ChatMessageDto>> Execute()
	{
		var chat = await this._dbContext.Chats.Include(x => x.Messages)
							 .Include(c => c.Participants)
							 .FirstOrDefaultAsync(c => c.Id == this._chatId);

		var message = chat.Messages.FirstOrDefault(x => x.Id == this._id);

		if (message is null)
			return Error.NotFound("Message not found");

		return message.ToDto();
	}
}