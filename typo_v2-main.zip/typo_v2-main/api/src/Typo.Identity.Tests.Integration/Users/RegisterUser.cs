using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Users;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Identity.Tests.Integration.Test_Data;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Users;
public class RegisterUser: ApiTestBase
{
	public RegisterUser(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task ReturnsOk_When_UsernameIsValid(string username)
	{
		var request  = new RegisterRequest(username);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		response.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task CreatesUser_When_UsernameIsValid(string username)
	{
		var request       = new RegisterRequest(username);
		var response      = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		var createdUser   = await response.Content.ReadFromJsonAsync<User>();
		var createdUserId = createdUser?.Id;

		using var dbContext = this.CreateDbContext();
		dbContext.Users.Count().Should().Be(1);
		var foundUser = dbContext.Users.FirstOrDefault();
		foundUser.Should().NotBeNull();
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task ReturnsCorrectUserId_When_UsernameIsValid(string username)
	{
		using var dbContext     = this.CreateDbContext();
		var       initialCount  = dbContext.Users.Count();
		var       request       = new RegisterRequest(username);
		var       result        = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		var       createdUser   = await result.Content.ReadFromJsonAsync<User>();
		var       createdUserId = createdUser?.Id;
		var       foundUser     = dbContext.Users.FirstOrDefault();
		foundUser.Id.Should().Be(createdUserId.Value);
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task CreatesUserWithCorrectUsername_When_UsernameIsValid(string username)
	{
		using var dbContext = this.CreateDbContext();
		var       request   = new RegisterRequest(username);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		var createdUser = dbContext.Users.FirstOrDefault(u => u.Email == username || u.PhoneNumber == username);
		createdUser.Should().NotBeNull();
	}

	[Theory]
	[ClassData(typeof(InvalidEmails))]
	[ClassData(typeof(InvalidPhoneNumbers))]
	public async Task ReturnsBadRequest_When_UsernameIsInvalid(string username)
	{
		var request  = new RegisterRequest(username);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task ReturnsConflict_When_UsernameIsDuplicate(string username)
	{
		var request = new RegisterRequest(username);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		response.StatusCode.Should().Be(HttpStatusCode.Conflict);
	}

	[Theory]
	[ClassData(typeof(InvalidEmails))]
	[ClassData(typeof(InvalidPhoneNumbers))]
	public async Task DoesNotCreateUser_When_UsernameIsInvalid(string username)
	{
		using var dbContext    = this.CreateDbContext();
		var       initialCount = dbContext.Users.Count();
		var       request      = new RegisterRequest(username);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		var finalCount = dbContext.Users.Count();

		finalCount.Should().Be(initialCount);
	}

	[Theory]
	[ClassData(typeof(ValidEmails))]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task DoesNotCreateUser_When_UsernameIsDuplicate(string username)
	{
		var request = new RegisterRequest(username);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, request);
	}
}