using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Core.Profiles.Handlers;
using Typo.Messenger.Core.Profiles.Service;
namespace Typo.Messenger.Core.Profiles;
public static class Endpoints
{
	public static IEndpointRouteBuilder MapProfileEndpoints(this IEndpointRouteBuilder endpoints)
	{
		endpoints.MapPost("/api/profiles", HttpProfileService.CreateProfile)
				 .WithOpenApi()
				 .Produces<UserProfileDto>()
				 .WithDisplayName("CreateProfile")
				 .WithSummary("Creates a User Profile")
				 .WithDescription("Creates a new user profile for the authenticated user.");

		endpoints.MapPut("/api/profiles/{profileId}/picture", HttpProfileService.ChangeProfilePicture)
				 .WithOpenApi()
				 .WithDisplayName("ChangeProfilePicture")
				 .WithSummary("Changes a User Profile Picture")
				 .WithDescription("Changes the profile picture for a user profile");

		endpoints.MapGet("/api/profiles", HttpProfileService.GetProfiles)
				 .WithOpenApi()
				 .Produces<UserProfileListDto>()
				 .WithDisplayName("GetProfiles")
				 .WithSummary("Gets profiles for a user")
				 .WithDescription("Gets a list of all profiles associated with the authenticated user");

		endpoints.MapGet("/api/profiles/all", HttpProfileService.GetAllProfiles)
				 .WithOpenApi()
				 .Produces<UserProfileListDto>()
				 .WithDisplayName("GetAllProfiles")
				 .WithSummary("Gets all registered profiles")
				 .WithDescription("Gets a list of all profiles on the platform");

		endpoints.MapPatch("/api/profiles/{profileId}", HttpProfileService.UpdateProfile)
				 .WithOpenApi()
				 .Produces<List<UserProfileDto>>()
				 .WithDisplayName("UpdateProfile")
				 .WithSummary("Updates a User Profile")
				 .WithDescription("Updates the display name for a user profile");

		endpoints.MapDelete("/api/profiles/{profileId}", HttpProfileService.DeleteProfile)
				 .WithOpenApi()
				 .WithDisplayName("DeleteProfile")
				 .WithSummary("Deletes a User Profile")
				 .WithDescription("Deletes a User Profile by Id, if it exists");

		endpoints.MapPost("/api/profiles/{receiverId}/friends", HttpProfileService.SendFriendRequest)
				 .WithOpenApi()
				 .WithDisplayName("SendFriendRequest")
				 .WithSummary("Sends a friend request")
				 .WithDescription("Sends a friend request from the authenticated user to the specified user");

		endpoints.MapGet("/api/friends/requests/pending", HttpProfileService.GetPendingFriendRequests)
				 .WithOpenApi()
				 .Produces<FriendRequestListDto>()
				 .WithDisplayName("GetFriendRequests")
				 .WithSummary("Gets a list of friend requests")
				 .WithDescription("Gets a list of friend requests for the authenticated user");

		endpoints.MapPost("/api/friends/requests/{requestId}/accept", HttpProfileService.AcceptFriendRequest)
				 .WithOpenApi()
				 .WithDisplayName("AcceptFriendRequest")
				 .WithSummary("Accepts a friend request")
				 .WithDescription("Accepts a friend request from the authenticated user to the specified user");

		endpoints.MapPost("/api/friends/requests/{requestId}/reject", HttpProfileService.RejectFriendRequest)
				 .WithOpenApi()
				 .WithDisplayName("RejectFriendRequest")
				 .WithSummary("Rejects a friend request")
				 .WithDescription("Rejects a friend request from the authenticated user to the specified user");

		endpoints.MapGet("/api/friends", HttpProfileService.GetFriendships)
				 .WithOpenApi()
				 .Produces<List<UserProfileDto>>()
				 .WithDisplayName("GetFriends")
				 .WithSummary("Gets a list of friends")
				 .WithDescription("Gets a list of friends for the authenticated user");

		endpoints.MapDelete("/api/friends/{profileId}", HttpProfileService.DeleteFriendship)
				 .WithOpenApi()
				 .WithDisplayName("DeleteFriend")
				 .WithSummary("Deletes a friendship")
				 .WithDescription("Deletes a friendship for the authenticated user");

		endpoints.MapGet("/api/profiles/{profileId}", HttpProfileService.GetProfile)
				 .WithOpenApi()
				 .Produces<UserProfileDto>()
				 .WithDisplayName("GetProfile")
				 .WithSummary("Gets a profile")
				 .WithDescription("Gets a profile by Id");

		endpoints.MapPost("/api/friends/requests/{requestId}/cancel", HttpProfileService.CancelFriendRequest)
				 .WithOpenApi()
				 .WithDisplayName("CancelFriendRequest")
				 .WithSummary("Cancels a friend request")
				 .WithDescription("Cancels a friend request from the authenticated user to the specified user");
		return endpoints;
	}
}