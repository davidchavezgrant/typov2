using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Options;
using Typo.Kernel.Configuration;
namespace Typo.Messenger.Core.Chats;
interface IFileStorageService
{
	Task<UploadImageResponse> Upload(string fileName, Stream fileStream);
}
public sealed record UploadImageResponse(Guid ImageId, Uri ImageUrl);
public class FileStorageService: IFileStorageService
{
	private readonly IAmazonS3 _s3Client;
	private readonly string    _bucketName;

	public FileStorageService(IOptions<AwsAccountDetails> options)
	{
		this._s3Client = new AmazonS3Client(options.Value.AccessKeyId,
											options.Value.SecretAccessKey,
											RegionEndpoint.GetBySystemName("us-east-1"));
		this._bucketName = "typo-chat-images";
	}

	public async Task<UploadImageResponse> Upload(string fileName, Stream fileStream)
	{
		var fileTransferUtility = new TransferUtility(this._s3Client);
		var imageId             = Guid.NewGuid();

		var uploadRequest = new TransferUtilityUploadRequest
		{
			InputStream = fileStream,
			Key         = $"{imageId}/{fileName}",
			BucketName  = this._bucketName,
			CannedACL   = S3CannedACL.PublicRead // Makes file publicly accessible
		};

		await fileTransferUtility.UploadAsync(uploadRequest);
		return new UploadImageResponse(imageId, new Uri($"https://{this._bucketName}.s3.amazonaws.com/{imageId}/{fileName}"));
	}
}