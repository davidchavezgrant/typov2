using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.Model;
using Typo.Identity.Core.Otp.Service;
using Typo.Identity.Core.Users;
using Typo.Kernel;
namespace Typo.Identity.Core.Handlers;
class SendOtp
{
	private readonly IOtpService  _otp;
	private readonly IUserService _users;

	public SendOtp(IOtpService otp, IUserService users)
	{
		this._otp   = otp;
		this._users = users;
	}
	public async Task<Result> Execute(SendOtpRequest request)
	{
		var email       = new EmailAddress(request.Value);
		var phoneNumber = new PhoneNumber(request.Value);
		var emailExists = await this._users.EmailExists(new EmailAddress(request.Value));
		var phoneExists = await this._users.PhoneExists(new PhoneNumber(request.Value));

		if (!emailExists && !phoneExists)
		{
			return Error.NotFound("User not found.");
		}
		if (email.IsValid())
		{
			await this._otp.SendOtpAsync(email);
			return Result.Ok;
		}

		if (phoneNumber.IsValid())
		{
			await this._otp.SendOtpAsync(phoneNumber);
			return Result.Ok;
		}
		return new Error.Invalid($"Invalid user identifier: {phoneNumber.Value} or {email.Value}");
	}
}