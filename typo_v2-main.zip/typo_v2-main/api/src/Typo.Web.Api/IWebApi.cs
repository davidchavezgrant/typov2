namespace Typo.Web.Api;
public interface IWebApi;