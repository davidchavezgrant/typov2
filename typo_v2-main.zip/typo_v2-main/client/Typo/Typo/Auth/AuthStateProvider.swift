import KeychainSwift
import SwiftUI

// MARK: - AuthStateProvider

final class AuthStateProvider: ObservableObject {
    @Published
    public private(set) var isValidated = false
    @Published
    public private(set) var accessToken: String?
    @Published
    public private(set) var refreshToken: String?

    public func update(newState: AuthState) {
        accessToken = newState.accessToken
        refreshToken = newState.refreshToken

        if accessToken != nil, refreshToken != nil {
            isValidated = true
        }

        let encodedState = try! JSONEncoder().encode(newState)
        Task
            { KeychainSwift().set(String(data: encodedState, encoding: .utf8)!, forKey: "authState") }
    }

    public func initialize() {
        let storedState = KeychainSwift().get("authState")
        if storedState != nil {
            let authState = try! JSONDecoder().decode(AuthState.self, from: storedState!.data(using: .utf8)!)
            update(newState: authState)
        }
    }

    public func logout() {
        accessToken = nil
        refreshToken = nil
        isValidated = false
        KeychainSwift().delete("authState")
        KeychainSwift().clear()
    }
}

// MARK: - AuthState

struct AuthState: Codable {
    var registered: Bool
    var isValidated: Bool
    var sentOtp: Bool
    var accessToken: String?
    var refreshToken: String?
    var error: String?
}
