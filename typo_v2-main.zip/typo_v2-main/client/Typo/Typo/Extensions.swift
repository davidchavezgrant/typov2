import Foundation
import SwiftUI

// MARK: - String + Error

/// allows String to be used as an Error
/// example: `throw "error message"`
extension String: Error {}

public extension UUID {
    /// Returns true if the UUID is empty
    func isEmpty() -> Bool {
        self == UUID(uuidString: "00000000-0000-0000-0000-000000000000")!
    }

    /// Returns true if the UUID is not empty
    func isNotEmpty() -> Bool {
        !isEmpty()
    }

    /// Returns a new UUID with all zeros
    var empty: UUID
    { UUID(uuidString: "00000000-0000-0000-0000-000000000000")! }

    /// Returns randomly generated UUID
    static func NewGuid() -> UUID
    { UUID() }
}

extension ScrollViewProxy {
    /// Scrolls to the bottom of the scroll view
    /// using the id "bottom"
    func scrollToBottom() {
        withAnimation {
            scrollTo("bottom", anchor: .bottom)
        }
    }
}

extension NSAttributedString.Key {
    static let pill = NSAttributedString.Key("Pill")
}

import AVFoundation
import Foundation
import SwiftUI

extension URL {
    static func localFilePath(fileName: String, folderName: UUID) -> URL? {
        if let directoryUrl = try? FileManager.default
            .url(for: .documentDirectory,
                 in: .userDomainMask,
                 appropriateFor: nil,
                 create: false)
            .appendingPathComponent(Constants.ArtifactFilesDirectory)
            .appendingPathComponent(folderName.uuidString.lowercased())
        {
            if !FileManager.default.fileExists(atPath: directoryUrl.path) {
                try? FileManager.default.createDirectory(at: directoryUrl, withIntermediateDirectories: true)
            }
            // copy file over
            let localUrl = directoryUrl.appendingPathComponent(fileName)
            return localUrl
        }
        return nil
    }
}
