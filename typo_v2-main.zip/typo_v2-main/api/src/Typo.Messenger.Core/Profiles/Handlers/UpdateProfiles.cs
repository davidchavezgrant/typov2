using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class UpdateProfile
{
	private readonly MessengerDbContext       _dbContext;
	private readonly Guid                     _profileId;
	private readonly UpdateDisplayNameRequest _request;
	public UpdateProfile(Guid                     profileId,
						 UpdateDisplayNameRequest request,
						 MessengerDbContext       dbContext)
	{
		this._profileId = profileId;
		this._request   = request;
		this._dbContext = dbContext;
	}
	public async Task<Result<UserProfileDto>> Execute()
	{
		var profile = await this._dbContext.Profiles.FirstOrDefaultAsync(p => p.Id == this._profileId);
		if (profile is null) return Error.NotFound("Profile not found");

		bool alreadyTaken = await this._dbContext.Profiles.AnyAsync(p => p.Nickname == this._request.NewDisplayName);

		if (alreadyTaken) return new Error.Conflict($"Nickname {this._request.NewDisplayName} is already taken");

		profile.UpdateDisplayName(this._request.NewDisplayName);
		await this._dbContext.SaveChangesAsync();
		return profile.ToDto();
	}
}