import SwiftUI

// MARK: - AttachmentContentView

struct AttachmentContentView: View {
    @ObservedObject var viewModel: AttachmentViewModel
    var body: some View {
        HStack(alignment: .center, spacing: 0) {
            switch viewModel.data {
            case is LinkAttachmentData:
                LinkPreviewView(for: viewModel)
            case is FileAttachmentData:
                FilePreviewView(data: viewModel)
            case is SystemMessageAttachmentData:
                Text(viewModel.data.displayText)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.black)
                    .lineLimit(1)
                    .truncationMode(.tail)
            default:
                Text("Unknown attachment type")
            }
        }
        .padding(.top, -10)
    }
}
