using Typo.Kernel.Abstract;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Core.Chats.Domain;
internal sealed class ChatParticipant: Entity<Guid>
{
	private ChatParticipant() {}
	public ChatParticipant(Chat room, UserProfile userProfile)
	{
		this.Room          = room;
		this.Nickname      = userProfile.Nickname;
		this.UserProfileId = userProfile.Id;
	}
	public string Nickname      { get; private set; }
	public Chat   Room          { get; private set; }
	public Guid   UserProfileId { get; private set; }
}