using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core.Jwt;
public static class JwtFactory
{
	public static string CreateAccessToken(IEnumerable<Claim> claims, JwtSettings jwt)
	{
		ThrowIfNullOrEmpty(jwt);

		// Create the JWT security token and encode it
		var bytes = Encoding.UTF8.GetBytes(jwt.SecurityKey);
		var key   = new SymmetricSecurityKey(bytes);

		// Create the signing credentials
		var signingCreds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

		// Set expiry based on settings
		var expiryInSeconds = Convert.ToInt32(jwt.AccessTokenExpiryInSeconds);
		var expiry          = DateTime.Now.AddSeconds(expiryInSeconds);

		// Create token
		var token = new JwtSecurityToken(jwt.Issuer,
										 jwt.Audience,
										 claims,
										 expires: expiry,
										 signingCredentials: signingCreds);

		var     handler     = new JwtSecurityTokenHandler();
		string? tokenString = handler.WriteToken(token);
		return tokenString;
	}

	private static void ThrowIfNullOrEmpty(JwtSettings jwt)
	{
		if (jwt is null)
			throw new ArgumentNullException(nameof(jwt));

		if (jwt.AccessTokenExpiryInSeconds.IsNullOrEmpty())
			throw new FormatException("Jwt expiry cannot be null or empty!");

		if (jwt.SecurityKey.IsNullOrEmpty())
			throw new FormatException("Jwt security key cannot be null or empty!");

		if (jwt.Issuer.IsNullOrEmpty())
			throw new FormatException("Jwt issuer cannot be null or empty.");

		if (jwt.Audience.IsNullOrEmpty())
			throw new FormatException("Jwt audience cannot be null or empty.");
	}

	public static ClaimsPrincipal? ValidateToken(string token, JwtSettings settings)
	{
		var tokenHandler = new JwtSecurityTokenHandler();

		try
		{
			var principal = tokenHandler.ValidateToken(token,
													   new TokenValidationParameters
													   {
														   ValidateIssuerSigningKey = true,
														   IssuerSigningKey =
															   new SymmetricSecurityKey(Encoding.UTF8.GetBytes(settings
																												   .SecurityKey)),
														   ValidateIssuer   = false,
														   ValidateAudience = false
													   },
													   out _);

			return principal;
		}
		catch
		{
			return null;
		}
	}

	public static string CreateRefreshToken(string userId, JwtSettings jwt)
	{
		ThrowIfNullOrEmpty(jwt);

		var bytes        = Encoding.UTF8.GetBytes(jwt.SecurityKey);
		var key          = new SymmetricSecurityKey(bytes);
		var signingCreds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

		// Set a longer expiry for refresh tokens
		var expiryInDays = Convert.ToInt32(jwt.RefreshTokenExpiryInDays); // Assuming you add this to JwtSettings
		var expiry       = DateTime.Now.AddDays(expiryInDays);

		var claims = new List<Claim>
		{
			new Claim(ClaimTypes.NameIdentifier, userId)
		};

		var token = new JwtSecurityToken(jwt.Issuer,
										 jwt.Audience,
										 claims,
										 expires: expiry,
										 signingCredentials: signingCreds);

		var     handler     = new JwtSecurityTokenHandler();
		string? tokenString = handler.WriteToken(token);
		return tokenString;
	}
}