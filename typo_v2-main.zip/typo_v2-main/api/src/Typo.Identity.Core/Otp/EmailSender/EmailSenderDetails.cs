namespace Typo.Identity.Core.Otp.EmailSender;
public sealed record EmailSenderDetails
{
	public const string SECTION_NAME = "EmailSender";

	public string Username { get; set; } = string.Empty;
	public string Password { get; set; } = string.Empty;
	public string Host     { get; set; } = string.Empty;
}