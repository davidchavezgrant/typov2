using DotNetCore.CAP;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Typo.Kernel;
using Typo.Messenger.Core.Chats;
using Typo.Messenger.Core.Chats.Handlers;
using Typo.Messenger.Core.DAL;
using Typo.Messenger.Core.Profiles.Service;
namespace Typo.Messenger.Core;
public static class Extensions
{
	public static IServiceCollection AddChatServices(this IServiceCollection services, string? connectionString)
	{
		services.AddDbContext<MessengerDbContext>(builder => builder.UseNpgsql(connectionString));
		services.AddDbContextFactory<MessengerDbContext>(builder => builder.UseNpgsql(connectionString), ServiceLifetime.Scoped);
		services.AddTransient<IProfileService, ProfileService>();
		services.AddTransient<IChatService, ChatService>();
		services.AddTransient<FileUploadService>();
		services.AddTransient<ICapSubscribe, OnChatCreated>();
		services.AddTransient<ICapSubscribe, OnMessageSent>();
		services.AddTransient<IFileStorageService, FileStorageService>();
		services.AddSignalR();
		return services;
	}

	public static IResult AsHttpResult<T>(this Result<T> result, string location)
	{
		return result.As(x => Results.Ok(x), x => x.ToHttpResult(location));
	}
	public static IResult ToHttpResult(this Error error, string route)
		=> error.GetType() switch
		   {
			   _ when error is Error.NotFoundError    => Results.NotFound(error.Message),
			   _ when error is Error.Conflict         => Results.Problem(error.Message, route, StatusCodes.Status409Conflict),
			   _ when error is Error.Unauthorized     => Results.Unauthorized(),
			   _ when error is Error.Invalid          => Results.Problem(error.Message, route, StatusCodes.Status400BadRequest),
			   _ when error is Error.ExceptionalError => Results.BadRequest(error.Message),
			   _ when error is Error.NoError          => Results.NoContent(),
			   _                                      => Results.BadRequest("Unknown error.")
		   };
}