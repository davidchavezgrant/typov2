using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Chats.Handlers;
internal sealed class AddComment
{
	private readonly AddCommentRequest  _request;
	private readonly Guid               _chatId;
	private readonly Guid               _messageId;
	private readonly Guid               _senderId;
	private readonly MessengerDbContext _db;
	public AddComment(AddCommentRequest  request,
					  Guid               chatId,
					  Guid               messageId,
					  Guid               senderId,
					  MessengerDbContext db)
	{
		this._request   = request;
		this._chatId    = chatId;
		this._messageId = messageId;
		this._senderId  = senderId;
		this._db        = db;
	}

	public async Task<Result<CommentDto>> Execute()
	{
		var sender = await this._db.Profiles.FirstOrDefaultAsync(x => x.Id == this._senderId);

		if (sender is null)
			return Error.NotFound("Sender not found");

		var chat = await this._db.Chats.Include(x => x.Messages).FirstOrDefaultAsync(x => x.Id == this._chatId);

		if (chat is null)
			return Error.NotFound("Message not found");

		var message = chat.Messages.FirstOrDefault(x => x.Id == this._messageId);

		if (message is null)
			return Error.NotFound("Message not found");

		var unixTimeMilliseconds = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

		var comment = message.AddComment(this._request.Text, unixTimeMilliseconds, sender);
		await this._db.SaveChangesAsync();

		return comment.ToDto();
	}
}