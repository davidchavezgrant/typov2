import Combine
import Foundation
import SignalRClient
import SwiftUI

final class RtcProvider: ObservableObject, HubConnectionDelegate, ChatPublisher, MessagePublisher {
    public func subscribe(_ subscriber: any ChatSubscriber) {
        newChatSubscribers.append(subscriber)
    }

    public func unsubscribe(_ subscriber: any ChatSubscriber) {
        newChatSubscribers.removeAll(where: { $0.id == subscriber.id })
    }

    public func subscribe(_ subscriber: any MessageSubscriber) {
        newMessageSubscribers.append(subscriber)
    }

    public func unsubscribe(_ subscriber: any MessageSubscriber) {
        newMessageSubscribers.removeAll(where: { $0.id == subscriber.id })
    }

    private var newChatSubscribers: [any ChatSubscriber] = []
    private var newMessageSubscribers: [any MessageSubscriber] = []
    private let id = UUID()
    let url: URL
    private var connection: HubConnection?
    var cancellable: AnyCancellable? = nil
    private var isConnected = false
    private let profileId: UUID?

    public init(_ baseUrl: String, profileId: UUID?) {
        self.profileId = profileId
        url = URL(string: baseUrl + "rtm/chat")!
        cancellable = NotificationCenter.default.publisher(for: willTerminateNotification)
            .sink { _ in
                self.connection?.stop()
                Thread.sleep(forTimeInterval: 1.0) // wait for disconnect
            }
    }

    public func connectionDidOpen(hubConnection: HubConnection) {
        let userProfileId = profileId
        hubConnection.send(method: "SubscribeToProfileChatsCreated", userProfileId) {
            (error: Error?) in
            if error != nil {
                print("ERROR: \(String(describing: error))")
            }
            print("Subscribed to userprofileid \(userProfileId)")
        }
    }

    public func subscribeToChatMessagesSent(chatId: UUID) {
        connection!.send(method: "SubscribeToChatMessagesSent", chatId) {
            (error: Error?) in
            if error != nil {
                print("ERROR: \(String(describing: error))")
            }
            print("Subscribed to chat \(chatId)")
        }
    }

    public func connectionDidFailToOpen(error _: Error)
    {}

    public func connectionDidClose(error _: Error?)
    {}

    public func connectionWillReconnect(error _: Error)
    {}

    public func connectionDidReconnect()
    {}

    // MARK: - Public

    func connect(authStateProvider: AuthStateProvider) async throws {
        if isConnected {
            return
        }
        let httpConnectionOptions = HttpConnectionOptions()
        let token = authStateProvider.accessToken ?? ""
        let value = "Bearer \(token)"
        httpConnectionOptions.headers = ["Authorization": value]
        let httpClient = HttpClient(baseUrl: Config.baseUrl, token: authStateProvider.accessToken!)

        connection = HubConnectionBuilder(url: url).withHubConnectionDelegate(delegate: self)
            .withLogging(minLogLevel: .error)
            .withHttpConnectionOptions(configureHttpOptions: { options in
                options.headers = httpConnectionOptions.headers
            })
            .build()
        connection!.on(method: "ChatCreated") { [self]
            (message: String) in
                for subscriber in newChatSubscribers {
                    subscriber.onReceivedChat(chatId: UUID(uuidString: message)!)
                }
        }
        connection!.on(method: "MessageSent") { [self]
            (serializedEvent: String) in
                let message = try! JSONDecoder().decode(MessageReceivedEvent.self,
                                                        from: serializedEvent.data(using: .utf8)!)
                for subscriber in newMessageSubscribers {
                    subscriber.onReceivedMessage(event: message)
                }
        }
        connection!.start()
        isConnected = true
    }

    private var willTerminateNotification: Notification.Name {
        #if os(macOS)
            return NSApplication.willTerminateNotification
        #else
            return UIApplication.willTerminateNotification
        #endif
    }
}

protocol ChatSubscriber: AnyObject, Identifiable {
    func onReceivedChat(chatId: UUID)
}

protocol ChatPublisher: AnyObject {
    func subscribe(_ subscriber: any ChatSubscriber)
    func unsubscribe(_ subscriber: any ChatSubscriber)
}

protocol MessageSubscriber: AnyObject, Identifiable {
    func onReceivedMessage(event: MessageReceivedEvent)
}

protocol MessagePublisher: AnyObject {
    func subscribe(_ subscriber: any MessageSubscriber)
    func unsubscribe(_ subscriber: any MessageSubscriber)
}

struct MessageReceivedEvent: Codable {
    let chatId: UUID
    let messageId: UUID
}
