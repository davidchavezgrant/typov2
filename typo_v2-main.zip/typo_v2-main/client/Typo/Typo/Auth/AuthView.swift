import Foundation
import SwiftUI

struct AuthView: View {
    @StateObject
    private var model = AuthViewModel()
    @EnvironmentObject
    var authStateProvider: AuthStateProvider

    var body: some View {
        VStack {
            Text("Typo")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 50)
            TextField(model.sentOtp ? "OTP" : "Username", text: $model.input)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.bottom, 20)

            if model.isAuthenticating {
                ProgressView()
            } else {
                Button("Login") {
                    model.submit(authStateProvider)
                }
                .disabled(model.loginDisabled)
            }

            if let authError = model.authError {
                Text(authError)
            }
            Spacer()
        }
    }
}
