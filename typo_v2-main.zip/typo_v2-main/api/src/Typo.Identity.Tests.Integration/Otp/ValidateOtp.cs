using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Handlers;
using Typo.Identity.Core.Otp;
using Typo.Identity.Core.Otp.EmailSender;
using Typo.Identity.Core.Otp.TextMessageSender;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Otp;
public class ValidateOtp: ApiTestBase
{
	/// <inheritdoc />
	public ValidateOtp(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsOk_When_OtpIsCorrect()
	{
		var email = $"example@example.com";
		await this.AddUserWithEmail(email);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var code    = FakeEmailSender.SentCodes[email];
		var request = new AuthRequest(email, code.Value);

		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);

		response.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Fact]
	public async Task ReturnsJwt_When_OtpIsCorrect()
	{
		var email = $"example@example.com";
		await this.AddUserWithEmail(email);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var code    = FakeEmailSender.SentCodes[email];
		var request = new AuthRequest(email, code.Value);

		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);
		var result   = await response.Content.ReadFromJsonAsync<AuthResponse>();

		result.Should().NotBeNull();
		result?.AccessToken.Should().NotBeNullOrEmpty();
	}

	[Fact]
	public async Task ConfirmsEmail_When_OtpIsCorrect()
	{
		using var dbContext = this.CreateDbContext();
		var       email     = "example@example.com";
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.REGISTER, new RegisterRequest(email));
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var code    = FakeEmailSender.SentCodes[email];
		var request = new AuthRequest(email, code.Value);

		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);

		var foundUser = await dbContext.Users.FirstOrDefaultAsync(u => u.Email == email);
		foundUser?.EmailConfirmed.Should().BeTrue();
	}

	[Fact]
	public async Task ConfirmsPhoneNumber_When_OtpIsCorrect()
	{
		using var dbContext = this.CreateDbContext();
		var       phone     = "+12107921430";
		await this.AddUserWithPhoneNumber(phone);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(phone));
		var code    = FakeTextMessageSender.SentCodes[phone];
		var request = new AuthRequest(phone, code.Value);

		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);

		var foundUser = await dbContext.Users.FirstOrDefaultAsync(u => u.PhoneNumber == phone);
		foundUser?.PhoneNumberConfirmed.Should().BeTrue();
	}

	[Fact]
	public async Task ReturnsBadRequest_When_OtpIsIncorrect()
	{
		var email = $"example@example.com";
		await this.AddUserWithEmail(email);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var request = new AuthRequest(email, "123456");

		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);

		response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
	}

	[Fact]
	public async Task DoesNotReturnJwt_When_OtpIsIncorrect()
	{
		var email = $"example@example.com";
		await this.AddUserWithEmail(email);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var request = new AuthRequest(email, "123456");

		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);
		response.Content.Headers.ContentType?.MediaType.Should().NotBe("application/json");
	}

	[Fact]
	public async Task ReturnsBadRequest_When_OtpIsInvalid()
	{
		var email = $"example@example.com";
		await this.AddUserWithEmail(email);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var request = new AuthRequest(email, "2");

		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);

		response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
	}

	[Fact]
	public async Task DoesNotReturnJwt_When_OtpIsInvalid()
	{
		var email = $"example@example.com";
		await this.AddUserWithEmail(email);
		await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, new SendOtpRequest(email));
		var request = new AuthRequest(email, "2");

		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);
		response.Content.Headers.ContentType?.MediaType.Should().NotBe("application/json");
	}

	[Fact]
	public async Task ReturnsNotFound_When_UserDoesNotExist()
	{
		var request  = new AuthRequest("davidgrant@me.com", "212345");
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.VALIDATE_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.NotFound);
	}
}