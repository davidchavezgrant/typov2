using System.Net.Http.Json;
using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ProfileTests.FriendRequests;
public class GetFriendRequests: ApiTestBase
{
	/// <inheritdoc />
	public GetFriendRequests(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task ReturnsReceivedRequests()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);

		// Act
		this.SetActiveProfileHeader(them.Id);
		var response = await this.ApiClient.GetFromJsonAsync<FriendRequestListDto>($"/api/friends/requests/pending");

		// Assert
		response.Should().NotBeNull();
		response?.Requests.Count().Should().Be(1);
	}

	[Fact]
	public async Task ReturnsSentRequests()
	{
		// Arrange
		var me   = await this.CreateProfile("user1");
		var them = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(me.Id);
		await this.ApiClient.PostAsync($"/api/profiles/{them.Id}/friends", null);

		// Act
		var response = await this.ApiClient.GetFromJsonAsync<FriendRequestListDto>($"/api/friends/requests/pending");

		// Assert
		response.Should().NotBeNull();
		response?.Requests.Count().Should().Be(1);
	}
}