
import AVKit
import Foundation
import SwiftUI

/// A view that displays a preview of an audio attachment
struct AudioAttachmentPreviewView: View {
    static let titleFont = Font.system(size: 15).weight(.medium)
    static let labelFont = Font.system(size: 12)
    static let foregroundPrimary = Color(red: 0.1, green: 0.1, blue: 0.1)
    static let foregroundSecondary = Color(red: 0.49, green: 0.49, blue: 0.49)
    static let background = Color(red: 0.1, green: 0.1, blue: 0.1).opacity(0.7)
    let sizeMb: String
    @StateObject
    private var audioPlayer: AudioPlayer
    @State
    private var isPlaying = false
    let title: String

    init(title: String, url: URL, sizeMb: String = "0.0MB") {
        self.title = title
        self.sizeMb = sizeMb
        _audioPlayer = StateObject(wrappedValue: AudioPlayer(url: url))
    }

    public var body: some View {
        VStack(alignment: .leading) {
            HStack(alignment: .center, spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    titleLabel
                    sizeMbLabel
                }
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .padding(.horizontal, 4)
                .padding(.vertical, 0)
                togglePlayButton
            }
            timestampLabel
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Colors.BackgroundSolid)
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16)
            .inset(by: 0.5)
            .stroke(Colors.Border, lineWidth: 1)
        )
    }

    private var titleLabel: some View {
        Text(title)
            .font(Self.titleFont)
            .foregroundColor(Self.foregroundPrimary)
            .frame(maxWidth: .infinity, alignment: .topLeading)
    }

    private var sizeMbLabel: some View {
        Text("\(sizeMb)")
            .font(Self.labelFont)
            .foregroundColor(Self.foregroundSecondary)
            .frame(width: 39.51613, alignment: .topLeading)
    }

    private var timestampLabel: some View {
        Text(String(format: "%d:%02d", Int(audioPlayer.currentTime) / 60, Int(audioPlayer.currentTime) % 60))
            .font(Self.labelFont)
            .foregroundColor(Self.foregroundSecondary)
    }

    private var togglePlayButton: some View {
        Button(action: togglePlayback) {
            ZStack {
                Image(systemName: "ellipsis.circle.fill")
                    .frame(width: 32, height: 32)
                    .background(Self.background)
                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .font(Self.titleFont)
                    .multilineTextAlignment(.center)
                    .foregroundColor(Colors.BackgroundSolid)
            }
            .frame(width: 32, height: 32)
        }
    }

    private func togglePlayback() {
        isPlaying.toggle()
        isPlaying ? audioPlayer.play() : audioPlayer.pause()
    }
}
