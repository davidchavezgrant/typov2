using System.Security.Claims;
using Typo.Identity.Core.Jwt;
using Typo.Kernel.Configuration;
namespace Typo.Identity.Core.Users;
internal sealed record UserSessionToken(
string     Username,
string     Jwt,
DateTime   ExpiresAt,
int        TimeRemaining,
AuthMethod AuthType)
{
	public UserSessionToken Create(JwtSettings jwtSettings,
								   AuthMethod  authType,
								   string      userName)
	{
		var claims = new[]
		{
			new Claim(ClaimTypes.Name,    userName),
			new Claim(nameof(AuthMethod), authType.ToString())
		};

		string jwt                  = JwtFactory.CreateAccessToken(claims, jwtSettings);
		double minutes              = double.Parse(jwtSettings.AccessTokenExpiryInSeconds);
		var    expiresAt            = DateTime.Now.AddMinutes(minutes);
		var    timeRemaining        = expiresAt.Subtract(DateTime.Now);
		var    timeRemainingSeconds = (int)timeRemaining.TotalSeconds;

		var token = new UserSessionToken(userName,
										 jwt,
										 expiresAt,
										 timeRemainingSeconds,
										 authType);
		return token;
	}
}