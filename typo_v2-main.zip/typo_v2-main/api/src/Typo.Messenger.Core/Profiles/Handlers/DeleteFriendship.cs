using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class DeleteFriendship
{
	private readonly Guid               _myId;
	private readonly Guid               _profileId;
	private readonly MessengerDbContext _dbContext;
	public DeleteFriendship(Guid               myId,
							Guid               profileId,
							MessengerDbContext dbContext)
	{
		this._myId      = myId;
		this._profileId = profileId;
		this._dbContext = dbContext;
	}
	public async Task<Result> Execute()
	{
		var me = await this._dbContext.Profiles.Include(p => p.Friendships)
						   .Include(p => p.SentRequests)
						   .Include(p => p.ReceivedRequests)
						   .FirstOrDefaultAsync(p => p.Id == this._myId);

		var friend = await this._dbContext.Profiles.Include(p => p.Friendships)
							   .Include(p => p.SentRequests)
							   .Include(p => p.ReceivedRequests)
							   .FirstOrDefaultAsync(p => p.Id == this._profileId);

		me?.DeleteFriendship(friend);
		await this._dbContext.SaveChangesAsync();
		return Result.Ok;
	}
}