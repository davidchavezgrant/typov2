using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public sealed class Misc
{
	[Fact]
	public void HandleMultipleFriendRequestsFromSameUser_ShouldBehaveCorrectly()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.AcceptFriendRequest(user1);
		user2.RejectFriendRequest(user1);

		// Assert
		user1.Friendships.Should().Contain(user2);
		user2.Friendships.Should().Contain(user1);
	}

	[Fact]
	public void ToDto_ShouldCorrectlyMapProperties()
	{
		// Arrange
		var userId      = Guid.NewGuid();
		var nickname    = "TestUser";
		var userProfile = new UserProfile(userId, nickname);

		// Act
		var dto = userProfile.ToDto();

		// Assert
		dto.UserId.Should().Be(userId);
		dto.DisplayName.Should().Be(nickname);
	}
}