using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public class Create
{
	[Theory]
	[InlineData(null)]
	[InlineData("")]
	public void ShouldThrowException_WhenNullOrEmptyNickname(string nickname)
	{
		// Act & Assert
		Assert.Throws<ArgumentException>(() => new UserProfile(Guid.NewGuid(), nickname));
	}

	[Fact]
	public void ShouldSetPropertiesCorrectly()
	{
		// Arrange
		var userId   = Guid.NewGuid();
		var nickname = "TestUser";

		// Act
		var userProfile = new UserProfile(userId, nickname);

		// Assert
		userProfile.UserId.Should().Be(userId);
		userProfile.Nickname.Should().Be(nickname);
	}
}