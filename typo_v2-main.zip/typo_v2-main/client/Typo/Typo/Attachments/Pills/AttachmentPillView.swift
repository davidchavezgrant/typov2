import Foundation
import SwiftUI

struct AttachmentPillView: View {
    @ObservedObject
    var parent: MessageViewModel
    @ObservedObject
    var viewModel: AttachmentViewModel

    private var colorScheme: ColorScheme {
        ColorScheme.create(for: PillStatus.new(state: viewModel.isActive ? .focused : .unselected))
    }

    init(parent: MessageViewModel, viewModel: AttachmentViewModel) {
        self.viewModel = viewModel
        self.parent = parent
    }

    var body: some View {
        Button(action: {
            viewModel.isActive = true
            parent.activeAttachment = viewModel
        }) {
            HStack(alignment: .center, spacing: 4.0) {
                if let image = viewModel.thumbnail {
                    Image(nsImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 16.0, height: 16.0)
                        .clipped()
                }
                let text = viewModel.data.displayText
                Text(text)
                    .font(.system(size: 12, weight: .regular))
                    .foregroundColor(colorScheme.textColor)
                    .lineLimit(1)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 2)
            .background(RoundedRectangle(cornerRadius: 100)
                .fill(colorScheme.backgroundColor)
            )
            .clipped()
        }
        .buttonStyle(PlainButtonStyle())
    }
}
