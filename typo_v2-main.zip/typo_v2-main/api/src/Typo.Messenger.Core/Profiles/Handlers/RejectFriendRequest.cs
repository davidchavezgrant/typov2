using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class RejectFriendRequest
{
	private readonly MessengerDbContext _db;
	private readonly Guid               _requestId;
	private readonly Guid               _userId;
	public RejectFriendRequest(MessengerDbContext db,
							   Guid               requestId,
							   Guid               userId)
	{
		this._db        = db;
		this._requestId = requestId;
		this._userId    = userId;
	}
	public async Task<Result> Execute()
	{
		var profile = await this._db.Profiles.Include(p => p.ReceivedRequests)
								.ThenInclude(x => x.Sender)
								.Include(p => p.SentRequests)
								.ThenInclude(x => x.Receiver)
								.FirstOrDefaultAsync(p => p.Id == this._userId);

		if (profile is null)
			return Error.NotFound("Profile not found");

		var request = profile.ReceivedRequests.FirstOrDefault(x => x.Id == this._requestId);
		if (request is null)
			return Error.NotFound("Friend request not found");

		profile.RejectFriendRequest(request.Sender);
		await this._db.SaveChangesAsync();
		return Result.Ok;
	}
}