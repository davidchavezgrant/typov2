namespace Typo.Web.Api;
public class ActiveProfileIdMiddleware
{
	private readonly RequestDelegate _next;

	public ActiveProfileIdMiddleware(RequestDelegate next)
	{
		this._next = next;
	}

	public async Task InvokeAsync(HttpContext httpContext)
	{
		// Try to get the X-Active-Profile-Id header
		if (!httpContext.Request.Headers.TryGetValue("X-Active-Profile-Id", out var profileIdHeader)
			|| string.IsNullOrWhiteSpace(profileIdHeader))
		{
			httpContext.Response.StatusCode = 400; // Bad Request
			await httpContext.Response.WriteAsJsonAsync(new { message = "Active profile ID is required." });
			Console.WriteLine("Active profile ID is required.");
			return;
		}

		if (!Guid.TryParse(profileIdHeader, out var profileId) || profileId == Guid.Empty)
		{
			httpContext.Response.StatusCode = 400; // Bad Request
			await httpContext.Response.WriteAsJsonAsync(new { message = "Invalid active profile ID." });
			Console.WriteLine("Invalid active profile ID.");
			return;
		}

		// Storing the valid profileId into HttpContext.Items to be used further down the pipeline.
		httpContext.Items["ProfileId"] = profileId;

		// Call the next delegate/middleware in the pipeline
		await this._next(httpContext);
	}
}