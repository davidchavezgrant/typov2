using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Typo.Identity.Contracts;
using Typo.Identity.Core.Otp;
using Typo.Identity.Tests.Integration.Setup;
using Typo.Identity.Tests.Integration.Test_Data;
using Typo.Web.Api;
namespace Typo.Identity.Tests.Integration.Otp;
public class SendPhoneOtp: ApiTestBase
{
	public SendPhoneOtp(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Theory]
	[ClassData(typeof(ValidPhoneNumbers))]
	public async Task ReturnsOk_When_PhoneNumberIsValid(string phone)
	{
		await this.AddUserWithPhoneNumber(phone);
		var request  = new PhoneNumberDto(phone);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.OK);
	}

	[Theory]
	[ClassData(typeof(InvalidPhoneNumbers))]
	public async Task ReturnsBadRequest_When_PhoneNumberIsInvalid(string phone)
	{
		await this.AddUserWithPhoneNumber(phone);
		var request  = new PhoneNumberDto(phone);
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
	}

	[Fact]
	public async Task ReturnsNotFound_When_PhoneIsNotRegistered()
	{
		var request  = new SendOtpRequest("+12939394032");
		var response = await this.ApiClient.PostAsJsonAsync(IdentityRoutes.SEND_OTP, request);
		response.StatusCode.Should().Be(HttpStatusCode.NotFound);
	}
}