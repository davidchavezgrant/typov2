using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Typo.Identity.Core;
using Typo.Kernel.Configuration;
namespace Typo.Web.Api;
public static class IdentityModuleServices
{
	public static IServiceCollection AddIdentityModuleServices(this IServiceCollection services,
															   string?                 connectionString,
															   JwtSettings?            jwtSettings)
	{
		services.AddTypoIdentityServices(connectionString);
		services.AddOtpServices();
		services.AddAuthentication(options =>
								   {
									   options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
									   options.DefaultChallengeScheme    = JwtBearerDefaults.AuthenticationScheme;
								   })
				.AddJwtBearer(options =>
							  {
								  options.TokenValidationParameters = new TokenValidationParameters
								  {
									  ValidateIssuerSigningKey = true,
									  IssuerSigningKey =
										  new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtSettings.SecurityKey)),
									  ValidateIssuer   = false,
									  ValidateAudience = false,
									  ValidateLifetime = true,
									  ClockSkew        = TimeSpan.Zero
								  };
							  });

		services.AddAuthorization();

		return services;
	}
}