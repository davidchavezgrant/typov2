import AVFoundation
import Combine
import SwiftUI

public class AttachmentViewModel: Identifiable, ObservableObject {
    @Published
    var data: AttachmentData
    @Published
    var playheadPosition: CMTime
    @Published
    var isPlaying: Bool
    @Published
    var displayIndex: Int
    @Published
    var isActive: Bool = false
    weak var activeContentString: NSAttributedString?
    weak var inactiveContentString: NSAttributedString?

    init() {
        displayIndex = 0
        data = EmptyAttachmentData()
        playheadPosition = CMTime(value: 0, timescale: 60)
        isPlaying = false
    }

    init(data: AttachmentData, displayIndex: Int) {
        self.displayIndex = displayIndex
        self.data = data
        playheadPosition = CMTime(value: 0, timescale: 60)
        isPlaying = false
    }

    enum eventType {
        case fileDownloaded
    }

    private let subject = PassthroughSubject<(AttachmentViewModel, AttachmentViewModel.eventType), Never>()
    var publisher: AnyPublisher<(AttachmentViewModel, AttachmentViewModel.eventType), Never> {
        subject.eraseToAnyPublisher()
    }

    func handleDownloadCompleted(isFromMe: Bool) {
        if let fileData = data as? FileAttachmentData {
            let size = MediaSize.create(fileName: fileData.name, fileId: fileData.id)
            fileData.updateSize(size)
        }
        DispatchQueue.main.async {
            self.activeContentString = self.generatePillContent(attachment: self,
                                                                status: PillStatus.lookup(isFromMe: isFromMe,
                                                                                          isActive: true))
            self.inactiveContentString = self.generatePillContent(attachment: self,
                                                                  status: PillStatus.lookup(isFromMe: isFromMe,
                                                                                            isActive: false))
        }
        subject.send((self, .fileDownloaded))
    }

    func clone() -> AttachmentViewModel {
        AttachmentViewModel(
            data: data,
            displayIndex: displayIndex
        )
    }

    private func generatePillContent(attachment: AttachmentViewModel, status: PillStatus) -> NSAttributedString
    {
        let content = PillContent(attachment: attachment, type: status)
        return build(pillContent: content)
    }

    func build(pillContent: PillContent) -> NSAttributedString {
        guard let thumbnailImage = pillContent.thumbnail
        else {
            return NSAttributedString(string: "clipped image nil")
        }

        let frame = createFrame(pillData: pillContent)
        let imageAttachment = NSTextAttachment()
        imageAttachment.image = thumbnailImage
        let content = NSMutableAttributedString(attachment: imageAttachment)

        imageAttachment.bounds = CGRect(x: 0,
                                        y: CGFloat(PillConstants.verticalOffset),
                                        width: frame.size.width,
                                        height: CGFloat(PillConstants.pillHeight))

        let contentAttributes: [NSAttributedString.Key: Any] = [.pill: pillContent.attachment]

        content.addAttributes(contentAttributes,
                              range: NSRange(location: 0, length: content.length))
        return content
    }

    private func createFrame(pillData: PillContent) -> CGRect {
        let textSize = pillData.text.size()
        let textWidth = Int(textSize.width)
        let horizontalPadding = PillConstants.horizontalPadding * 2
        let imageWidth = PillConstants.imageWidth
        let innerPadding = PillConstants.innerPadding
        let outerPadding = PillConstants.outerPadding
        let frameWidth: Int = horizontalPadding + imageWidth + innerPadding + textWidth + outerPadding
        let frameHeight = PillConstants.pillHeight
        return CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
    }

    public func getPillContent(ofType type: PillStatus) -> NSAttributedString {
        if let pill = getProperty(ofType: type) {
            return pill
        }
        let generatedPill = generatePillContent(attachment: self, status: type)
        save(pill: generatedPill, ofType: type)
        return generatedPill
    }

    private func save(pill: NSAttributedString, ofType type: PillStatus) {
        switch type {
        case .sent(selected: true),
             .received(selected: true):
            activeContentString = pill
        case .sent(selected: false),
             .received(selected: false):
            inactiveContentString = pill
        default:
            break
        }
    }

    private func getProperty(ofType type: PillStatus) -> NSAttributedString? {
        switch type {
        case .sent(selected: true),
             .received(selected: true):
            return activeContentString
        case .sent(selected: false),
             .received(selected: false):
            return inactiveContentString
        default:
            return inactiveContentString // maybe log an error here
        }
    }

    var thumbnail: NSImage? {
        switch data {
        case is FileAttachmentData:
            if let file = data as? FileAttachmentData,
               let fileUrl = URL.localFilePath(fileName: file.name, folderName: file.id),
               let category = MediaType.lookup(fileName: file.name)
            {
                switch category {
                case .image:
                    return NSImage(contentsOf: fileUrl)
                case .audio:
                    return NSImage(systemSymbolName: "waveform", accessibilityDescription: nil)

                case .textDocument:
                    return NSImage(systemSymbolName: "doc.fill", accessibilityDescription: nil)

                case .spatialModel:
                    return NSImage(systemSymbolName: "rotate.3d", accessibilityDescription: nil)

                case .video:
                    return nil
                case .unknown:
                    return NSImage(systemSymbolName: "question-mark", accessibilityDescription: nil)
                }
            }

        case is LinkAttachmentData:
            return NSImage(systemSymbolName: "link", accessibilityDescription: nil)
        case is SystemMessageAttachmentData:
            return nil
        default:
            return nil
        }
        return nil
    }

    public func getContentState() -> AttachmentContentState {
        AttachmentContentState(id: data.id,
                               data: data,
                               displayIndex: displayIndex)
    }
}

struct PillContent {
    let type: PillStatus
    let attachment: AttachmentViewModel
    private(set) var colors: ColorScheme!
    private(set) var text: NSAttributedString!
    private(set) var thumbnail: NSImage!

    init(attachment: AttachmentViewModel, type: PillStatus) {
        self.attachment = attachment
        self.type = type
        colors = ColorScheme.create(for: type)
        thumbnail = attachment.thumbnail
    }
}
