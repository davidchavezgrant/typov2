using FluentAssertions;
using Typo.Messenger.Core.Profiles.Domain;
namespace Typo.Messenger.Tests.Unit.Profiles.UserProfileTests;
public class AcceptFriendRequest
{
	[Fact]
	public void AcceptsRequest_When_Called()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.AcceptFriendRequest(user1);
		var request  = user1.SentRequests.FirstOrDefault(r => r.ReceiverId   == user2.Id);
		var request2 = user2.ReceivedRequests.FirstOrDefault(r => r.SenderId == user1.Id);

		// Assert
		request.Should().NotBeNull();
		request2.Should().NotBeNull();

		request!.Status.Should().Be(FriendRequestStatus.ACCEPTED);
		request2!.Status.Should().Be(FriendRequestStatus.ACCEPTED);
	}

	[Fact]
	public void AddsFriendship_When_Called()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.AcceptFriendRequest(user1);

		// Assert
		user1.Friendships.Should().Contain(user2);
		user2.Friendships.Should().Contain(user1);
	}
	[Fact]
	public void CreatesFriendship_When_Valid()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.AcceptFriendRequest(user1);

		// Assert
		user1.Friendships.Should().Contain(user2);
		user2.Friendships.Should().Contain(user1);
	}

	[Fact]
	public void DoesNotAddFriendship_When_CalledTwice()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.AcceptFriendRequest(user1);
		user2.AcceptFriendRequest(user1);

		// Assert
		user1.Friendships.Should().Contain(user2);
		user2.Friendships.Should().Contain(user1);
	}
	[Fact]
	public void DoesNotChangeFriendshipStatus_When_RequestAlreadyAccepted()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);
		user2.AcceptFriendRequest(user1);

		// Act
		user2.AcceptFriendRequest(user1);

		// Assert
		user1.Friendships.Should().Contain(user2);
		user2.Friendships.Should().Contain(user1);
	}

	[Fact]
	public void DoesNotCreateFriendship_When_Invalid()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");

		// Act
		user2.AcceptFriendRequest(user1);

		// Assert
		user1.Friendships.Should().BeEmpty();
		user2.Friendships.Should().BeEmpty();
	}
	[Fact]
	public void FriendRequestStatus_IsConsistentAcrossSenderReceiver()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		user1.SendFriendRequest(user2);

		// Act
		user2.AcceptFriendRequest(user1);

		// Assert
		var requestByUser1 = user1.SentRequests.FirstOrDefault();
		var requestByUser2 = user2.ReceivedRequests.FirstOrDefault();
		requestByUser1.Status.Should().Be(FriendRequestStatus.ACCEPTED);
		requestByUser2.Status.Should().Be(FriendRequestStatus.ACCEPTED);
	}

	[Fact]
	public void DoesNothing_When_NoMatchingRequestExists()
	{
		// Arrange
		var user1 = new UserProfile(Guid.NewGuid(), "User1");
		var user2 = new UserProfile(Guid.NewGuid(), "User2");
		var user3 = new UserProfile(Guid.NewGuid(), "User3");
		user1.SendFriendRequest(user2);

		// Act
		Action act = () => user2.AcceptFriendRequest(user3);

		// Assert
		act.Should().NotThrow();
		user2.Friendships.Should().NotContain(user1);
		user2.Friendships.Should().NotContain(user3);
		user1.Friendships.Should().NotContain(user2);
		user3.Friendships.Should().NotContain(user2);

		var request = user1.SentRequests.FirstOrDefault(r => r.ReceiverId == user2.Id);
		request.Should().NotBeNull();
		request!.Status.Should().Be(FriendRequestStatus.PENDING); // Assuming the default status is PENDING
	}
}