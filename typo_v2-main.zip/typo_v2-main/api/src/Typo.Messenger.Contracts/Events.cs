﻿namespace Typo.Messenger.Contracts;
public sealed record UserLoggedIn(string       DeviceToken, string            Platform,     string PhoneNumber);
public sealed record ShadowProfileFound(string SenderName,  string            ReceiverName, string ReceiverPhoneNumber);
public sealed record ArtifactCreated(Guid      ArtifactId,  IEnumerable<Guid> RecipientIds): IntegrationEvent(Guid.NewGuid());
public record IntegrationEvent(Guid            Id);
public sealed record ChatMessageSent(
Guid   MessageId,
Guid   SenderId,
Guid   ChatId,
string Message): IntegrationEvent(Guid.NewGuid());
public abstract record MessageStatus
{
	public static readonly MessageStatus Pending   = new PendingStatus();
	public static readonly MessageStatus Processed = new ProcessedStatus();
	public static readonly MessageStatus Failed    = new FailedStatus();
	private MessageStatus() {}
	public sealed record FailedStatus: MessageStatus;
	public sealed record PendingStatus: MessageStatus;
	public sealed record ProcessedStatus: MessageStatus;
}
public sealed record UserConnected(Guid    UserId, string ConnectionId): IntegrationEvent(Guid.NewGuid());
public sealed record UserDisconnected(Guid UserId, string ConnectionId): IntegrationEvent(Guid.NewGuid());
public sealed record UserSubscribed(Guid   UserId): IntegrationEvent(Guid.NewGuid());
public sealed record UserUnsubscribed(Guid UserId): IntegrationEvent(Guid.NewGuid());
public sealed record ChatCreated(Guid ChatId, IEnumerable<Guid> ParticipantProfileIds): IntegrationEvent(Guid.NewGuid());
public sealed record MessageSent(Guid ChatMessageId, Guid ChatId, Guid SenderId, string Text): IntegrationEvent(Guid.NewGuid());
public sealed record ChatUpdated(Guid ChatId) : IntegrationEvent(Guid.NewGuid());