import Foundation
import SwiftUI
class AppState: ObservableObject
{
    @Published
    var showCompose = false
    {
        didSet {
            if showProfile, showCompose {
                showProfile = false
            }
        }
    }
    @Published
    var showProfile = false
    {
        didSet {
            if showProfile, showCompose {
                showCompose = false
            }
        }
    }
    @Published
    var isDragActive = false
}
