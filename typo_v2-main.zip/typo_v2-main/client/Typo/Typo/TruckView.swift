import SwiftUI

// MARK: - TruckView

struct TruckView: View {
    // MARK: Internal

    @ObservedObject
    var model: FoodTruckModel
    @Binding
    var navigationSelection: Panel?

    var body: some View {
        WidthThresholdReader(widthThreshold: 520) { _ in
            ScrollView(.vertical) {
                VStack(spacing: 16) {
                    Grid(horizontalSpacing: 12, verticalSpacing: 12) {}
                        .containerShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .fixedSize(horizontal: false, vertical: true)
                        .padding([.horizontal, .bottom], 16)
                        .frame(maxWidth: 1200)
                }
            }
        }
        .background(.quaternary.opacity(0.5))
        .background()
        .navigationTitle("Truck")
        .navigationDestination(for: Panel.self) { panel in
            switch panel {
            case .orders:
                OrdersView(model: model)
            default:
                DonutGallery(model: model)
            }
        }
    }

    var cardNavigation: TruckCardHeaderNavigation {
        let useNavigationLink: Bool = {
            #if os(iOS)
                return sizeClass == .compact
            #else
                return false
            #endif
        }()
        if useNavigationLink {
            return .navigationLink
        } else {
            return .selection($navigationSelection)
        }
    }

    // MARK: Private

    #if os(iOS)
        @Environment(\.horizontalSizeClass)
        private var sizeClass
    #endif
}

// MARK: - TruckCardHeaderNavigation

enum TruckCardHeaderNavigation {
    case navigationLink
    case selection(Binding<Panel?>)
}

// MARK: - TruckView_Previews

struct TruckView_Previews: PreviewProvider {
    struct Preview: View {
        // MARK: Internal

        var body: some View {
            TruckView(model: model, navigationSelection: $navigationSelection)
        }

        // MARK: Private

        @StateObject
        private var model = FoodTruckModel()
        @State
        private var navigationSelection: Panel? = Panel.truck
    }

    static var previews: some View {
        NavigationStack {
            Preview()
        }
    }
}

@MainActor
public class FoodTruckModel: ObservableObject {}

// MARK: - OrdersView

struct OrdersView: View {
    @ObservedObject
    var model: FoodTruckModel

    var body: some View {
        Text("Orders")
    }
}

// MARK: - DonutGallery

struct DonutGallery: View {
    @ObservedObject
    var model: FoodTruckModel

    var body: some View {
        Text("Donut Gallery")
    }
}
