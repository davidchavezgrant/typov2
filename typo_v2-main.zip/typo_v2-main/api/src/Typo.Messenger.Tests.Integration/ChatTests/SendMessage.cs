using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Typo.Messenger.Core.Chats.Domain;
using Typo.Messenger.Tests.Integration.Setup;
using Typo.Web.Api;
namespace Typo.Messenger.Tests.Integration.ChatTests;
public class SendMessage: ApiTestBase
{
	/// <inheritdoc />
	public SendMessage(CustomWebApplicationFactory<IWebApi> factory): base(factory)
	{
		factory.ClearDatabase();
	}

	[Fact]
	public async Task SendsMessageToCorrectRoom()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request      = new CreateChatRequest(new List<Guid> { user1!.Id, user2!.Id });
		var response     = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		var roomResponse = await response.Content.ReadFromJsonAsync<ChatDto>();
		var message      = new SendMessageRequest(roomResponse.Id, user1.Id, "hello", 111111);

		// Act
		var messageResponse = await this.ApiClient.PostAsJsonAsync($"/api/chats/{roomResponse.Id}/messages", message);
		var messageResult   = await messageResponse.Content.ReadFromJsonAsync<ChatMessageDto>();

		// Assert
		using var db   = this.CreateDbContext();
		var       room = await db.Chats.Include(x => x.Messages).FirstOrDefaultAsync(x => x.Id == roomResponse.Id);
		room.Should().NotBeNull();
		room.Messages.Should().NotBeEmpty();
		room.Messages.First().Text.Should().Be("hello");
	}

	[Fact]
	public async Task ReturnsMessageDto()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request      = new CreateChatRequest(new List<Guid> { user1!.Id, user2!.Id });
		var response     = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		var roomResponse = await response.Content.ReadFromJsonAsync<ChatDto>();
		var message      = new SendMessageRequest(roomResponse.Id, user1.Id, "hello", 111112);

		// Act
		var messageResponse = await this.ApiClient.PostAsJsonAsync($"/api/chats/{roomResponse.Id}/messages", message);
		var messageResult   = await messageResponse.Content.ReadFromJsonAsync<ChatMessageDto>();

		// Assert
		messageResult.Should().NotBeNull();
		messageResult.Text.Should().Be("hello");
		messageResult.SenderId.Should().Be(user1.Id);
		messageResult.ChatId.Should().Be(roomResponse.Id);
		messageResult.Id.Should().NotBeEmpty();
	}

	[Fact]
	public async Task ReturnsDtoThatMatchesDatabase()
	{
		// Arrange
		var user1 = await this.CreateProfile("user1");
		var user2 = await this.CreateProfile("user2");
		this.SetActiveProfileHeader(user1.Id);
		var request      = new CreateChatRequest(new List<Guid> { user1!.Id, user2!.Id });
		var response     = await this.ApiClient.PostAsJsonAsync("/api/chats", request);
		var roomResponse = await response.Content.ReadFromJsonAsync<ChatDto>();
		var message      = new SendMessageRequest(roomResponse.Id, user1.Id, "hello", 11223);

		// Act
		var messageResponse = await this.ApiClient.PostAsJsonAsync($"/api/chats/{roomResponse.Id}/messages", message);
		var messageResult   = await messageResponse.Content.ReadFromJsonAsync<ChatMessageDto>();

		// Assert
		using var db   = this.CreateDbContext();
		var       room = await db.Chats.Include(x => x.Messages).FirstOrDefaultAsync(x => x.Id == roomResponse.Id);
		room.Should().NotBeNull();
		room.Messages.Should().NotBeEmpty();
		room.Messages.First().Text.Should().Be("hello");

		messageResult.Should().NotBeNull();
		messageResult.Text.Should().Be("hello");
		messageResult.SenderId.Should().Be(user1.Id);
		messageResult.ChatId.Should().Be(room.Id);
		messageResult.Id.Should().NotBeEmpty();
	}
}