using Microsoft.EntityFrameworkCore;
using Typo.Kernel;
using Typo.Messenger.Core.DAL;
namespace Typo.Messenger.Core.Profiles.Handlers;
internal sealed class DeleteProfile
{
	private readonly MessengerDbContext _dbContext;
	private readonly Guid               _profileId;
	public DeleteProfile(Guid profileId, MessengerDbContext dbContext)
	{
		this._profileId = profileId;
		this._dbContext = dbContext;
	}
	public async Task<Result> Execute()
	{
		var profile = await this._dbContext.Profiles.FirstOrDefaultAsync(p => p.Id == this._profileId);
		if (profile is null) return Error.NotFound("Profile not found");

		this._dbContext.Profiles.Remove(profile);
		await this._dbContext.SaveChangesAsync();
		return Result.Ok;
	}
}